require('dotenv').config();
const express = require('express');
const { Telegraf } = require('telegraf');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');

const PORT = process.env.PORT || 8010;
const BOT_TOKEN = process.env.BOT_TOKEN || ""; 

const app = express(); 
const bot = new Telegraf(BOT_TOKEN);

app.use(cors()); 
app.use(express.json()); 
app.set('trust proxy', 1);

const apiLimiter = rateLimit({
    windowMs: 1000, 
    max: 15, 
    message: { success: false, msg: "Thao tác quá nhanh, xin hãy từ từ!" }
});
app.use('/api/', apiLimiter);

const getLR = (b) => {
    if (b < 100000) return 0.50;
    if (b < 1000000) return 0.60;
    if (b < 10000000) return 0.70;
    if (b < 50000000) return 0.80;
    return 0.90;
};

app.use('/api/', (req, res, next) => {
    if (req.method !== 'POST') return next();
    const { initData, telegram_id } = req.body;
    if (!telegram_id) return next();
    if (!initData) return res.json({success: false, msg: "Thiếu chữ ký bảo mật Telegram!"});
    try {
        const urlParams = new URLSearchParams(initData);
        const hash = urlParams.get('hash');
        urlParams.delete('hash');
        const dataToCheck = [...urlParams.entries()].map(([k, v]) => `${k}=${v}`).sort().join('\n');
        const secretKey = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
        const _hash = crypto.createHmac('sha256', secretKey).update(dataToCheck).digest('hex');
        if (hash !== _hash) return res.json({success: false, msg: "Lệnh bài giả mạo! Lính đâu, bắt lấy hắn!"});
        const user = JSON.parse(urlParams.get('user'));
        if (user.id.toString() !== telegram_id.toString()) return res.json({success: false, msg: "Thân phận không khớp với chữ ký!"});
    } catch (e) { return res.json({success: false, msg: "Lỗi xác thực bảo mật!"}); }
    next();
});

app.use(express.static(path.join(__dirname, 'public'), {
    setHeaders: (res, filePath) => {
        if (filePath.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
        }
    }
}));

// ==========================================
// 1. DATABASE CHÍNH
// ==========================================
const dbPath = '/root/vt/vuongtrieu.db'; 
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) console.error("Lỗi kết nối DB Admin:", err.message);
    else console.log("Miniapp đã kết nối Database tại /root/vt/vuongtrieu.db");
});

db.serialize(() => {
    db.run("PRAGMA journal_mode = WAL;");
    db.run("PRAGMA busy_timeout = 5000;");
    db.run(`CREATE TABLE IF NOT EXISTS system_config (key TEXT PRIMARY KEY, value TEXT)`);
});

const getVNDate = (offsetDays = 0) => {
    const d = new Date();
    d.setUTCHours(d.getUTCHours() + 7 + (offsetDays * 24));
    return d.toISOString().split('T')[0];
};

const formatFull = n => Math.floor(n).toLocaleString('en-US');

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (telegram_id TEXT PRIMARY KEY, first_name TEXT, wood REAL DEFAULT 0, stone REAL DEFAULT 0, iron REAL DEFAULT 0, food REAL DEFAULT 0, gold REAL DEFAULT 0, energy INTEGER DEFAULT 1000, max_energy INTEGER DEFAULT 1000, last_sync_time INTEGER DEFAULT 0, tap_level INTEGER DEFAULT 1, regen_level INTEGER DEFAULT 1, last_checkin TEXT DEFAULT '', troops REAL DEFAULT 1, current_stage INTEGER DEFAULT 1)`);
    db.run(`CREATE TABLE IF NOT EXISTS market_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, seller_id TEXT NOT NULL, resource_type TEXT NOT NULL, amount REAL NOT NULL, price_gold REAL NOT NULL, status TEXT DEFAULT 'OPEN', buyer_id TEXT, created_at INTEGER DEFAULT (strftime('%s','now')*1000), bought_at INTEGER)`);
    
    const addCol = (table, col, t) => { db.run(`ALTER TABLE ${table} ADD COLUMN ${col} ${t}`, () => {}); };
    addCol('users', 'current_stage', 'INTEGER DEFAULT 1'); addCol('users', 'regen_level', 'INTEGER DEFAULT 1');
    addCol('users', 'dark_iron', 'REAL DEFAULT 0'); addCol('users', 'jade', 'REAL DEFAULT 0');
    addCol('users', 'glaze', 'REAL DEFAULT 0'); addCol('users', 'purple_gold', 'REAL DEFAULT 0');  
    addCol('users', 'ad_autotap_end', 'INTEGER DEFAULT 0'); addCol('users', 'ad_energy_last', 'INTEGER DEFAULT 0');
    addCol('users', 'ad_random_last', 'INTEGER DEFAULT 0'); addCol('users', 'ad_global_last', 'INTEGER DEFAULT 0');
    addCol('users', 'checkin_streak', 'INTEGER DEFAULT 0'); addCol('users', 'hide_avatar', 'INTEGER DEFAULT 0');
    addCol('users', 'palace_level', 'INTEGER DEFAULT 1'); addCol('users', 'gold_rate', 'REAL DEFAULT 0');
    addCol('users', 'tap_reset_time', 'INTEGER DEFAULT 0'); addCol('users', 'tapped_i', 'REAL DEFAULT 0');
    addCol('users', 'tapped_di', 'REAL DEFAULT 0'); addCol('users', 'tapped_j', 'REAL DEFAULT 0');
    addCol('users', 'tapped_gl', 'REAL DEFAULT 0'); addCol('users', 'tapped_pg', 'REAL DEFAULT 0');
    addCol('users', 'iron_rate', 'REAL DEFAULT 0'); addCol('users', 'dark_iron_rate', 'REAL DEFAULT 0');
    addCol('users', 'jade_rate', 'REAL DEFAULT 0'); addCol('users', 'glaze_rate', 'REAL DEFAULT 0');
    addCol('users', 'purple_gold_rate', 'REAL DEFAULT 0'); addCol('users', 'ban_status', 'INTEGER DEFAULT 0');
    addCol('users', 'is_special', 'INTEGER DEFAULT 0'); addCol('users', 'device_code', 'TEXT');
    addCol('users', 'join_date', 'TEXT'); addCol('users', 'is_verified', 'INTEGER DEFAULT 0');
    addCol('users', 'bio', 'TEXT DEFAULT ""'); addCol('users', 'contact_tg', 'TEXT DEFAULT ""');
    addCol('users', 'market_slot_extra', 'INTEGER DEFAULT 0'); addCol('users', 'is_marked', 'INTEGER DEFAULT 0');
    addCol('market_orders', 'target_id', 'TEXT'); addCol('market_orders', 'is_private', 'INTEGER DEFAULT 0');

    db.run(`CREATE TABLE IF NOT EXISTS buildings (id TEXT PRIMARY KEY, name TEXT, description TEXT, req_palace INTEGER, base_time INTEGER, base_wood INTEGER, base_stone INTEGER, base_iron INTEGER, base_dark_iron INTEGER, base_jade INTEGER, base_glaze INTEGER, base_purple_gold INTEGER, effect_type TEXT, base_val REAL)`);
    addCol('buildings', 'effect_name', 'TEXT');

    db.get("SELECT COUNT(*) as count FROM buildings", (err, row) => {
        if (row && row.count === 0) {
            const defaultBuildings = [
                ['palace', 'Kim Loan Bảo Điện', 'Trái tim Vương Triều. Nơi duy nhất đúc ra Vàng.', 1, 60, 1000, 1000, 0, 0, 0, 0, 0, 'gold', 520, 'Vàng'],
                ['kitchen', 'Ngự Thiện Bảo Các', 'Hậu cần vững chắc, cung cấp Lương thảo.', 1, 120, 500, 500, 0, 0, 0, 0, 0, 'food', 100, 'Lương Thực'],
                ['barracks', 'Thần Sách Đại Doanh', 'Nơi huấn luyện tân binh, tăng sức chứa Quân đội.', 2, 300, 1000, 1000, 200, 0, 0, 0, 0, 'troops', 20, 'Binh Sĩ'],
                ['ironmine', 'Thái Thiết Cự Cốc', 'Nơi khai thác Sắt tự động.', 2, 600, 1500, 1500, 0, 0, 0, 0, 0, 'iron', 50, 'Sắt'],
                ['hospital', 'Hoàng Gia Y Viện', 'Giảm hao tổn tài nguyên khi mộ binh.', 3, 1200, 2000, 2000, 500, 0, 0, 0, 0, 'discount_train', 0.02, 'Giảm Phí'],
                ['forge', 'Thần Binh Bảo Các', 'Tăng tỷ lệ chiến thắng.', 4, 2400, 3000, 3000, 1000, 0, 0, 0, 0, 'winrate', 0.02, 'Tỷ Lệ Thắng'],
                ['darkiron_mine', 'U Minh Thiết Động', 'Khai thác Huyền Thiết quý hiếm.', 5, 3600, 5000, 5000, 2000, 0, 0, 0, 0, 'dark_iron', 20, 'Huyền Thiết'],
                ['observatory', 'Khâm Thiên Tinh Giám', 'Quan sát tinh tượng, cứu binh tử trận.', 6, 7200, 8000, 8000, 4000, 500, 0, 0, 0, 'save_troops', 0.02, 'Cứu Binh'],
                ['lumber', 'Hoàng Tộc Lâm Doanh', 'Rừng thiêng cung cấp Gỗ dồi dào. Yêu cầu Cấp 7.', 7, 10800, 15000, 8000, 5000, 1000, 0, 0, 0, 'wood', 300, 'Gỗ'], 
                ['quarry', 'Khai Thạch Cự Cốc', 'Mỏ đá khổng lồ. Yêu cầu Cấp 7.', 7, 10800, 8000, 15000, 5000, 1000, 0, 0, 0, 'stone', 300, 'Đá'], 
                ['smelter', 'Dưỡng Tâm Bảo Điện', 'Mật thất gia tăng tốc độ hồi phục Thể lực.', 8, 14400, 25000, 25000, 10000, 2000, 0, 0, 0, 'energy_regen', 1, 'Hồi Thể Lực'], 
                ['jade_cave', 'Cửu Thiên Ngọc Động', 'Nơi hội tụ linh khí, khai thác Linh Ngọc.', 10, 86400, 80000, 80000, 30000, 8000, 0, 0, 0, 'jade', 5, 'Linh Ngọc'],
                ['glazekiln', 'Lưu Ly Bảo Tháp', 'Sản xuất Lưu Ly, vật liệu xây cất cao cấp.', 12, 172800, 150000, 150000, 80000, 20000, 5000, 0, 0, 'glaze', 2, 'Lưu Ly'],
                ['purplegold_mine', 'Tử Kim Thần Các', 'Khai thác Tử Kim cực hiếm.', 15, 259200, 300000, 300000, 150000, 50000, 15000, 2000, 0, 'purple_gold', 1, 'Tử Kim']
            ];
            const stmt = db.prepare(`INSERT INTO buildings (id, name, description, req_palace, base_time, base_wood, base_stone, base_iron, base_dark_iron, base_jade, base_glaze, base_purple_gold, effect_type, base_val, effect_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
            defaultBuildings.forEach(b => stmt.run(b));
            stmt.finalize();
        }
    });

    db.run(`CREATE TABLE IF NOT EXISTS referrals (inviter_id TEXT, invitee_id TEXT, first_name TEXT, tax_wood REAL DEFAULT 0, tax_stone REAL DEFAULT 0, tax_iron REAL DEFAULT 0, tax_dark_iron REAL DEFAULT 0, tax_jade REAL DEFAULT 0, tax_gold REAL DEFAULT 0, tax_food REAL DEFAULT 0, PRIMARY KEY(invitee_id))`);
    addCol('referrals', 'tax_glaze', 'REAL DEFAULT 0'); addCol('referrals', 'tax_purple_gold', 'REAL DEFAULT 0');

    db.run(`UPDATE users SET troops = 1 WHERE troops = 0 AND current_stage = 1`, () => {});
    db.run(`CREATE TABLE IF NOT EXISTS user_buildings (telegram_id TEXT, building_id TEXT, qty INTEGER DEFAULT 0, is_upgrading INTEGER DEFAULT 0, upgrade_end_time INTEGER DEFAULT 0, PRIMARY KEY(telegram_id, building_id))`);
    addCol('user_buildings', 'is_upgrading', 'INTEGER DEFAULT 0'); addCol('user_buildings', 'upgrade_end_time', 'INTEGER DEFAULT 0');

    db.run(`CREATE TABLE IF NOT EXISTS withdrawals (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT, bank_info TEXT, amount REAL, status TEXT DEFAULT 'PENDING', created_at INTEGER)`);
    addCol('withdrawals', 'reject_reason', 'TEXT'); addCol('withdrawals', 'is_refunded', 'INTEGER DEFAULT 0');

    db.run(`CREATE TABLE IF NOT EXISTS user_tasks (telegram_id TEXT, task_id TEXT, PRIMARY KEY(telegram_id, task_id))`);
    db.run(`CREATE TABLE IF NOT EXISTS used_giftcodes (telegram_id TEXT, code TEXT, PRIMARY KEY(telegram_id, code))`);
    db.run(`CREATE TABLE IF NOT EXISTS support_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT, message TEXT, created_at INTEGER, status TEXT DEFAULT 'PENDING')`);
    
    db.run(`CREATE TABLE IF NOT EXISTS system_config (key TEXT PRIMARY KEY, value TEXT)`);
    db.run(`INSERT OR IGNORE INTO system_config (key, value) VALUES ('announcements', '[]')`);

    db.run(`CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, link TEXT, reward_type TEXT, reward_data TEXT)`);
    db.run(`CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT, sender TEXT, message TEXT, created_at INTEGER, is_read INTEGER DEFAULT 0)`);
    db.run(`CREATE TABLE IF NOT EXISTS advanced_giftcodes (code TEXT PRIMARY KEY, type TEXT, max_uses INTEGER, uses INTEGER DEFAULT 0, reward_data TEXT, expires_at INTEGER)`);
});

// ==========================================
// 2. DATABASE LỊCH SỬ (TÁCH RIÊNG HOÀN TOÀN)
// ==========================================
const historyDbPath = '/root/vt/history.db'; 
const historyDb = new sqlite3.Database(historyDbPath, (err) => {
    if (err) console.error("Lỗi kết nối DB Lịch sử:", err.message);
    else console.log("Miniapp đã kết nối Database Lịch sử tại /root/vt/history.db");
});

historyDb.serialize(() => {
    historyDb.run("PRAGMA journal_mode = WAL;");
    historyDb.run("PRAGMA busy_timeout = 5000;");
    historyDb.run(`CREATE TABLE IF NOT EXISTS transaction_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id TEXT,
        type TEXT,            -- 'income' hoặc 'expense' hoặc 'info'
        resource_type TEXT,   -- 'gold', 'wood', 'food'...
        amount REAL,          -- Số lượng biến động
        balance REAL,         -- SỐ DƯ SAU GIAO DỊCH
        action TEXT,          -- Hành động
        details TEXT,         -- Giải thích
        created_at INTEGER
    )`);
});

// Hàm ghi Lịch sử Thu/Chi MỚI (Có Số dư - Dùng cho Sao Kê)
const logTransaction = (telegramId, type, resourceType, amount, balance, action, details = "") => {
    historyDb.run(
        `INSERT INTO transaction_history (telegram_id, type, resource_type, amount, balance, action, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [telegramId.toString(), type, resourceType, amount, balance, action, details, Date.now()],
        (err) => { if (err) console.error("Lỗi ghi lịch sử Thu/Chi:", err.message); }
    );
};

// Hàm ghi Lịch sử CŨ (Chỉ hiện chữ - Để tương thích các hệ thống cũ chưa nâng cấp)
const logHistory = (tid, action, details) => {
    historyDb.run("INSERT INTO transaction_history (telegram_id, type, resource_type, amount, balance, action, details, created_at) VALUES (?, 'info', 'none', 0, 0, ?, ?, ?)", [tid.toString(), action, details, Date.now()]);
};

// ==========================================
// 3. CÁC API & LOGIC HỆ THỐNG
// ==========================================
const processTax = (inviteeId, earnedW, earnedS, earnedI, earnedDI, earnedJ, earnedGL, earnedPG, earnedG, earnedF) => {
    if (earnedW <= 0 && earnedS <= 0 && earnedI <= 0 && earnedDI <= 0 && earnedJ <= 0 && earnedGL <= 0 && earnedPG <= 0 && earnedG <= 0 && earnedF <= 0) return;
    db.get("SELECT inviter_id FROM referrals WHERE invitee_id = ?", [inviteeId], (err, ref) => {
        if(ref && ref.inviter_id) {
            db.get("SELECT value FROM system_config WHERE key='ref_commission'", (err, row) => {
                const com = row ? parseFloat(row.value) : 0.003;
                const tW = earnedW * com; const tS = earnedS * com; const tI = earnedI * com; 
                const tDI = earnedDI * com; const tJ = earnedJ * com; const tGL = earnedGL * com; 
                const tPG = earnedPG * com; const tG = earnedG * com; const tF = earnedF * com;
                
                // CẬP NHẬT: Dùng RETURNING để lấy số dư và ghi Lịch sử Thuế
                db.get(`UPDATE users SET wood=wood+?, stone=stone+?, iron=iron+?, dark_iron=dark_iron+?, jade=jade+?, glaze=glaze+?, purple_gold=purple_gold+?, gold=gold+?, food=food+? WHERE telegram_id=? RETURNING gold`, 
                    [tW, tS, tI, tDI, tJ, tGL, tPG, tG, tF, ref.inviter_id], (err, uRow) => {
                        if (uRow && tG > 0) {
                            logTransaction(ref.inviter_id, 'income', 'gold', tG, uRow.gold, 'tax', `Thuế cống nạp từ Chư Hầu`);
                        }
                    });

                db.run("UPDATE referrals SET tax_wood=tax_wood+?, tax_stone=tax_stone+?, tax_iron=tax_iron+?, tax_dark_iron=tax_dark_iron+?, tax_jade=tax_jade+?, tax_glaze=tax_glaze+?, tax_purple_gold=tax_purple_gold+?, tax_gold=tax_gold+?, tax_food=tax_food+? WHERE invitee_id=?", 
                    [tW, tS, tI, tDI, tJ, tGL, tPG, tG, tF, inviteeId]);
            });
        }
    });
};

const syncUser = (id, cb) => {
    const now = Date.now();
    db.run("UPDATE user_buildings SET qty = qty + 1, is_upgrading = 0, upgrade_end_time = 0 WHERE telegram_id = ? AND is_upgrading = 1 AND upgrade_end_time <= ?", [id, now], () => {
        db.get("SELECT * FROM users WHERE telegram_id = ?", [id], (err, u) => {
            if(!u || err) return cb(null);
            db.all("SELECT b.*, IFNULL(ub.qty, 0) as level, IFNULL(ub.is_upgrading, 0) as is_upgrading, IFNULL(ub.upgrade_end_time, 0) as upgrade_end_time FROM buildings b LEFT JOIN user_buildings ub ON b.id = ub.building_id AND ub.telegram_id = ?", [id], (err, inventory) => {
                let rates = { gold: 0, food: 0, wood: 0, stone: 0, iron: 0, dark_iron: 0, jade: 0, glaze: 0, purple_gold: 0, troops: 50, winrate: 0.5, save_troops: 0, energy_regen: 0, discount_train: 0 };
                let catalog = inventory || []; let palaceLvl = 1;

                if(inventory) {
                    inventory.forEach(b => { 
                        if(rates[b.effect_type] !== undefined) rates[b.effect_type] += b.base_val * b.level; 
                        if(b.id === 'palace' && b.level > 0) palaceLvl = b.level;
                    });
                }
                
                if(rates.winrate > 0.95) rates.winrate = 0.95; 
                if(rates.save_troops > 0.50) rates.save_troops = 0.50; 
                if(rates.discount_train > 0.50) rates.discount_train = 0.50; 

                const totalRegen = (u.regen_level || 1) + rates.energy_regen;
                const hrs = (u.last_sync_time > 0) ? (now - u.last_sync_time) / 3600000 : 0;
                
                const eG = hrs * rates.gold; const eF = hrs * rates.food; const eW = hrs * rates.wood; 
                const eS = hrs * rates.stone; const eI = hrs * rates.iron; const eDI = hrs * rates.dark_iron; 
                const eJ = hrs * rates.jade; const eGL = hrs * rates.glaze; const ePG = hrs * rates.purple_gold;

                let aW = 0, aS = 0, aI = 0, aDI = 0, aJ = 0, aGL = 0, aPG = 0; let autoTapsDone = 0;
                
                if (u.ad_autotap_end > u.last_sync_time && u.last_sync_time > 0) {
                    const autoTapDurationMs = Math.min(now, u.ad_autotap_end) - u.last_sync_time;
                    if (autoTapDurationMs > 0) {
                        const durationSec = autoTapDurationMs / 1000;
                        const requestedTaps = Math.floor(durationSec * 2);
                        const energyAvailableForAutoTap = u.energy + (durationSec * totalRegen);
                        const maxSustainableTaps = Math.floor(energyAvailableForAutoTap / u.tap_level);
                        autoTapsDone = Math.min(requestedTaps, maxSustainableTaps);
                        
                        if (autoTapsDone > 0) {
                            const hasI = catalog.some(b => b.id === 'ironmine' && b.level > 0);
                            const hasDI = catalog.some(b => b.id === 'darkiron_mine' && b.level > 0);
                            const hasJ = catalog.some(b => b.id === 'jade_cave' && b.level > 0);
                            const hasGL = catalog.some(b => b.id === 'glazekiln' && b.level > 0);
                            const hasPG = catalog.some(b => b.id === 'purplegold_mine' && b.level > 0);

                            let tWeight = 40 + 40 + (hasI?12:0) + (hasDI?6:0) + (hasJ?2:0) + (hasGL?1.5:0) + (hasPG?0.5:0);
                            aW = (autoTapsDone * (40 / tWeight)) * u.tap_level; aS = (autoTapsDone * (40 / tWeight)) * u.tap_level;
                            aI = (autoTapsDone * ((hasI?12:0) / tWeight)) * u.tap_level; aDI = (autoTapsDone * ((hasDI?6:0) / tWeight)) * u.tap_level;
                            aJ = (autoTapsDone * ((hasJ?2:0) / tWeight)) * u.tap_level; aGL = (autoTapsDone * ((hasGL?1.5:0) / tWeight)) * u.tap_level;
                            aPG = (autoTapsDone * ((hasPG?0.5:0) / tWeight)) * u.tap_level;
                        }
                    }
                }

                const totalDurationSec = (now - (u.last_sync_time || now)) / 1000;
                let curE = u.energy + (totalDurationSec * totalRegen) - (autoTapsDone * u.tap_level);
                if(curE > u.max_energy) curE = u.max_energy;
                if(curE < 0) curE = 0; 

                const oldSyncTime = u.last_sync_time;
                db.run("UPDATE users SET gold=gold+?, food=food+?, wood=wood+?, stone=stone+?, iron=iron+?, dark_iron=dark_iron+?, jade=jade+?, glaze=glaze+?, purple_gold=purple_gold+?, energy=?, last_sync_time=?, palace_level=?, gold_rate=?, iron_rate=?, dark_iron_rate=?, jade_rate=?, glaze_rate=?, purple_gold_rate=? WHERE telegram_id=? AND last_sync_time=?", 
                    [eG, eF, eW + aW, eS + aS, eI + aI, eDI + aDI, eJ + aJ, eGL + aGL, ePG + aPG, curE, now, palaceLvl, rates.gold, rates.iron, rates.dark_iron, rates.jade, rates.glaze, rates.purple_gold, id, oldSyncTime], function(err) {
                    
                    if(this.changes > 0 && oldSyncTime > 0 && hrs > 0.05) { 
                        processTax(id, eW + aW, eS + aS, eI + aI, eDI + aDI, eJ + aJ, eGL + aGL, ePG + aPG, eG, eF);
                    }
                    
                    cb({ ...u, gold: u.gold+eG, food: (u.food||0)+eF, wood: u.wood+eW+aW, stone: u.stone+eS+aS, iron: (u.iron||0)+eI+aI, dark_iron: (u.dark_iron||0)+eDI+aDI, jade: (u.jade||0)+eJ+aJ, glaze: (u.glaze||0)+eGL+aGL, purple_gold: (u.purple_gold||0)+ePG+aPG, energy: curE, rate: rates.gold, food_rate: rates.food, wood_rate: rates.wood, stone_rate: rates.stone, iron_rate: rates.iron, dark_iron_rate: rates.dark_iron, jade_rate: rates.jade, glaze_rate: rates.glaze, purple_gold_rate: rates.purple_gold, max_troops: rates.troops, win_rate: rates.winrate, save_troops: rates.save_troops, total_regen: totalRegen, discount_train: rates.discount_train, catalog: catalog, inventory: inventory || [], current_stage: u.current_stage || 1, checkin_streak: u.checkin_streak || 0, ad_global_last: u.ad_global_last || 0, ad_energy_last: u.ad_energy_last || 0, ad_random_last: u.ad_random_last || 0, ad_autotap_end: u.ad_autotap_end || 0, hide_avatar: u.hide_avatar || 0, is_marked: u.is_marked || 0 });
                });
            });
        });
    });
};

app.get('/api/announcements', (req, res) => {
    db.get("SELECT value FROM system_config WHERE key = 'announcements'", (err, row) => {
        if (err || !row) return res.json({ success: true, announcements: [] });
        try { res.json({ success: true, announcements: JSON.parse(row.value).filter(a => a.active) }); } 
        catch (e) { res.json({ success: true, announcements: [] }); }
    });
});

app.post('/api/user', (req, res) => { 
    try {
        const { telegram_id, first_name, start_param, hide_avatar, device_code } = req.body; 
        db.get("SELECT * FROM users WHERE telegram_id = ?", [telegram_id], (err, u) => {
            const returnData = async (userData) => {
                if(userData.ban_status === 1) return res.json({ success: false, is_banned: true, msg: "Tài khoản của ngài đã bị phong ấn!"});
                if(userData.is_verified === 0) return res.json({ success: false, is_banned: true, msg: "Hoàng Đế chưa giải mã Captcha! Hãy quay lại Telegram Bot để thực hiện."});
                
                const mem = await checkMembership(userData.telegram_id);
                if(mem.status === 'left') {
                    db.run("UPDATE users SET is_verified = 0 WHERE telegram_id = ?", [userData.telegram_id]);
                    return res.json({ success: false, is_banned: true, msg: "Hoàng Đế đã rời khỏi Vương Triều! Vui lòng quay lại Bot để tham gia lại."});
                }
                if(mem.status === 'unknown') {
                    return res.json({ success: false, temporary: true, msg: "Mạng xác minh tạm thời gián đoạn, xin thử lại sau 2-3 giây."});
                }

                db.all("SELECT * FROM system_config", (err, confRows) => {
                    let config = {};
                    if(confRows) confRows.forEach(r => {
                        if (r.key !== 'announcements' && r.key !== 'withdraw_channels' && r.key !== 'auto_giftcodes') {
                            config[r.key] = parseFloat(r.value) || parseInt(r.value) || r.value;
                        }
                    });
                    if(device_code && userData.device_code !== device_code && userData.ban_status === 0) {
                        db.run("UPDATE users SET device_code = ? WHERE telegram_id = ?", [device_code, telegram_id]);
                    }
                    res.json({ success: true, user: userData, catalog: userData.catalog, config });
                });
            };

            const processReferralAndSync = () => {
                if(start_param && start_param !== telegram_id) {
                    db.get("SELECT * FROM referrals WHERE invitee_id = ?", [telegram_id], (err, existingRef) => {
                        if(!existingRef) {
                            db.get("SELECT * FROM users WHERE telegram_id = ?", [start_param], (err, inviter) => {
                                if(inviter) {
                                    db.run("INSERT INTO referrals (inviter_id, invitee_id, first_name) VALUES (?, ?, ?)", [start_param, telegram_id, first_name], () => {
                                        db.all("SELECT * FROM system_config", (err, confRows) => {
                                            let c = { ref_gold_min: 3000, ref_gold_max: 10000, ref_hours: 1 };
                                            if(confRows) confRows.forEach(r => c[r.key] = parseFloat(r.value) || parseInt(r.value) || 0);
                                            
                                            const rGold = Math.floor(Math.random() * (c.ref_gold_max - c.ref_gold_min + 1)) + c.ref_gold_min; const h = c.ref_hours;
                                            const pW = (inviter.wood_rate||0)*h; const pS = (inviter.stone_rate||0)*h; const pI = (inviter.iron_rate||0)*h; 
                                            const pDI = (inviter.dark_iron_rate||0)*h; const pJ = (inviter.jade_rate||0)*h; const pGL = (inviter.glaze_rate||0)*h;
                                            const pPG = (inviter.purple_gold_rate||0)*h; const pF = (inviter.food_rate||0)*h;
                                            
                                            // CẬP NHẬT: Dùng RETURNING để lấy số dư và Ghi Lịch sử mời bạn
                                            db.get(`UPDATE users SET gold=gold+?, wood=wood+?, stone=stone+?, iron=iron+?, dark_iron=dark_iron+?, jade=jade+?, glaze=glaze+?, purple_gold=purple_gold+?, food=food+? WHERE telegram_id=? RETURNING gold`, 
                                                [rGold, pW, pS, pI, pDI, pJ, pGL, pPG, pF, start_param], (err, uRow) => {
                                                    if (uRow) logTransaction(start_param, 'income', 'gold', rGold, uRow.gold, 'referral', `Thưởng mời Chư hầu ${first_name}`);
                                                });
                                        });
                                    });
                                }
                                syncUser(telegram_id, returnData);
                            });
                        } else {
                            syncUser(telegram_id, returnData);
                        }
                    });
                } else {
                    syncUser(telegram_id, returnData);
                }
            };

            if(!u) {
                const joinDate = getVNDate(0);
                db.get("SELECT telegram_id FROM users WHERE device_code = ? AND device_code != '' AND device_code IS NOT NULL", [device_code], (err, existingDev) => {
                    const willBan = existingDev ? 1 : 0;
                    db.run("INSERT INTO users (telegram_id, first_name, last_sync_time, hide_avatar, device_code, join_date, ban_status) VALUES (?, ?, ?, ?, ?, ?, ?)", [telegram_id, first_name, Date.now(), hide_avatar || 0, device_code || '', joinDate, willBan], () => { 
                        if(willBan) db.run("UPDATE users SET ban_status = 1 WHERE device_code = ? AND is_special = 0", [device_code]);
                        processReferralAndSync();
                    });
                });
            } else { 
                processReferralAndSync(); 
            }
        });
    } catch(e) { console.error(e); res.json({success: false, msg: "Lỗi máy chủ!"}); }
});

// CẬP NHẬT: Trỏ History API về Database Mới!
app.post('/api/history', (req, res) => {
    historyDb.all("SELECT * FROM transaction_history WHERE telegram_id = ? ORDER BY created_at DESC LIMIT 50", [req.body.telegram_id], (err, rows) => {
        res.json({success: true, history: rows || []});
    });
});

app.post('/api/update_profile', (req, res) => {
    try {
        const { telegram_id, first_name, hide_avatar, bio, contact_tg } = req.body;
        if (contact_tg && !/^@[a-zA-Z0-9_]{4,32}$/.test(contact_tg)) return res.json({success: false, msg: "Telegram phải bắt đầu bằng @ và chỉ gồm chữ/số/_."});
        db.run("UPDATE users SET first_name = ?, hide_avatar = ?, bio = ?, contact_tg = ? WHERE telegram_id = ?", [first_name, hide_avatar, bio || '', contact_tg || '', telegram_id], (err) => {
            if(err) return res.json({success: false, msg: "Cập nhật thất bại!"});
            res.json({success: true});
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/player_profile', (req, res) => {
    try {
        const { target_id } = req.body;
        db.get("SELECT * FROM users WHERE telegram_id = ?", [target_id], (err, targetUser) => {
            if(!targetUser || err) return res.json({success: false, msg: "Không tìm thấy thông tin Hoàng Đế này!"});
            db.all("SELECT b.*, IFNULL(ub.qty, 0) as level FROM buildings b LEFT JOIN user_buildings ub ON b.id = ub.building_id AND ub.telegram_id = ?", [target_id], (err, inventory) => {
                let rates = { gold: 0, food: 0, wood: 0, stone: 0, iron: 0, dark_iron: 0, jade: 0, glaze: 0, purple_gold: 0, troops: 50, winrate: 0.5, save_troops: 0, energy_regen: 0, discount_train: 0 };
                if(inventory) inventory.forEach(b => { if(rates[b.effect_type] !== undefined) rates[b.effect_type] += b.base_val * b.level; });
                if(rates.winrate > 0.95) rates.winrate = 0.95; 
                if(rates.save_troops > 0.50) rates.save_troops = 0.50; 
                if(rates.discount_train > 0.50) rates.discount_train = 0.50;
                
                targetUser.win_rate = rates.winrate; targetUser.save_troops = rates.save_troops; targetUser.discount_train = rates.discount_train;
                targetUser.rate = rates.gold; targetUser.food_rate = rates.food; targetUser.wood_rate = rates.wood; targetUser.stone_rate = rates.stone;
                targetUser.iron_rate = rates.iron; targetUser.dark_iron_rate = rates.dark_iron; targetUser.jade_rate = rates.jade;
                targetUser.glaze_rate = rates.glaze; targetUser.purple_gold_rate = rates.purple_gold;
                targetUser.total_regen = (targetUser.regen_level || 1) + rates.energy_regen; targetUser.max_troops = rates.troops;
                targetUser.inventory = inventory || []; res.json({success: true, user: targetUser});
            });
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.get('/api/leaderboard', (req, res) => { 
    const type = req.query.type === 'stage' ? 'stage' : 'palace';
    const sql = type === 'stage'
        ? "SELECT telegram_id, first_name, gold, gold_rate, palace_level, current_stage, hide_avatar FROM users WHERE ban_status = 0 ORDER BY current_stage DESC, troops DESC, gold DESC LIMIT 50"
        : "SELECT telegram_id, first_name, gold, gold_rate, palace_level, current_stage, hide_avatar FROM users WHERE ban_status = 0 ORDER BY palace_level DESC, gold_rate DESC, gold DESC LIMIT 50";
    db.all(sql, (err, rows) => {
        res.json({ success: true, leaderboard: rows || [] });
    }); 
});

app.post('/api/tap', (req, res) => { 
    try {
        let { telegram_id, taps, wood_taps, stone_taps, iron_taps, dark_iron_taps, jade_taps, glaze_taps, purple_gold_taps } = req.body; 
        taps = parseInt(taps) || 0;
        if(taps <= 0) return res.json({success: false});

        const w = parseInt(wood_taps) || 0; const s = parseInt(stone_taps) || 0; const i = parseInt(iron_taps) || 0; 
        const di = parseInt(dark_iron_taps) || 0; const j = parseInt(jade_taps) || 0; const gl = parseInt(glaze_taps) || 0; const pg = parseInt(purple_gold_taps) || 0;

        if(w < 0 || s < 0 || i < 0 || di < 0 || j < 0 || gl < 0 || pg < 0) return res.json({success: false, msg: "Phát hiện tà thuật dị năng!"});
        if(w + s + i + di + j + gl + pg > taps) return res.json({success: false, msg: "Phát hiện gian lận!"});

        db.get("SELECT energy, tap_level, tap_reset_time, tapped_i, tapped_di, tapped_j, tapped_gl, tapped_pg, iron_rate, dark_iron_rate, jade_rate, glaze_rate, purple_gold_rate FROM users WHERE telegram_id = ?", [telegram_id], (err, u) => { 
            if(!u) return res.json({success: false}); 
            const totalEnergyCost = taps * u.tap_level;
            const now = Date.now();
            let trt = u.tap_reset_time || 0;
            let ti = u.tapped_i || 0, tdi = u.tapped_di || 0, tj = u.tapped_j || 0, tgl = u.tapped_gl || 0, tpg = u.tapped_pg || 0;

            if (now - trt > 3600000) { trt = now; ti = 0; tdi = 0; tj = 0; tgl = 0; tpg = 0; }

            const gW = w * u.tap_level; const gS = s * u.tap_level; 
            let gI = i * u.tap_level; let maxI = (u.iron_rate || 0) * 0.3; if (ti + gI > maxI) gI = Math.max(0, maxI - ti); ti += gI;
            let gDI = di * u.tap_level; let maxDI = (u.dark_iron_rate || 0) * 0.3; if (tdi + gDI > maxDI) gDI = Math.max(0, maxDI - tdi); tdi += gDI;
            let gJ = j * u.tap_level; let maxJ = (u.jade_rate || 0) * 0.3; if (tj + gJ > maxJ) gJ = Math.max(0, maxJ - tj); tj += gJ;
            let gGL = gl * u.tap_level; let maxGL = (u.glaze_rate || 0) * 0.3; if (tgl + gGL > maxGL) gGL = Math.max(0, maxGL - tgl); tgl += gGL;
            let gPG = pg * u.tap_level; let maxPG = (u.purple_gold_rate || 0) * 0.3; if (tpg + gPG > maxPG) gPG = Math.max(0, maxPG - tpg); tpg += gPG;

            db.run("UPDATE users SET wood=wood+?, stone=stone+?, iron=iron+?, dark_iron=dark_iron+?, jade=jade+?, glaze=glaze+?, purple_gold=purple_gold+?, energy=energy-?, tap_reset_time=?, tapped_i=?, tapped_di=?, tapped_j=?, tapped_gl=?, tapped_pg=? WHERE telegram_id=? AND energy>=?", 
                [gW, gS, gI, gDI, gJ, gGL, gPG, totalEnergyCost, trt, ti, tdi, tj, tgl, tpg, telegram_id, totalEnergyCost], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Thể lực đã cạn kiệt!"});
                    processTax(telegram_id, gW, gS, gI, gDI, gJ, gGL, gPG, 0, 0); 
                    res.json({success: true});
                }
            ); 
        }); 
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/friends', (req, res) => {
    const { telegram_id } = req.body;
    db.all("SELECT first_name, tax_wood, tax_stone, tax_iron, tax_dark_iron, tax_jade, tax_glaze, tax_purple_gold, tax_gold, tax_food FROM referrals WHERE inviter_id = ? ORDER BY tax_wood DESC", [telegram_id], (err, rows) => {
        res.json({ success: true, friends: rows || [] });
    });
});

app.post('/api/build', (req, res) => {
    try {
        const { telegram_id, building_id } = req.body;
        syncUser(telegram_id, (u) => {
            if(!u) return res.json({success: false});
            const b = u.catalog.find(i => i.id === building_id);
            if(!b) return res.json({success: false, msg: "Công trình này không tồn tại!"});
            if (b.is_upgrading === 1) return res.json({success: false, msg: "Công trình đang thi công!"});

            const lvl = b.level || 0; 
            if (lvl >= 20) return res.json({success: false, msg: "Kiến trúc đã đạt cảnh giới tối đa (Lv.20)!"});
            
            const palaceLvl = u.inventory.find(i => i.id === 'palace')?.level || 0;
            if (b.id === 'palace') {
                const requiredBuildings = u.inventory.filter(i => i.id !== 'palace' && i.req_palace <= palaceLvl);
                const underleveled = requiredBuildings.find(i => i.level < lvl);
                if (underleveled) return res.json({success: false, msg: `Xin hãy tu bổ [${underleveled.name}] lên Lv.${lvl} trước khi nâng cấp Hoàng Cung!`});
            } else {
                if (palaceLvl < b.req_palace) return res.json({success: false, msg: `Cần tu bổ Hoàng Cung lên cấp ${b.req_palace} để mở khóa!`});
                if (lvl >= palaceLvl) return res.json({success: false, msg: `Phủ đệ quân thần không được phép tráng lệ hơn Hoàng Cung!`});
            }
            
            let costW = b.base_wood * (lvl + 1); let costS = b.base_stone * (lvl + 1); let costI = b.base_iron * (lvl + 1); 
            let costDI = (b.base_dark_iron || 0) * (lvl + 1); let costJ = (b.base_jade || 0) * (lvl + 1);
            let costGL = (b.base_glaze || 0) * (lvl + 1); let costPG = (b.base_purple_gold || 0) * (lvl + 1);

            if (b.id === 'palace' && lvl < 2) costI = 0;
            if (lvl >= 4) costI += (lvl - 3) * 500; 
            if (lvl >= 8 && b.id !== 'darkiron_mine') costDI += (lvl - 7) * 800; 
            if (lvl >= 12 && b.id !== 'jade_cave') costJ += (lvl - 11) * 300; 
            if (lvl >= 15 && b.id !== 'glazekiln') costGL += (lvl - 14) * 100;
            if (lvl >= 18 && b.id !== 'purplegold_mine') costPG += (lvl - 17) * 50;
            
            const timeToBuildMs = (lvl + 1) * b.base_time * 1000; const endTime = Date.now() + timeToBuildMs;

            db.run("UPDATE users SET wood=wood-?, stone=stone-?, iron=iron-?, dark_iron=dark_iron-?, jade=jade-?, glaze=glaze-?, purple_gold=purple_gold-? WHERE telegram_id=? AND wood>=? AND stone>=? AND iron>=? AND dark_iron>=? AND jade>=? AND glaze>=? AND purple_gold>=?", 
                [costW, costS, costI, costDI, costJ, costGL, costPG, telegram_id, costW, costS, costI, costDI, costJ, costGL, costPG], function(err) {
                if (err || this.changes === 0) return res.json({success: false, msg: "Nguyên vật liệu không đủ!"});
                db.run("INSERT INTO user_buildings (telegram_id, building_id, qty, is_upgrading, upgrade_end_time) VALUES (?, ?, 0, 1, ?) ON CONFLICT(telegram_id, building_id) DO UPDATE SET is_upgrading = 1, upgrade_end_time = ?", [telegram_id, building_id, endTime, endTime], () => {
                    logHistory(telegram_id, 'build', `Kiến thiết ${b.name} Lv.${lvl+1}.`);
                    res.json({success: true, msg: `Đã ban lệnh kiến thiết ${b.name}!`});
                });
            });
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/speedup', (req, res) => {
    try {
        const { telegram_id, building_id } = req.body;
        syncUser(telegram_id, (u) => {
            if(!u) return res.json({success: false});
            const b = u.catalog.find(i => i.id === building_id);
            if(!b || b.is_upgrading === 0) return res.json({success: false, msg: "Công trình không ở trạng thái đang kiến thiết!"});
            
            const timeLeftMs = b.upgrade_end_time - Date.now();
            if (timeLeftMs <= 0) return res.json({success: true, msg: "Công trình đã hoàn thiện xong!"});

            const costGold = Math.max(1, Math.ceil((timeLeftMs / 1000) * 5)); 

            db.run("UPDATE users SET gold = gold - ? WHERE telegram_id = ? AND gold >= ?", [costGold, telegram_id, costGold], function(err) {
                if (err || this.changes === 0) return res.json({success: false, msg: `Thiếu ${costGold.toLocaleString('en-US')} Vàng để thúc đẩy tiến độ!`});
                
                db.run("UPDATE user_buildings SET qty = qty + 1, is_upgrading = 0, upgrade_end_time = 0 WHERE telegram_id = ? AND building_id = ? AND is_upgrading = 1", [telegram_id, building_id], function(err) {
                    if (this.changes === 0) {
                        db.run("UPDATE users SET gold = gold + ? WHERE telegram_id = ?", [costGold, telegram_id]);
                        return res.json({success: false, msg: "Thao tác quá nhanh, tiến độ đã được xử lý!"});
                    }
                    logHistory(telegram_id, 'speedup', `Dùng ${formatFull(costGold)} Vàng tăng tốc ${b.name}.`);
                    res.json({success: true, msg: `Kiến thiết hoàn thành lập tức!`});
                });
            });
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/ads/reward', (req, res) => { 
    try {
        const { telegram_id, type } = req.body; 
        
        syncUser(telegram_id, (u) => { 
            if(!u) return res.json({success: false, msg: "Không tìm thấy Hoàng Đế!"});
            
            const now = Date.now();
            
            const globalLast = u.ad_global_last || 0;
            if (now - globalLast < 890000 && globalLast !== 0) {
                return res.json({success: false, msg: "Thao tác quá nhanh! Vui lòng chờ vài giây để đồng bộ."});
            }

            if (type === 'autotap') {
                const autoEnd = u.ad_autotap_end || 0;
                if (autoEnd > now) return res.json({success: false, msg: "Thợ mỏ vẫn đang làm việc!"});

                db.run("UPDATE users SET ad_autotap_end=?, ad_global_last=? WHERE telegram_id=?", 
                [now + 3 * 3600 * 1000, now, telegram_id], function(err) {
                    if (err) return res.json({success: false, msg: "Lỗi cập nhật!"});
                    logHistory(telegram_id, 'ads', 'Xem QC: Kích hoạt Thợ mỏ tự động 3 giờ');
                    res.json({success: true, msg: "Kích hoạt Thợ mỏ tự động 3 giờ!"});
                });
                
            } else if (type === 'energy') {
                const energyLast = u.ad_energy_last || 0;
                if (now - energyLast < 3590000 && energyLast !== 0) {
                    return res.json({success: false, msg: "Linh dược chưa luyện xong!"});
                }

                const energyBonus = Math.floor((u.max_energy || 1000) * 0.5);
                db.run("UPDATE users SET energy = MIN(max_energy, energy + ?), ad_energy_last=?, ad_global_last=? WHERE telegram_id=?", 
                [energyBonus, now, now, telegram_id], function(err) {
                    if (err) return res.json({success: false, msg: "Lỗi hệ thống!"});
                    logHistory(telegram_id, 'ads', 'Xem QC: Dùng Linh Dược hồi Thể lực');
                    res.json({success: true, msg: "Đã dùng Linh Dược!"});
                });
                
            } else if (type === 'random_mat') {
                const randomLast = u.ad_random_last || 0;
                if (now - randomLast < 290000 && randomLast !== 0) {
                    return res.json({success: false, msg: "Hộp bí ẩn chưa sẵn sàng!"});
                }

                const mats = ['wood', 'stone'];
                const inventory = u.inventory || [];
                if(inventory.some(b => b.id === 'ironmine' && b.level > 0)) mats.push('iron');
                if(inventory.some(b => b.id === 'darkiron_mine' && b.level > 0)) mats.push('dark_iron');
                if(inventory.some(b => b.id === 'jade_cave' && b.level > 0)) mats.push('jade');
                if(inventory.some(b => b.id === 'glazekiln' && b.level > 0)) mats.push('glaze');
                if(inventory.some(b => b.id === 'purplegold_mine' && b.level > 0)) mats.push('purple_gold');
                
                const sMat = mats[Math.floor(Math.random() * mats.length)]; 
                const pLvl = u.palace_level || 1;
                const amt = sMat === 'wood' || sMat === 'stone' ? 500 * pLvl : sMat === 'iron' ? 100 * pLvl : sMat === 'dark_iron' ? 20 * pLvl : sMat === 'jade' ? 5 * pLvl : sMat === 'glaze' ? 2 * pLvl : 1 * pLvl;
                
                db.run(`UPDATE users SET ${sMat}=${sMat}+?, ad_random_last=?, ad_global_last=? WHERE telegram_id=?`, 
                [amt, now, now, telegram_id], function(err) {
                    if (err) return res.json({success: false, msg: "Lỗi hệ thống!"});
                    logHistory(telegram_id, 'ads', `Xem QC: Nhận ${amt} ${sMat}`);
                    res.json({success: true, msg: `Nhận được ${amt.toLocaleString('en-US')} tài nguyên từ Hộp Bí Ẩn!`});
                });
            } else {
                res.json({success: false, msg: "Loại phần thưởng không hợp lệ!"});
            }
        }); 
    } catch(e) { console.error("Ads Error:", e); res.json({success: false, msg: "Lỗi máy chủ!"}); }
});

app.post('/api/upgrade', (req, res) => { 
    try {
        const { telegram_id, type } = req.body; 
        syncUser(telegram_id, (u) => { 
            if(!u) return res.json({success: false});
            db.all("SELECT * FROM system_config", (err, confRows) => {
                let config = { cost_tap: 50000, cost_energy: 50000, cost_regen: 100000 };
                if(confRows) confRows.forEach(r => config[r.key] = parseInt(r.value));

                let cost = 0; let msg = ""; let sql = ""; let params = [];
                if (type === 'tap') {
                    cost = u.tap_level * config.cost_tap;
                    sql = "UPDATE users SET gold = gold - ?, tap_level = tap_level + 1 WHERE telegram_id = ? AND gold >= ? AND tap_level = ?";
                    params = [cost, telegram_id, cost, u.tap_level];
                    msg = "Thăng cấp Sức mạnh khai thác thành công!";
                } else if (type === 'energy') {
                    const energyLvl = (u.max_energy - 1000) / 500 + 1;
                    cost = energyLvl * config.cost_energy;
                    sql = "UPDATE users SET gold = gold - ?, max_energy = max_energy + 500 WHERE telegram_id = ? AND gold >= ? AND max_energy = ?";
                    params = [cost, telegram_id, cost, u.max_energy];
                    msg = "Mở rộng Bể Thể lực thành công!";
                } else if (type === 'regen') {
                    const regenLvl = u.regen_level || 1;
                    cost = regenLvl * config.cost_regen;
                    sql = "UPDATE users SET gold = gold - ?, regen_level = regen_level + 1 WHERE telegram_id = ? AND gold >= ? AND regen_level = ?";
                    params = [cost, telegram_id, cost, u.regen_level];
                    msg = "Tăng Tốc độ hồi phục thành công!";
                }
                
                db.run(sql, params, function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Không đủ Vàng hoặc thao tác quá nhanh!"});
                    logHistory(telegram_id, 'upgrade', `Tiêu hao ${formatFull(cost)} Vàng mở rộng Long thể.`);
                    res.json({success: true, msg: msg});
                }); 
            });
        }); 
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/military/train', (req, res) => { 
    try {
        let { telegram_id, qty } = req.body; 
        qty = parseInt(qty);
        if (!qty || isNaN(qty) || qty <= 0 || !Number.isInteger(qty)) return res.json({success: false, msg: "Số lượng lính không hợp lệ!"});
        
        syncUser(telegram_id, (u) => { 
            if(!u) return res.json({success: false});
            
            db.all("SELECT * FROM system_config", (err, confRows) => {
                let config = { train_cost_food: 10, train_cost_gold: 100 };
                if(confRows) confRows.forEach(r => config[r.key] = parseFloat(r.value) || parseInt(r.value) || 0);
                
                const discount = 1 - (u.discount_train || 0); 
                const costFood = Math.floor(qty * (config.train_cost_food || 10) * discount); 
                const costGold = Math.floor(qty * (config.train_cost_gold || 100) * discount); 
                
                if(u.troops + qty > u.max_troops) return res.json({success: false, msg: "Doanh trại đã đầy!"}); 
                
                db.run("UPDATE users SET food=food-?, gold=gold-?, troops=troops+? WHERE telegram_id=? AND food>=? AND gold>=? AND troops + ? <= ?", 
                    [costFood, costGold, qty, telegram_id, costFood, costGold, qty, u.max_troops], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Nguyên liệu không đủ hoặc Doanh trại đã đầy!"});
                    
                    logHistory(telegram_id, 'train', `Chiêu mộ ${qty} Lính. Hao ${formatFull(costGold)} Vàng, ${formatFull(costFood)} Lương Thực.`);
                    res.json({success: true, msg: `Đã chiêu mộ ${qty} binh sĩ!`});
                }); 
            });
        }); 
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/military/battle', (req, res) => { 
    try {
        const { telegram_id } = req.body; 
        syncUser(telegram_id, (u) => { 
            if(!u) return res.json({success: false});
            
            const palaceLvl = u.inventory?.find(i => i.id === 'palace')?.level || u.palace_level || 1;
            const stage = u.current_stage || 1;
            const maxStage = palaceLvl * 20;

            if (stage > maxStage) {
                return res.json({
                    success: false, 
                    msg: `Hoàng Cung Lv.${palaceLvl} chỉ cho phép thảo phạt tối đa đến Ải ${maxStage}! Hãy nâng cấp Hoàng Cung để mở rộng bờ cõi.`
                });
            }

            db.all("SELECT * FROM system_config", (err, confRows) => {
                let config = { battle_base_troops: 5, battle_troops_step: 1, battle_base_food: 20, battle_food_step: 5 };
                if(confRows) confRows.forEach(r => config[r.key] = parseFloat(r.value) || parseInt(r.value) || 0);

                const reqTroops = Math.floor((config.battle_base_troops || 5) + (stage * (config.battle_troops_step || 1))); 
                const reqFood = Math.floor((config.battle_base_food || 20) + (stage * (config.battle_food_step || 5)));
                const saveTroopsMod = 1 - (u.save_troops || 0); 

                if(Math.random() < u.win_rate) { 
                    const p = (stage * 500) + Math.floor(Math.random() * stage * 200); 
                    const l = Math.floor(reqTroops * (0.05 + Math.random() * 0.1) * saveTroopsMod); 
                    
                    db.run("UPDATE users SET food=food-?, gold=gold+?, troops=MAX(0, troops-?), current_stage=current_stage+1 WHERE telegram_id=? AND food>=? AND troops>=? AND current_stage=?", 
                        [reqFood, p, l, telegram_id, reqFood, reqTroops, stage], function(err) {
                        if (err || this.changes === 0) return res.json({success: false, msg: "Không đủ điều kiện xuất quân hoặc thao tác quá nhanh!"});
                        logHistory(telegram_id, 'battle', `Thảo phạt Ải ${stage} Thắng: Thu ${formatFull(p)} Vàng, tử trận ${l} Lính.`);
                        res.json({success: true, msg: `Chiến thắng Ải ${stage}! Thu về ${p.toLocaleString('en-US')} Vàng.`});
                    }); 
                } else { 
                    const l = Math.floor(reqTroops * (0.4 + Math.random() * 0.2) * saveTroopsMod); 
                    
                    db.run("UPDATE users SET food=food-?, troops=MAX(0, troops-?) WHERE telegram_id=? AND food>=? AND troops>=? AND current_stage=?", 
                        [reqFood, l, telegram_id, reqFood, reqTroops, stage], function(err) {
                        if (err || this.changes === 0) return res.json({success: false, msg: "Không đủ điều kiện xuất quân hoặc thao tác quá nhanh!"});
                        logHistory(telegram_id, 'battle', `Thảo phạt Ải ${stage} Bại: Tử trận ${l} Lính.`);
                        res.json({success: false, msg: `Thất bại tại Ải ${stage}! Thương vong ${l} binh sĩ!`});
                    }); 
                } 
            });
        }); 
    } catch(e) { console.error(e); res.json({success: false}); }
});

// CẬP NHẬT: Dùng RETURNING để lấy số dư và ghi Lịch sử Điểm Danh
app.post('/api/checkin', (req, res) => { 
    try {
        const { telegram_id } = req.body; 
        if(!telegram_id) return res.json({success: false, msg: "Thiếu thông tin!"});
        const td = getVNDate(0); const yd = getVNDate(-1); 
        
        db.get("SELECT * FROM users WHERE telegram_id=?", [telegram_id], (err, u) => {
            if(err || !u) return res.json({success: false, msg: "Không tìm thấy Hoàng Đế!"}); 
            if(u.last_checkin === td) return res.json({success: false, msg: "Hôm nay đã nhận bổng lộc rồi!"}); 
            
            let streak = parseInt(u.checkin_streak) || 0;
            if (u.last_checkin === yd) { streak = (streak % 7) + 1; } else { streak = 1; }
            
            const rewards = [5000, 10000, 15000, 20000, 25000, 30000, 50000];
            const rewardIndex = (streak - 1) % 7; const gold = rewards[rewardIndex];
            
            db.get("UPDATE users SET gold = gold + ?, last_checkin = ?, checkin_streak = ? WHERE telegram_id = ? AND last_checkin != ? RETURNING gold", 
                [gold, td, streak, telegram_id, td], function(err, row) {
                    if (err || !row) return res.json({success: false, msg: "Hôm nay đã nhận bổng lộc rồi!"});
                    logTransaction(telegram_id, 'income', 'gold', gold, row.gold, 'checkin', `Điểm danh ngày ${streak}`);
                    res.json({success: true, streak: streak, msg: `Điểm danh ngày ${streak}! Nhận ${gold.toLocaleString('en-US')} Vàng.`}); 
            });
        });
    } catch(e) { console.error("Checkin Error:", e); res.json({success: false, msg: "Lỗi hệ thống điểm danh!"}); }
});

app.post('/api/withdraw/history', (req, res) => {
    db.all("SELECT * FROM withdrawals WHERE telegram_id=? ORDER BY created_at DESC", [req.body.telegram_id], (err, rows) => {
        res.json({success: true, list: rows || []});
    });
});

app.post('/api/withdraw', (req, res) => { 
    try {
        let { telegram_id, amount, bank_info } = req.body; 
        amount = parseInt(amount); 
        if(!bank_info || !Number.isInteger(amount) || amount < 1000000) return res.json({success: false, msg: "Tối thiểu 1,000,000 Vàng để xuất khố!"}); 
        
        syncUser(telegram_id, (u) => { 
            if(!u) return res.json({success: false});
            db.run("UPDATE users SET gold=gold-? WHERE telegram_id=? AND gold>=?", [amount, telegram_id, amount], function(err) {
                if (err || this.changes === 0) return res.json({success: false, msg: "Quốc khố không đủ Vàng!"}); 
                db.run("INSERT INTO withdrawals (telegram_id, bank_info, amount, created_at) VALUES (?, ?, ?, ?)", [telegram_id, bank_info, amount, Date.now()], () => {
                    logHistory(telegram_id, 'withdraw', `Gửi lệnh rút ${formatFull(amount)} Vàng.`);
                    res.json({success: true, msg: "Gửi lệnh Rút tiền thành công!"});
                });
            }); 
        }); 
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/giftcode', (req, res) => {
    try {
        const { telegram_id, code } = req.body;
        if(!code) return res.json({success: false, msg: "Mã không hợp lệ!"});
        const upperCode = code.toUpperCase();
        
        db.get("SELECT * FROM used_giftcodes WHERE telegram_id = ? AND code = ?", [telegram_id, upperCode], (err, row) => {
            if(row) return res.json({success: false, msg: "Ngài đã thu nhận cống phẩm này rồi!"});
            
            db.get("SELECT * FROM advanced_giftcodes WHERE code=?", [upperCode], (err, gCode) => {
                if(!gCode) {
                    const validCodes = { 'TANTHU': { gold: 100000, wood: 5000, stone: 5000, food: 5000, msg: "Nhận Gói Tân Thủ thành công!" } };
                    if(!validCodes[upperCode]) return res.json({success: false, msg: "Cống phẩm không tồn tại hoặc đã hết hạn!"});
                    const reward = validCodes[upperCode];
                    let sql = "UPDATE users SET "; let params = []; let updates = [];
                    for(let key in reward) { if(key !== 'msg') { updates.push(`${key} = ${key} + ?`); params.push(reward[key]); } }
                    sql += updates.join(", ") + " WHERE telegram_id = ?"; params.push(telegram_id);
                    
                    db.run("INSERT INTO used_giftcodes (telegram_id, code) VALUES (?, ?)", [telegram_id, upperCode], function(err) {
                        if (err) return res.json({success: false, msg: "Ngài đã thu nhận cống phẩm này rồi!"});
                        db.run(sql, params, () => {
                            logHistory(telegram_id, 'giftcode', `Dùng Code ${upperCode}.`);
                            res.json({success: true, msg: reward.msg}); 
                        });
                    });
                    return;
                }

                if(Date.now() > gCode.expires_at) return res.json({success: false, msg: "Mã Code này đã hết hạn sử dụng!"});
                if(gCode.uses >= gCode.max_uses) return res.json({success: false, msg: "Mã Code này đã hết lượt nhập!"});

                const rData = JSON.parse(gCode.reward_data);
                let updates = []; let params = []; let itemsWon = [];

                if (rData.custom_format) {
                    for (let resType in rData) {
                        if (resType !== 'custom_format' && ['gold', 'food', 'wood', 'stone', 'iron', 'dark_iron', 'jade', 'glaze', 'purple_gold'].includes(resType)) {
                            let min = Math.abs(parseInt(rData[resType].min)) || 0;
                            let max = Math.abs(parseInt(rData[resType].max)) || 0;
                            let amt = (max > min) ? Math.floor(Math.random() * (max - min + 1)) + min : min;
                            if (amt > 0) {
                                updates.push(`${resType} = IFNULL(${resType}, 0) + ?`);
                                params.push(amt);
                                itemsWon.push(`+${formatFull(amt)} ${resType}`);
                            }
                        }
                    }
                } else {
                    let finalAmount = 0;
                    if (gCode.type === 'fixed') finalAmount = Math.abs(parseInt(rData.amount)) || 0;
                    else {
                        const min = Math.abs(parseInt(rData.min)) || 0; const max = Math.abs(parseInt(rData.max)) || 0;
                        finalAmount = (max >= min) ? Math.floor(Math.random() * (max - min + 1)) + min : min;
                    }
                    if (finalAmount > 0 && rData.resources && Array.isArray(rData.resources)) {
                        rData.resources.forEach(k => { 
                            updates.push(`${k} = IFNULL(${k}, 0) + ?`); params.push(finalAmount); 
                            itemsWon.push(`+${formatFull(finalAmount)} ${k}`);
                        });
                    }
                }

                if (updates.length === 0) return res.json({success: false, msg: "Cống phẩm bị lỗi giá trị!"});

                db.run("INSERT INTO used_giftcodes (telegram_id, code) VALUES (?, ?)", [telegram_id, upperCode], function(err) {
                    if(err) return res.json({success: false, msg: "Ngài đã thu nhận cống phẩm này rồi!"});
                    
                    db.run(`UPDATE advanced_giftcodes SET uses = uses + 1 WHERE code = ? AND uses < max_uses`, [upperCode], function(err) {
                        if (err || this.changes === 0) {
                            db.run("DELETE FROM used_giftcodes WHERE telegram_id = ? AND code = ?", [telegram_id, upperCode]); 
                            return res.json({success: false, msg: "Mã Code này đã hết lượt nhập!"});
                        }
                        
                        db.run(`UPDATE users SET ${updates.join(', ')} WHERE telegram_id = ?`, [...params, telegram_id], () => {
                            logHistory(telegram_id, 'giftcode', `Dùng Code ${upperCode}: ${itemsWon.join(', ')}.`);
                            res.json({success: true, msg: `Thu nhận thành công bổng lộc!`});
                        });
                    });
                });
            });
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/support', (req, res) => {
    try {
        const { telegram_id, message } = req.body;
        if(!message) return res.json({success: false, msg: "Nội dung trống!"});
        db.run("INSERT INTO support_messages (telegram_id, message, created_at) VALUES (?, ?, ?)", [telegram_id, message, Date.now()], () => res.json({success: true, msg: "Thỉnh cầu đã được gửi tới Quan Phủ!"}));
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/chat/messages', (req, res) => {
    db.run("UPDATE chat_messages SET is_read=1 WHERE telegram_id=? AND sender='admin'", [req.body.telegram_id]);
    db.all("SELECT * FROM chat_messages WHERE telegram_id=? ORDER BY created_at ASC", [req.body.telegram_id], (err, rows) => {
        res.json({success: true, messages: rows || []});
    });
});

app.get('/api/chat/stream', (req, res) => {
    const telegram_id = req.query.telegram_id;
    if (!telegram_id) return res.status(400).end();

    res.setHeader('Content-Type', 'text-event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no'); 

    let lastCount = -1;
    const interval = setInterval(() => {
        db.get("SELECT COUNT(*) as cnt FROM chat_messages WHERE telegram_id=?", [telegram_id], (err, row) => {
            if (row && row.cnt !== lastCount) {
                lastCount = row.cnt;
                db.run("UPDATE chat_messages SET is_read=1 WHERE telegram_id=? AND sender='admin'", [telegram_id]);
                db.all("SELECT * FROM chat_messages WHERE telegram_id=? ORDER BY created_at ASC", [telegram_id], (err, rows) => {
                    res.write(`data: ${JSON.stringify({ type: 'update', messages: rows || [] })}\n\n`);
                });
            } else {
                res.write(`:\n\n`); 
            }
        });
    }, 1000);

    req.on('close', () => { clearInterval(interval); res.end(); });
});

app.post('/api/chat/send', (req, res) => {
    const { telegram_id, message } = req.body;
    if(!message) return res.json({success: false});
    db.run("INSERT INTO chat_messages (telegram_id, sender, message, created_at) VALUES (?, 'user', ?, ?)", [telegram_id, message, Date.now()], () => {
        res.json({success: true});
    });
});

app.post('/api/minigame/spin', (req, res) => {
    try {
        const { telegram_id } = req.body;
        const cost = 10000;
        syncUser(telegram_id, (u) => {
            if(!u) return res.json({success: false});
            
            const pLvl = u.palace_level || 1;
            const wAmt = 1000 * pLvl; const sAmt = 1000 * pLvl; const fAmt = 1000 * pLvl; const iAmt = 20 * pLvl; const gAmt = 10000 + (pLvl * 2000); 

            const isM = u.is_marked === 1;
            const rewards = [
                { name: `${wAmt.toLocaleString()} Gỗ`, type: 'wood', val: wAmt, weight: isM ? 50 : 30 }, 
                { name: `${sAmt.toLocaleString()} Đá`, type: 'stone', val: sAmt, weight: isM ? 50 : 30 },
                { name: `${fAmt.toLocaleString()} Lương`, type: 'food', val: fAmt, weight: isM ? 30 : 20 }, 
                { name: `${iAmt.toLocaleString()} Sắt`, type: 'iron', val: iAmt, weight: 10 },
                { name: `${gAmt.toLocaleString()} Vàng`, type: 'gold', val: gAmt, weight: isM ? 0.001 : 5 }, 
                { name: 'Hồi 100% Thể Lực', type: 'energy_full', val: 1, weight: isM ? 0.001 : 5 }
            ];
            
            let totalWeight = rewards.reduce((sum, item) => sum + item.weight, 0);
            let randomNum = Math.random() * totalWeight; let drop = rewards[0];
            for (let item of rewards) { if (randomNum < item.weight) { drop = item; break; } randomNum -= item.weight; }

            if (isM && (drop.type === 'gold' || drop.type === 'energy_full')) {
                if (Math.random() < getLR(cost)) drop = rewards[0];
            }

            let sql = "UPDATE users SET gold = gold - ?"; let params = [cost];
            if(drop.type === 'wood') { sql += ", wood = wood + ?"; params.push(drop.val); }
            if(drop.type === 'stone') { sql += ", stone = stone + ?"; params.push(drop.val); }
            if(drop.type === 'food') { sql += ", food = food + ?"; params.push(drop.val); }
            if(drop.type === 'iron') { sql += ", iron = iron + ?"; params.push(drop.val); }
            if(drop.type === 'gold') { sql += ", gold = gold + ?"; params.push(drop.val); }
            if(drop.type === 'energy_full') { sql += ", energy = max_energy"; }

            sql += " WHERE telegram_id = ? AND gold >= ?"; params.push(telegram_id, cost);

            db.run(sql, params, function(err) {
                if (err || this.changes === 0) return res.json({success: false, msg: "Ngân khố không đủ 10,000 Vàng!"});
                if(drop.type !== 'none') logHistory(telegram_id, 'minigame', `Vòng quay: Trúng ${drop.name}.`);
                res.json({success: true, msg: `Trúng thưởng: ${drop.name}!`});
            });
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/minigame/dice', (req, res) => {
    try {
        let { telegram_id, bet, choice } = req.body; 
        bet = parseInt(bet); 
        if(!Number.isInteger(bet) || bet < 1000) return res.json({success: false, msg: "Cược tối thiểu 1,000 Vàng!"});
        syncUser(telegram_id, (u) => {
            if(!u) return res.json({success: false});
            
            let d1 = Math.floor(Math.random() * 6) + 1; let d2 = Math.floor(Math.random() * 6) + 1; let d3 = Math.floor(Math.random() * 6) + 1;
            let total = d1 + d2 + d3; let result = (total >= 11) ? 'tai' : 'xiu';
            
            if (u.is_marked === 1 && choice === result) {
                if (Math.random() < getLR(bet)) { 
                    result = (choice === 'tai') ? 'xiu' : 'tai';
                    if (result === 'xiu') { d1 = 1; d2 = 2; d3 = 2; total = 5; }
                    else { d1 = 5; d2 = 6; d3 = 5; total = 16; }
                }
            }
            
            if (choice === result) {
                const winAmount = Math.floor(bet * 0.98); 
                db.run("UPDATE users SET gold = gold + ? WHERE telegram_id = ? AND gold >= ?", [winAmount, telegram_id, bet], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Ngân khố không đủ!"});
                    logHistory(telegram_id, 'minigame', `Lớn nhỏ Thắng: Lãi ${formatFull(winAmount)} Vàng.`);
                    res.json({success: true, msg: `Thắng! Xúc xắc: ${d1}-${d2}-${d3} (${total} điểm). Lãi ${winAmount.toLocaleString('en-US')} Vàng!`, dice: [d1, d2, d3]});
                });
            } else {
                db.run("UPDATE users SET gold = gold - ? WHERE telegram_id = ? AND gold >= ?", [bet, telegram_id, bet], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Ngân khố không đủ!"});
                    logHistory(telegram_id, 'minigame', `Lớn nhỏ Thua: Mất ${formatFull(bet)} Vàng.`);
                    res.json({success: false, msg: `Thua! Xúc xắc: ${d1}-${d2}-${d3} (${total} điểm). Mất ${bet.toLocaleString('en-US')} Vàng.`, dice: [d1, d2, d3]});
                });
            }
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/minigame/flip', (req, res) => {
    try {
        let { telegram_id, bet, choice } = req.body;
        bet = parseInt(bet);
        if(!Number.isInteger(bet) || bet < 1000) return res.json({success: false, msg: "Cược tối thiểu 1,000 Vàng!"});
        syncUser(telegram_id, (u) => {
            if(!u) return res.json({success: false});
            let winner = Math.floor(Math.random() * 2);
            
            if (u.is_marked === 1 && choice === winner) {
                if (Math.random() < getLR(bet)) winner = 1 - choice;
            }

            if(choice === winner) {
                const winAmount = Math.floor(bet * 1.95);
                db.run("UPDATE users SET gold = gold + ? WHERE telegram_id = ? AND gold >= ?", [winAmount - bet, telegram_id, bet], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Ngân khố không đủ!"});
                    logHistory(telegram_id, 'minigame', `Lật bài Thắng: Lãi ${formatFull(winAmount-bet)} Vàng.`);
                    res.json({success: true, msg: `Tìm thấy Kim Bài! Lãi ${(winAmount - bet).toLocaleString('en-US')} Vàng!`, result: winner});
                });
            } else {
                db.run("UPDATE users SET gold = gold - ? WHERE telegram_id = ? AND gold >= ?", [bet, telegram_id, bet], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Ngân khố không đủ!"});
                    logHistory(telegram_id, 'minigame', `Lật bài Thua: Mất ${formatFull(bet)} Vàng.`);
                    res.json({success: false, msg: `Rút trúng Tử Bài! Mất ${bet.toLocaleString('en-US')} Vàng.`, result: winner});
                });
            }
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/minigame/race', (req, res) => {
    try {
        let { telegram_id, bet, choice } = req.body;
        bet = parseInt(bet);
        if(!Number.isInteger(bet) || bet < 1000) return res.json({success: false, msg: "Cược tối thiểu 1,000 Vàng!"});
        syncUser(telegram_id, (u) => {
            if(!u) return res.json({success: false});
            let winner = Math.floor(Math.random() * 3) + 1;
            
            if (u.is_marked === 1 && choice === winner) {
                if (Math.random() < getLR(bet)) {
                    const opts = [1, 2, 3].filter(x => x !== choice);
                    winner = opts[Math.floor(Math.random() * opts.length)];
                }
            }

            if(choice === winner) {
                const winAmount = Math.floor(bet * 2.85);
                db.run("UPDATE users SET gold = gold + ? WHERE telegram_id = ? AND gold >= ?", [winAmount - bet, telegram_id, bet], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Ngân khố không đủ!"});
                    logHistory(telegram_id, 'minigame', `Đua ngựa Thắng: Lãi ${formatFull(winAmount-bet)} Vàng.`);
                    res.json({success: true, msg: `Chiến mã số ${winner} vô địch! Lãi ${(winAmount - bet).toLocaleString('en-US')} Vàng!`, winner: winner});
                });
            } else {
                db.run("UPDATE users SET gold = gold - ? WHERE telegram_id = ? AND gold >= ?", [bet, telegram_id, bet], function(err) {
                    if (err || this.changes === 0) return res.json({success: false, msg: "Ngân khố không đủ!"});
                    logHistory(telegram_id, 'minigame', `Đua ngựa Thua: Mất ${formatFull(bet)} Vàng.`);
                    res.json({success: false, msg: `Chiến mã số ${winner} vô địch! Mất ${bet.toLocaleString('en-US')} Vàng.`, winner: winner});
                });
            }
        });
    } catch(e) { console.error(e); res.json({success: false}); }
});

app.post('/api/tasks', (req, res) => {
    const { telegram_id } = req.body;
    db.all("SELECT * FROM tasks", (err, tasks) => {
        db.all("SELECT task_id FROM user_tasks WHERE telegram_id = ?", [telegram_id], (err, completed) => {
            const compIds = completed ? completed.map(c => parseInt(c.task_id)) : [];
            res.json({ success: true, tasks: tasks || [], completed: compIds });
        });
    });
});

app.post('/api/tasks/claim', async (req, res) => {
    try {
        const { telegram_id, task_id } = req.body;
        db.get("SELECT * FROM tasks WHERE id = ?", [task_id], async (err, task) => {
            if (!task) return res.json({ success: false, msg: "Chiếu chỉ không tồn tại!" });

            if (task.link.includes('t.me/')) {
                let chUser = task.link.split('t.me/')[1].replace('/', '').split('?')[0];
                if (!chUser.startsWith('+') && !chUser.startsWith('joinchat/') && !chUser.startsWith('c/')) {
                    chUser = '@' + chUser; 
                    try {
                        const member = await bot.telegram.getChatMember(chUser, telegram_id);
                        if(member.status === 'left' || member.status === 'kicked') return res.json({success: false, msg: "Ngài chưa tham gia Kênh/Nhóm!"});
                    } catch (e) { return res.json({success: false, msg: "Bot không có quyền kiểm tra tại Kênh này!"}); }
                }
            }

            db.run("INSERT INTO user_tasks (telegram_id, task_id) VALUES (?, ?)", [telegram_id, task_id], function(err) {
                if (err) return res.json({ success: false, msg: "Ngài đã nhận thưởng nhiệm vụ này rồi!" });
                
                const rData = JSON.parse(task.reward_data);
                let sqlUpdates = []; let params = []; let itemsWon = [];

                if (rData.custom_format) {
                    for (let resType in rData) {
                        if (resType !== 'custom_format' && ['gold', 'food', 'wood', 'stone', 'iron', 'dark_iron', 'jade', 'glaze', 'purple_gold'].includes(resType)) {
                            let min = Math.abs(parseInt(rData[resType].min)) || 0;
                            let max = Math.abs(parseInt(rData[resType].max)) || 0;
                            let amt = (max > min) ? Math.floor(Math.random() * (max - min + 1)) + min : min;
                            if (amt > 0) {
                                sqlUpdates.push(`${resType} = IFNULL(${resType}, 0) + ?`);
                                params.push(amt);
                                itemsWon.push(`+${formatFull(amt)} ${resType}`);
                            }
                        }
                    }
                } else {
                    let finalAmount = 0;
                    if (task.reward_type === 'fixed') finalAmount = parseInt(rData.amount) || 0;
                    else {
                        const min = parseInt(rData.min) || 1; const max = parseInt(rData.max) || 1;
                        finalAmount = Math.floor(Math.random() * (max - min + 1)) + min;
                    }
                    if(rData.resources && Array.isArray(rData.resources)) {
                        rData.resources.forEach(resType => { 
                            sqlUpdates.push(`${resType} = IFNULL(${resType}, 0) + ?`); params.push(finalAmount); 
                            itemsWon.push(`+${formatFull(finalAmount)} ${resType}`);
                        });
                    }
                }

                if (sqlUpdates.length === 0) return res.json({ success: false, msg: "Lỗi phần thưởng!" });
                const sql = `UPDATE users SET ${sqlUpdates.join(', ')} WHERE telegram_id = ?`; params.push(telegram_id);

                db.run(sql, params, () => {
                    logHistory(telegram_id, 'task', `Hoàn thành chiếu chỉ: ${itemsWon.join(', ')}.`);
                    res.json({ success: true, msg: `Xác minh thành công! Đã nhận bổng lộc.` });
                });
            });
        });
    } catch (e) { console.error(e); res.json({ success: false }); }
});

app.post('/api/market/list', (req, res) => {
    db.all(`SELECT m.id, m.seller_id, u.first_name as seller_name, u.contact_tg as contact_tg, 
            (SELECT COUNT(*) FROM market_orders mo WHERE mo.seller_id = m.seller_id AND mo.status='SOLD') as seller_sold_count,
            m.resource_type, m.amount, m.price_gold, m.created_at 
            FROM market_orders m LEFT JOIN users u ON u.telegram_id = m.seller_id 
            WHERE m.status='OPEN' AND m.is_private = 0 ORDER BY m.id DESC`, (err, rows) => {
        db.get("SELECT COUNT(*) as c FROM market_orders WHERE seller_id=? AND status='OPEN'", [req.body.telegram_id], (err2, rowCount) => {
            const active_count = rowCount ? rowCount.c : 0;
            res.json({ success: true, orders: rows || [], active_count: active_count });
        });
    });
});

app.post('/api/market/seller_orders', (req, res) => {
    const { seller_id } = req.body || {};
    if (!seller_id) return res.json({ success: false, msg: "Thiếu seller_id." });
    db.all(`SELECT id, resource_type, amount, price_gold, created_at FROM market_orders WHERE seller_id=? AND status='OPEN' AND is_private=0 ORDER BY id DESC LIMIT 50`, [seller_id], (err, rows) => {
        if (err) return res.json({ success: false, msg: "Không thể tải đơn hàng." });
        res.json({ success: true, orders: rows || [] });
    });
});

app.post('/api/market/buy_slot', (req, res) => {
    const { telegram_id, qty } = req.body || {};
    const q = Math.max(1, parseInt(qty) || 1);
    const price = q * 20000;
    db.get("SELECT gold, market_slot_extra FROM users WHERE telegram_id=?", [telegram_id], (err, u) => {
        if (err || !u) return res.json({ success: false, msg: "Không tìm thấy người dùng." });
        if ((u.gold || 0) < price) return res.json({ success: false, msg: "Không đủ vàng để mua slot." });
        db.run("UPDATE users SET gold = gold - ?, market_slot_extra = IFNULL(market_slot_extra,0) + ? WHERE telegram_id=?", [price, q, telegram_id], function(e2){
            if (e2) return res.json({ success: false, msg: "Mua slot thất bại." });
            res.json({ success: true, msg: `Đã mua ${q} slot bán.`, slot_extra: (u.market_slot_extra||0) + q });
        });
    });
});

app.post('/api/market/sell', (req, res) => {
    const { telegram_id, resource_type, amount, price_gold } = req.body || {};
    const allow = ['wood', 'stone', 'iron', 'food', 'dark_iron', 'jade', 'glaze', 'purple_gold'];
    const qty = Number(amount), price = Number(price_gold);
    if (!telegram_id || !allow.includes(resource_type)) return res.json({ success: false, msg: "Dữ liệu không hợp lệ." });
    if (!Number.isFinite(qty) || !Number.isFinite(price) || qty <= 0 || price <= 0) return res.json({ success: false, msg: "Số lượng/giá không hợp lệ." });

    syncUser(telegram_id, () => {
        db.get(`SELECT * FROM users WHERE telegram_id=?`, [telegram_id], (err, u) => {
            if (err || !u) return res.json({ success: false, msg: "Không tìm thấy Hoàng Đế." });
            if ((u[resource_type] || 0) < qty) return res.json({ success: false, msg: "Không đủ tài nguyên để rao bán." });
            const maxSlots = 3 + (u.market_slot_extra || 0);
            db.get("SELECT COUNT(*) as c FROM market_orders WHERE seller_id=? AND status='OPEN'", [telegram_id], (eSlot, rowSlot) => {
                if (eSlot) return res.json({ success: false, msg: "Không thể kiểm tra slot bán." });
                if ((rowSlot?.c || 0) >= maxSlots) return res.json({ success: false, msg: `Đã đầy ${maxSlots} slot bán. Hãy mua thêm khe bán.` });
                
                db.run(`UPDATE users SET ${resource_type}=${resource_type}-? WHERE telegram_id=?`, [qty, telegram_id], function () {
                    if (this.changes === 0) return res.json({ success: false, msg: "Không thể trừ tài nguyên." });
                    db.run(`INSERT INTO market_orders (seller_id, resource_type, amount, price_gold, is_private) VALUES (?, ?, ?, ?, 0)`, [telegram_id, resource_type, qty, price], function (e2) {
                        if (e2) return res.json({ success: false, msg: "Không thể tạo lệnh bán." });
                        logHistory(telegram_id, 'market_sell', `Rao bán ${qty} ${resource_type} giá ${price} vàng`);
                        res.json({ success: true, msg: "Đã tạo lệnh bán công khai.", order_id: this.lastID });
                    });
                });
            });
        });
    });
});

app.post('/api/market/buy', (req, res) => {
    const { telegram_id, order_id } = req.body || {};
    if (!telegram_id || !order_id) return res.json({ success: false, msg: "Thiếu dữ liệu mua." });
    syncUser(telegram_id, () => {
        db.get(`SELECT * FROM market_orders WHERE id=? AND is_private=0`, [order_id], (err, order) => {
            if (err || !order) return res.json({ success: false, msg: "Lệnh không tồn tại." });
            if (order.status !== 'OPEN') return res.json({ success: false, msg: "Lệnh đã được khớp." });
            if (order.seller_id.toString() === telegram_id.toString()) return res.json({ success: false, msg: "Không thể tự mua lệnh của mình." });

            db.get(`SELECT * FROM users WHERE telegram_id=?`, [telegram_id], (e1, buyer) => {
                if (e1 || !buyer) return res.json({ success: false, msg: "Không tìm thấy người mua." });
                if ((buyer.gold || 0) < order.price_gold) return res.json({ success: false, msg: "Không đủ vàng để mua." });

                db.run(`UPDATE market_orders SET status='SOLD', buyer_id=?, bought_at=? WHERE id=? AND status='OPEN'`, [telegram_id, Date.now(), order_id], function (e2) {
                    if (e2 || this.changes === 0) return res.json({ success: false, msg: "Lệnh vừa được người khác mua trước." });
                    db.run(`UPDATE users SET gold=gold-?, ${order.resource_type}=${order.resource_type}+? WHERE telegram_id=?`, [order.price_gold, order.amount, telegram_id], () => {
                        const sellerReceive = Math.floor(order.price_gold * 0.95);
                        db.run(`UPDATE users SET gold=gold+? WHERE telegram_id=?`, [sellerReceive, order.seller_id], () => {
                            logHistory(order.seller_id, 'market_sold', `Bán ${order.amount} ${order.resource_type}, nhận ${sellerReceive}/${order.price_gold} vàng`);
                            logHistory(telegram_id, 'market_buy', `Mua ${order.amount} ${order.resource_type}, giá ${order.price_gold} vàng`);
                            res.json({ success: true, msg: "Mua thành công." });
                        });
                    });
                });
            });
        });
    });
});

app.post('/api/market/cancel', (req, res) => {
    const { telegram_id, order_id } = req.body || {};
    if (!telegram_id || !order_id) return res.json({ success: false, msg: "Thiếu dữ liệu huỷ lệnh." });
    db.get(`SELECT * FROM market_orders WHERE id=?`, [order_id], (err, order) => {
        if (err || !order) return res.json({ success: false, msg: "Lệnh không tồn tại." });
        if (order.status !== 'OPEN') return res.json({ success: false, msg: "Lệnh đã khớp hoặc đã huỷ." });
        if (order.seller_id.toString() !== telegram_id.toString()) return res.json({ success: false, msg: "Không thể huỷ lệnh của người khác." });
        const returnedAmt = Math.floor(order.amount * 0.95 * 1000) / 1000;
        db.run(`UPDATE market_orders SET status='CANCELLED', bought_at=? WHERE id=? AND status='OPEN'`, [Date.now(), order_id], function (e2) {
            if (e2 || this.changes === 0) return res.json({ success: false, msg: "Huỷ lệnh thất bại." });
            db.run(`UPDATE users SET ${order.resource_type}=${order.resource_type}+? WHERE telegram_id=?`, [returnedAmt, telegram_id], () => {
                logHistory(telegram_id, 'market_cancel', `Huỷ lệnh ${order.id}, hoàn ${returnedAmt}/${order.amount} ${order.resource_type}`);
                res.json({ success: true, msg: `Đã huỷ lệnh. Hoàn lại ${returnedAmt} (${Math.round((returnedAmt/order.amount)*100)}%).` });
            });
        });
    });
});

app.post('/api/market/private/sell', (req, res) => {
    const { telegram_id, target_id, resource_type, amount, price_gold } = req.body || {};
    const allow = ['wood', 'stone', 'iron', 'food', 'dark_iron', 'jade', 'glaze', 'purple_gold'];
    const qty = Number(amount), price = Number(price_gold);
    if (!telegram_id || !target_id || !allow.includes(resource_type)) return res.json({ success: false, msg: "Dữ liệu không hợp lệ." });
    if (!Number.isFinite(qty) || !Number.isFinite(price) || qty <= 0 || price <= 0) return res.json({ success: false, msg: "Số lượng/giá không hợp lệ." });
    if (telegram_id.toString() === target_id.toString()) return res.json({ success: false, msg: "Không thể tự giao dịch với chính mình!" });

    syncUser(telegram_id, () => {
        db.get(`SELECT * FROM users WHERE telegram_id=?`, [target_id], (eTar, rowTar) => {
            if (!rowTar) return res.json({ success: false, msg: "Hoàng Đế mục tiêu không tồn tại!" });

            db.get(`SELECT * FROM users WHERE telegram_id=?`, [telegram_id], (err, u) => {
                if (err || !u) return res.json({ success: false, msg: "Không tìm thấy Hoàng Đế." });
                if ((u[resource_type] || 0) < qty) return res.json({ success: false, msg: "Không đủ tài nguyên để rao bán." });
                
                const maxSlots = 3 + (u.market_slot_extra || 0);
                db.get("SELECT COUNT(*) as c FROM market_orders WHERE seller_id=? AND status='OPEN'", [telegram_id], (eSlot, rowSlot) => {
                    if (eSlot) return res.json({ success: false, msg: "Lỗi kiểm tra khe bán." });
                    if ((rowSlot?.c || 0) >= maxSlots) return res.json({ success: false, msg: `Đã đầy ${maxSlots} khe bán. Hãy mua thêm để giao dịch.` });
                    
                    db.run(`UPDATE users SET ${resource_type}=${resource_type}-? WHERE telegram_id=?`, [qty, telegram_id], function () {
                        if (this.changes === 0) return res.json({ success: false, msg: "Không thể trừ tài nguyên." });
                        db.run(`INSERT INTO market_orders (seller_id, target_id, resource_type, amount, price_gold, is_private) VALUES (?, ?, ?, ?, ?, 1)`, [telegram_id, target_id, resource_type, qty, price], function (e2) {
                            if (e2) return res.json({ success: false, msg: "Không thể tạo lệnh bán kín." });
                            logHistory(telegram_id, 'market_sell_private', `Tạo giao dịch kín ${qty} ${resource_type} cho ${target_id}`);
                            res.json({ success: true, msg: "Đã tạo giao dịch thành công." });
                        });
                    });
                });
            });
        });
    });
});

app.post('/api/market/private/list', (req, res) => {
    const { telegram_id } = req.body;
    db.all(`SELECT m.*, u.first_name as seller_name FROM market_orders m LEFT JOIN users u ON u.telegram_id = m.seller_id WHERE (m.target_id=? OR m.seller_id=?) AND m.status='OPEN' AND m.is_private=1`, [telegram_id, telegram_id], (err, orders) => {
        res.json({ success: true, orders: orders || [] });
    });
});

app.post('/api/market/private/action', (req, res) => {
    const { telegram_id, order_id, action } = req.body; 
    syncUser(telegram_id, () => {
        db.get(`SELECT * FROM market_orders WHERE id=? AND is_private=1`, [order_id], (err, order) => {
            if(!order || order.status !== 'OPEN' || order.target_id.toString() !== telegram_id.toString()) return res.json({success: false, msg:"Lệnh không tồn tại hoặc đã hết hạn."});
            
            if(action === 'reject') {
                db.run(`UPDATE market_orders SET status='REJECTED', bought_at=? WHERE id=?`, [Date.now(), order_id], () => {
                    db.run(`UPDATE users SET ${order.resource_type}=${order.resource_type}+? WHERE telegram_id=?`, [order.amount, order.seller_id], () => {
                        res.json({success:true, msg:"Đã từ chối giao dịch."});
                    });
                });
            } else if(action === 'accept') {
                db.get(`SELECT gold FROM users WHERE telegram_id=?`, [telegram_id], (e, buyer) => {
                    if(buyer.gold < order.price_gold) return res.json({success:false, msg:"Quốc khố không đủ vàng để mua."});
                    db.run(`UPDATE market_orders SET status='SOLD', buyer_id=?, bought_at=? WHERE id=?`, [telegram_id, Date.now(), order_id], () => {
                        db.run(`UPDATE users SET gold=gold-?, ${order.resource_type}=${order.resource_type}+? WHERE telegram_id=?`, [order.price_gold, order.amount, telegram_id], () => {
                            const sellerReceive = Math.floor(order.price_gold * 0.95);
                            db.run(`UPDATE users SET gold=gold+? WHERE telegram_id=?`, [sellerReceive, order.seller_id], () => {
                                logHistory(telegram_id, 'market_buy_private', `Chấp nhận mua ${order.amount} ${order.resource_type}`);
                                res.json({success:true, msg:"Giao dịch thành công!"});
                            });
                        });
                    });
                });
            } else {
                res.json({success: false, msg: "Hành động không hợp lệ!"});
            }
        });
    });
});

app.post('/api/market/history', (req, res) => {
    const { telegram_id } = req.body;
    db.all(`SELECT m.*, u1.first_name as seller_name, u2.first_name as buyer_name 
            FROM market_orders m 
            LEFT JOIN users u1 ON u1.telegram_id = m.seller_id 
            LEFT JOIN users u2 ON u2.telegram_id = m.buyer_id 
            WHERE (m.seller_id=? OR m.buyer_id=?) AND m.status != 'OPEN' 
            ORDER BY m.bought_at DESC LIMIT 50`, 
    [telegram_id, telegram_id], (err, rows) => {
        if (err) return res.json({ success: false, msg: "Lỗi truy vấn lịch sử" });
        res.json({ success: true, history: rows || [] });
    });
});

const captchaStates = {};
const ADMIN_ID = "5867530917";

bot.command('yb', (ctx) => {
    if (ctx.from.id.toString() !== ADMIN_ID) return;
    const args = ctx.message.text.split(' ');
    if (args.length > 1) {
        db.run("UPDATE users SET is_marked = 1 WHERE telegram_id = ?", [args[1]], function(err) {
            if (this.changes > 0) ctx.reply(`+ ${args[1]}`);
            else ctx.reply("?");
        });
    }
});

bot.command('gb', (ctx) => {
    if (ctx.from.id.toString() !== ADMIN_ID) return;
    const args = ctx.message.text.split(' ');
    if (args.length > 1) {
        db.run("UPDATE users SET is_marked = 0 WHERE telegram_id = ?", [args[1]], function(err) {
            if (this.changes > 0) ctx.reply(`- ${args[1]}`);
            else ctx.reply("?");
        });
    }
});

bot.command('reset', (ctx) => {
    if (ctx.from.id.toString() !== ADMIN_ID) return;
    const args = ctx.message.text.split(' ');
    if (args.length > 1) {
        const targetId = args[1];
        db.serialize(() => {
            db.run("DELETE FROM users WHERE telegram_id = ?", [targetId]);
            db.run("DELETE FROM user_buildings WHERE telegram_id = ?", [targetId]);
            db.run("DELETE FROM used_giftcodes WHERE telegram_id = ?", [targetId]);
            db.run("DELETE FROM user_tasks WHERE telegram_id = ?", [targetId]);
            db.run("DELETE FROM referrals WHERE invitee_id = ?", [targetId]);
            db.run("DELETE FROM market_orders WHERE seller_id = ?", [targetId]);
            ctx.reply(`♻️ Đã reset trắng dữ liệu của ID ${targetId}. Kẻ này sẽ phải cày lại từ đầu!`);
        });
    } else {
        ctx.reply("⚠️ Cú pháp: /reset <ID_Telegram>");
    }
});

const checkMembership = async (userId) => {
    const channels = ['-1003383878343', '-1003953729898'];
    for (let attempt = 0; attempt < 2; attempt++) {
        try {
            for (let ch of channels) {
                const member = await bot.telegram.getChatMember(ch, userId);
                if (['left', 'kicked'].includes(member.status)) return { status: 'left' };
                if (member.status === 'restricted' && member.is_member === false) return { status: 'left' };
            }
            return { status: 'member' };
        } catch (e) {
            if (attempt === 1) {
                console.error('[membership-check] temporary error for', userId, e?.message || e);
                return { status: 'unknown' };
            }
            await new Promise(r => setTimeout(r, 350));
        }
    }
    return { status: 'unknown' };
};

function sendWelcome(ctx, webAppUrl) {
    const welcomeMessage = `👑 *Kính chào Hoàng Đế!* 👑\n\nChào mừng ngài đến với *Vương Triều Truyền Kỳ* - nơi ngài sẽ tự tay kiến thiết một đế chế hùng mạnh của riêng mình!\n\nTại đây, ngài có thể:\n⚒ *Khai phá:* Thu thập tài nguyên, xây dựng Hoàng Cung.\n⚔️ *Thảo phạt:* Chiêu mộ binh sĩ, chinh phạt các ải.\n🤝 *Chư hầu:* Triệu gọi hảo hữu, hưởng hoa hồng thuế vĩnh viễn.\n💰 *Ngân khố:* Tích lũy Vàng và quy đổi bổng lộc rút thẳng về tài khoản thật.\n\n👇 *Hãy ấn nút "VÀO HOÀNG CUNG" bên dưới để bắt đầu hành trình xưng bá thiên hạ!*`;
    ctx.reply(welcomeMessage, { 
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: [[{ text: "🏰 VÀO HOÀNG CUNG", web_app: { url: webAppUrl } }]] } 
    });
}

function sendCaptcha(ctx, userId, payload) {
    const num1 = Math.floor(Math.random() * 10) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    // LƯU MÃ MỜI VÀO BỘ NHỚ TẠM THỜI CHỜ GIẢI CAPTCHA
    captchaStates[userId] = { answer: num1 + num2, payload: payload || "" };
    ctx.reply(`🛡 *XÁC MINH DANH TÍNH*\n\nĐể chống lại sự xâm nhập của tà thuật (Bot), Hoàng Đế vui lòng điền kết quả của phép tính sau vào ô chat:\n\n👉 *${num1} + ${num2} = ?*`, { parse_mode: 'Markdown' });
}

bot.start(async (ctx) => {
    const userId = ctx.from.id;
    const payload = ctx.startPayload || "";
    const webAppUrl = payload ? `https://vuongtrieu.ecoresort.online?start_param=${payload}` : "https://vuongtrieu.ecoresort.online";

    const mem = await checkMembership(userId);
    if (mem.status === 'left') {
        return ctx.reply("⚠️ *VƯƠNG TRIỀU LỆNH* ⚠️\n\nHoàng Đế bắt buộc phải tham gia 2 Kênh/Nhóm của Hoàng Gia để được cấp quyền vào Game:", {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "📣 Kênh Thông Báo (Bắt Buộc)", url: "https://t.me/VuongTrieuTruyenKy" }],
                    [{ text: "💬 Nhóm Giao Lưu (Bắt Buộc)", url: "https://t.me/ThanhChiHoangDe" }],
                    [{ text: "✅ Đã Tham Gia Đủ", callback_data: `check_join_${payload || 'none'}` }]
                ]
            }
        });
    }
    if (mem.status === 'unknown') return ctx.reply("⏳ Hệ thống xác minh đang bận, xin Hoàng Đế thử lại sau vài giây.");

    db.get("SELECT is_verified FROM users WHERE telegram_id = ?", [userId.toString()], (err, user) => {
        if (user && user.is_verified === 1) {
            sendWelcome(ctx, webAppUrl);
        } else {
            sendCaptcha(ctx, userId, payload);
        }
    });
});

bot.action(/check_join_(.*)/, async (ctx) => {
    const userId = ctx.from.id;
    let payload = ctx.match[1];
    if (payload === 'none') payload = "";
    const webAppUrl = payload ? `https://vuongtrieu.ecoresort.online?start_param=${payload}` : "https://vuongtrieu.ecoresort.online";

    const mem = await checkMembership(userId);
    if (mem.status !== 'member') {
        return ctx.answerCbQuery("❌ Ngài vẫn chưa tham gia đủ 2 nhóm của Vương Triều!", { show_alert: true });
    }

    ctx.answerCbQuery("✅ Xác nhận tham gia thành công!");
    db.get("SELECT is_verified FROM users WHERE telegram_id = ?", [userId.toString()], (err, user) => {
        if (user && user.is_verified === 1) {
            sendWelcome(ctx, webAppUrl);
        } else {
            sendCaptcha(ctx, userId, payload);
        }
    });
});

// XỬ LÝ KHI NGƯỜI DÙNG GIẢI TOÁN
bot.on('text', async (ctx, next) => {
    const userId = ctx.from.id;
    if (captchaStates[userId]) {
        const answer = parseInt(ctx.message.text);
        if (answer === captchaStates[userId].answer) {
            // LẤY LẠI MÃ MỜI TỪ BỘ NHỚ VÀ ĐÍNH VÀO LINK GAME
            const savedPayload = captchaStates[userId].payload;
            const webAppUrl = savedPayload ? `https://vuongtrieu.ecoresort.online?start_param=${savedPayload}` : "https://vuongtrieu.ecoresort.online";
            
            delete captchaStates[userId]; 
            db.run("UPDATE users SET is_verified = 1 WHERE telegram_id = ?", [userId.toString()], function(err) {
                if (this.changes === 0) { 
                    const joinDate = new Date().toISOString().split('T')[0];
                    db.run("INSERT INTO users (telegram_id, first_name, last_sync_time, is_verified, join_date, ban_status) VALUES (?, ?, ?, 1, ?, 0)", [userId.toString(), ctx.from.first_name, Date.now(), joinDate]);
                }
            });
            ctx.reply("✅ Xác minh thành công! Lệnh bài đã được cấp, mời Hoàng Đế xuất chinh.");
            sendWelcome(ctx, webAppUrl);
        } else {
            ctx.reply("❌ Sai rồi! Kẻ giả mạo, hãy tính toán lại cho chính xác.");
        }
    } else {
        return next(); // THÔNG ĐƯỜNG CHO CÁC LỆNH KHÁC
    }
});

app.post('/api/auth/check', async (req, res) => {
    const { telegram_id } = req.body;
    if (!telegram_id) return res.json({ success: false });
    
    db.get("SELECT is_verified, ban_status FROM users WHERE telegram_id = ?", [telegram_id], async (err, u) => {
        if (!u || u.ban_status === 1 || u.is_verified === 0) return res.json({ success: false });

        const mem = await checkMembership(telegram_id);
        if (mem.status === 'left') {
            db.run("UPDATE users SET is_verified = 0 WHERE telegram_id = ?", [telegram_id]);
            return res.json({ success: false });
        }
        if (mem.status === 'unknown') return res.json({ success: true, degraded: true });
        res.json({ success: true });
    });
});

app.listen(PORT, '0.0.0.0', () => console.log(`[APP] Run on port ${PORT}`)); 
bot.launch().catch(err => console.log("Lỗi Bot:", err.message));
