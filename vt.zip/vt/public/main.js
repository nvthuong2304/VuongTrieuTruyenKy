let devCode = localStorage.getItem('device_code');
if (!devCode) {
    devCode = 'DEV_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
    localStorage.setItem('device_code', devCode);
}
window.DEVICE_CODE = devCode;

const coinImg = '<img src="https://i.ibb.co/hJsDmYjP/1000039881-removebg-preview.png" class="w-3.5 h-3.5 object-contain inline-block drop-shadow-[0_0_2px_rgba(255,215,0,0.8)] -mt-0.5">';

const formatNum = n => {
    const formatSuffix = (val, suffix) => {
        let s = parseFloat(val.toFixed(2)).toString();
        return s.includes('.') ? s.replace('.', suffix) : s + suffix;
    };
    if (n >= 1e9) return formatSuffix(n / 1e9, 'B');
    if (n >= 1e6) return formatSuffix(n / 1e6, 'M');
    if (n >= 1e3) return formatSuffix(n / 1e3, 'K');
    return Math.floor(n).toLocaleString('en-US');
};

const formatFullNum = n => Math.floor(n).toLocaleString('en-US');

const Fab = {
    init() {},
    toggle() {}
};

const Tabs = {
    renderHome(v, app) {
        const conf = app.config || {};
        const cTap = parseInt(conf.cost_tap) || 50000;
        const cEnergy = parseInt(conf.cost_energy) || 50000;
        const cRegen = parseInt(conf.cost_regen) || 100000;
        
        const tLvl = app.user.tap_level || 1;
        const eLvl = app.user.max_energy || 1000;
        const rLvl = app.user.regen_level || 1;

        const tCost = tLvl * cTap; 
        const eCost = ((eLvl - 1000) / 500 + 1) * cEnergy; 
        const rCost = rLvl * cRegen;
        
        v.innerHTML = `
        <div class="fade-enter flex flex-col items-center justify-start relative z-10 w-full mt-2 pb-32">
            <div class="w-[95%] max-w-[360px] royal-box p-2.5 mb-2 shadow-lg relative z-20 border-opacity-50 mt-4">
                <div class="flex justify-between text-[11px] font-black text-c-gold mb-1.5 px-1 uppercase opacity-90"><span><i class="fas fa-bolt text-yellow-400 mr-1"></i>LONG THỂ</span><span id="ui-energy"></span></div>
                <div class="h-2.5 bg-gray-950 rounded-full overflow-hidden border border-black"><div id="ui-energy-bar" class="h-full bg-gradient-to-r from-orange-700 via-yellow-500 to-yellow-100 transition-all"></div></div>
            </div>
            
            <div class="tap-circle-container">
                <div class="tap-circle" onclick="App.tap(event)"><img src="https://i.ibb.co/hJsDmYjP/1000039881-removebg-preview.png" class="absolute w-[125%] h-[125%] max-w-none object-contain pointer-events-none drop-shadow-[0_0_10px_rgba(255,215,0,0.4)]" draggable="false"></div>
            </div>

            <div class="flex gap-1.5 w-[95%] max-w-[360px] relative z-20 mb-4">
                <button onclick="App.upgrade('tap')" class="flex-1 btn-royal h-[42px] rounded-lg shadow-md active:scale-95 transition flex flex-col items-center justify-center px-1"><span class="text-[9px] font-bold whitespace-nowrap"><i class="fas fa-hammer text-[#ffd700] mr-0.5"></i> BÚA LV.${tLvl+1}</span><span class="text-[8px] opacity-90 leading-tight">${coinImg} ${formatNum(tCost)}</span></button>
                <button onclick="App.upgrade('energy')" class="flex-1 btn-royal h-[42px] rounded-lg shadow-md active:scale-95 transition flex flex-col items-center justify-center px-1"><span class="text-[9px] font-bold whitespace-nowrap"><i class="fas fa-battery-full text-green-700 mr-0.5"></i> LONG THỂ</span><span class="text-[8px] opacity-90 leading-tight">${coinImg} ${formatNum(eCost)}</span></button>
                <button onclick="App.upgrade('regen')" class="flex-1 btn-royal h-[42px] rounded-lg shadow-md active:scale-95 transition flex flex-col items-center justify-center px-1"><span class="text-[9px] font-bold whitespace-nowrap"><i class="fas fa-bolt text-blue-600 mr-0.5"></i> HỒI PHỤC</span><span class="text-[8px] opacity-90 leading-tight">${coinImg} ${formatNum(rCost)}</span></button>
            </div>

            <h3 class="font-empire text-c-gold text-[10px] w-[95%] max-w-[360px] mb-1.5 border-l-2 border-[var(--gold)] pl-1.5 text-left mt-2">Hỗ Trợ Hoàng Đế</h3>
            <div class="w-[95%] max-w-[360px] mb-4"><button id="btn-merchant" onclick="App.openModal('merchant')" class="btn-royal w-full h-[45px] text-[11px] shadow-lg flex items-center justify-center gap-2"><i class="fas fa-user-secret text-lg"></i> THƯƠNG NHÂN BÍ ẨN</button></div>
            
            <h3 class="font-empire text-gray-400 text-[10px] w-[95%] max-w-[360px] mb-2 border-l-2 border-gray-500 pl-1.5 text-left">Lịch Sử Biến Động</h3>
            <div class="w-[95%] max-w-[360px] bg-black/40 border border-gray-800 rounded p-2 shadow-inner mb-6" id="home-history-list">
                <div class="text-center py-5 text-gray-500"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div>
            </div>
        </div>`; 
        app.updateUI();
        app.loadHistory();
    },

    renderBuild(v, app) {
        let avHtml = '', lkHtml = ''; const pLvl = app.inventory.find(i => i.id === 'palace')?.level || 0;
        const defaultIcons = {'palace':'fa-chess-king text-yellow-500', 'kitchen':'fa-fire text-orange-500', 'barracks':'fa-campground text-green-500', 'ironmine':'fa-mountain text-gray-400', 'forge':'fa-hammer text-red-400', 'lumber':'fa-tree text-green-700', 'quarry':'fa-cubes text-gray-300', 'darkiron_mine':'fa-meteor text-purple-500', 'hospital':'fa-clinic-medical text-pink-400', 'jade_cave':'fa-gem text-teal-400', 'observatory':'fa-eye text-blue-400', 'smelter':'fa-fire-alt text-orange-600', 'glazekiln':'fa-ring text-blue-300', 'purplegold_mine':'fa-crown text-purple-600'};
        const defaultIds = Object.keys(defaultIcons);
        
        app.catalog.forEach(b => {
            const iB = app.inventory.find(i => i.id === b.id); 
            const lvl = iB ? iB.level : 0, upg = iB ? iB.is_upgrading : 0;
            
            let costW = b.base_wood * (lvl + 1); let costS = b.base_stone * (lvl + 1); let costI = b.base_iron * (lvl + 1); 
            let costDI = (b.base_dark_iron||0) * (lvl + 1); let costJ = (b.base_jade||0) * (lvl + 1);
            let costGL = (b.base_glaze || 0) * (lvl + 1); let costPG = (b.base_purple_gold || 0) * (lvl + 1);

            if (b.id === 'palace' && lvl < 2) costI = 0;
            if (lvl >= 4) costI += (lvl - 3) * 500; 
            if (lvl >= 8 && b.id !== 'darkiron_mine') costDI += (lvl - 7) * 800; 
            if (lvl >= 12 && b.id !== 'jade_cave') costJ += (lvl - 11) * 300; 
            if (lvl >= 15 && b.id !== 'glazekiln') costGL += (lvl - 14) * 100;
            if (lvl >= 18 && b.id !== 'purplegold_mine') costPG += (lvl - 17) * 50;

            let timeToBuild = Math.floor(b.base_time * (lvl + 1));
            
            const isNew = !defaultIds.includes(b.id);
            const iconHtml = isNew ? '<div class="w-10 h-10 rounded bg-red-900/50 border border-red-500/50 flex flex-col items-center justify-center animate-pulse"><span class="text-[10px] font-black text-red-400">NEW</span></div>' : `<div class="w-10 h-10 rounded bg-black/50 border border-[var(--gold)]/20 flex items-center justify-center"><i class="fas ${defaultIcons[b.id]} text-[18px]"></i></div>`;
            const iconLockedHtml = isNew ? '<div class="w-10 h-10 rounded bg-black/80 flex flex-col items-center justify-center"><span class="text-[10px] font-black text-gray-500">NEW</span></div>' : `<div class="w-10 h-10 rounded bg-black/80 flex items-center justify-center"><i class="fas ${defaultIcons[b.id]} text-[18px] text-gray-500"></i></div>`;

            if(b.id !== 'palace' && pLvl < b.req_palace) {
                lkHtml += `<div class="royal-card p-2.5 flex justify-between items-center bg-black/40 border-gray-600/30 grayscale opacity-80"><div class="flex items-center gap-2">${iconLockedHtml}<div><h3 class="font-black text-[12px] text-gray-300 font-empire"><i class="fas fa-lock text-red-500"></i> ${b.name}</h3><p class="text-[9px] text-red-400 font-bold bg-red-900/30 px-1 py-0.5 rounded border border-red-900/50 mt-1">Cần Hoàng Cung Lv.${b.req_palace}</p></div></div><button class="px-2 h-[42px] w-[85px] rounded-lg bg-gray-800 text-gray-400" disabled><i class="fas fa-lock"></i></button></div>`;
            } else {
                let costStr = '';
                if(lvl >= 20) {
                    costStr = `<span class="text-green-400 font-black"><i class="fas fa-check-circle"></i> Đạt Cảnh Giới Tối Đa</span>`;
                } else {
                    let cArr = [];
                    if(costW > 0) cArr.push(`<span class="${app.user.wood>=costW?'text-c-dark':'text-red-500'}"><i class="fas fa-tree"></i> ${formatNum(costW)}</span>`);
                    if(costS > 0) cArr.push(`<span class="${app.user.stone>=costS?'text-gray-400':'text-red-500'}"><i class="fas fa-cube"></i> ${formatNum(costS)}</span>`);
                    if(costI > 0) cArr.push(`<span class="${(app.user.iron||0)>=costI?'text-gray-300':'text-red-500'}"><i class="fas fa-cubes"></i> ${formatNum(costI)}</span>`);
                    if(costDI > 0) cArr.push(`<span class="${(app.user.dark_iron||0)>=costDI?'text-purple-400':'text-red-500'}"><i class="fas fa-meteor"></i> ${formatNum(costDI)}</span>`);
                    if(costJ > 0) cArr.push(`<span class="${(app.user.jade||0)>=costJ?'text-teal-400':'text-red-500'}"><i class="fas fa-gem"></i> ${formatNum(costJ)}</span>`);
                    if(costGL > 0) cArr.push(`<span class="${(app.user.glaze||0)>=costGL?'text-blue-300':'text-red-500'}"><i class="fas fa-ring"></i> ${formatNum(costGL)}</span>`);
                    if(costPG > 0) cArr.push(`<span class="${(app.user.purple_gold||0)>=costPG?'text-purple-600':'text-red-500'}"><i class="fas fa-crown"></i> ${formatNum(costPG)}</span>`);
                    costStr = cArr.join(' ');
                }
                
                let btn = '';
                if (lvl >= 20) btn = `<button class="btn-royal px-2 h-[42px] w-[85px] text-[10px] grayscale opacity-80" disabled><i class="fas fa-check-circle mb-0.5"></i>Tối Đa</button>`;
                else btn = upg === 1 ? `<button id="btn-b-${b.id}" onclick="App.speedUp('${b.id}')" class="btn-royal px-1 h-[42px] w-[85px]"><i class="fas fa-spinner fa-spin"></i></button>` : `<button onclick="App.build('${b.id}')" class="btn-royal px-2 h-[42px] w-[85px] text-[10px]"><i class="fas fa-hammer mb-0.5"></i>${lvl>0?'Tu Bổ':'Xây Dựng'}</button>`;

                let effectStr = '';
                if (lvl > 0) {
                    const totalEff = b.base_val * lvl;
                    const eName = b.effect_name || b.effect_type;
                    
                    let fxTxt = `Sản lượng: +${formatNum(totalEff)} ${eName}/h`;
                    if (b.effect_type === 'troops') fxTxt = `Sức chứa: +${formatNum(totalEff)} lính`;
                    else if (b.effect_type === 'winrate') fxTxt = `Tỷ lệ thắng: +${(totalEff*100).toFixed(0)}%`;
                    else if (b.effect_type === 'save_troops') fxTxt = `Cứu thương: +${(totalEff*100).toFixed(0)}%`;
                    else if (b.effect_type === 'energy_regen') fxTxt = `Hồi thể lực: +${formatNum(totalEff)}/s`;
                    else if (b.effect_type === 'discount_train') fxTxt = `Giảm phí mộ: -${(totalEff*100).toFixed(0)}%`;
                    
                    effectStr = `<div class="text-[9px] text-green-400 font-bold mt-1.5 bg-green-900/30 px-1.5 py-0.5 rounded border border-green-800/50 inline-block"><i class="fas fa-level-up-alt mr-1"></i> ${fxTxt}</div>`;
                }
                avHtml += `<div class="royal-card p-2.5 flex flex-col gap-1.5"><div class="flex justify-between items-center gap-2">${iconHtml}<div class="flex-1"><h3 class="font-black text-[12px] text-[var(--text-main)] font-empire">${b.name} <span class="text-c-gold text-[8px] bg-black/80 px-1 py-0.5 rounded border border-[var(--gold)]/30">Lv.${lvl}</span></h3><p class="text-[9px] text-gray-400 mt-0.5">${b.description}</p><p class="text-[9px] mt-1 text-gray-500"><i class="fas fa-clock text-c-gold"></i> ${(lvl<20)?timeToBuild:'---'}s</p>${effectStr}</div>${btn}</div><div class="flex flex-wrap gap-2 pt-1.5 border-t border-[var(--gold)]/10 text-[9px] font-bold justify-center">${costStr}</div></div>`;
            }
        });
        v.innerHTML = `<div class="fade-enter min-h-[85vh] pb-32"><h3 class="font-empire text-c-gold text-[10px] mb-1.5 border-l-2 border-[var(--gold)] pl-1.5">Công Bộ Kiến Thiết</h3><div class="space-y-2 mb-4">${avHtml}</div>` + (lkHtml ? `<h3 class="font-empire text-gray-500 text-[10px] mb-1.5 border-l-2 border-gray-600 pl-1.5">Chưa Mở Khóa</h3><div class="space-y-2 mb-4">${lkHtml}</div>` : '') + `<div id="invisible-spacer" class="h-20 w-full opacity-0 pointer-events-none"></div></div>`;
    },

    renderDungeon(v, app) {
        const conf = app.config || {
            train_qty_1: 5, train_qty_2: 25, train_cost_food: 10, train_cost_gold: 100,
            battle_base_troops: 5, battle_troops_step: 1, battle_base_food: 20, battle_food_step: 5
        };

        const s = app.user.current_stage || 1;
        const reqT = Math.floor(conf.battle_base_troops + (s * conf.battle_troops_step));
        const reqF = Math.floor(conf.battle_base_food + (s * conf.battle_food_step));
        
        const dR = app.user.discount_train || 0;
        const qty1 = conf.train_qty_1 || 5;
        const qty2 = conf.train_qty_2 || 25;
        
        const cF1 = Math.floor(qty1 * conf.train_cost_food * (1 - dR));
        const cG1 = Math.floor(qty1 * conf.train_cost_gold * (1 - dR));
        const cF2 = Math.floor(qty2 * conf.train_cost_food * (1 - dR));
        const cG2 = Math.floor(qty2 * conf.train_cost_gold * (1 - dR));
        
        v.innerHTML = `
        <div class="fade-enter w-full flex flex-col pt-2 pb-32">
            <div class="royal-card p-4 text-center border-orange-500/30 shadow-[0_0_15px_rgba(255,69,0,0.15)] mb-4 w-full flex-shrink-0">
                <i class="fas fa-skull-crossbones text-4xl text-orange-500 mb-3 drop-shadow-[0_0_5px_rgba(255,165,0,0.5)]"></i>
                <h3 class="font-empire text-[16px] text-[var(--text-main)] mb-1.5">Thảo Phạt - Ải ${s}</h3>
                <p class="text-[11px] text-gray-400 mb-2">Tỷ lệ thắng lợi: <strong class="text-green-500">${(app.user.win_rate * 100).toFixed(0)}%</strong></p>
                <div class="text-[10px] text-gray-300 bg-yellow-900/20 border border-yellow-500/30 rounded p-1.5 mb-2 inline-block">Bổng lộc: <strong class="text-c-gold">${formatFullNum(s * 500)} - ${formatFullNum(s * 700)} Vàng</strong></div>
                <div class="bg-black/40 border border-[var(--gold)]/20 p-2 rounded-lg mb-4 text-[10px]">
                    <div class="flex justify-around">
                        <span><i class="fas fa-khanda text-gray-400 mr-1"></i>Binh sĩ: <strong class="${app.user.troops >= reqT ? 'text-green-400' : 'text-red-400'}">${formatNum(app.user.troops)}</strong>/${formatNum(reqT)}</span>
                        <span class="text-gray-500">|</span>
                        <span><i class="fas fa-drumstick-bite text-orange-400 mr-1"></i>Lương: <strong class="${app.user.food >= reqF ? 'text-green-400' : 'text-red-400'}">${formatNum(app.user.food)}</strong>/${formatNum(reqF)}</span>
                    </div>
                </div>
                <button onclick="App.battle()" class="btn-royal w-full h-[40px] text-[13px] shadow-lg active:scale-95 transition"><i class="fas fa-fire text-red-900 mr-2"></i> XUẤT BINH</button>
            </div>

            <div class="royal-card p-3 shadow-[0_0_15px_rgba(0,0,0,0.8)] border border-[var(--dark-gold)]/50 w-full flex-shrink-0 mb-4">
                <div class="flex items-center justify-between border-b border-[var(--gold)]/20 pb-2 mb-2">
                    <h3 class="font-empire text-[13px] font-black text-[var(--gold)]"><i class="fas fa-user-plus text-red-500 mr-1.5"></i>Binh Bộ Quản Lý</h3>
                </div>
                <div class="grid grid-cols-2 gap-2 mt-2">
                    <button onclick="App.train(${qty1})" class="btn-royal h-[45px] flex flex-col items-center justify-center">
                        <span class="text-[10px] font-black"><i class="fas fa-khanda mr-1"></i> CHIÊU MỘ ${qty1} LÍNH</span>
                        <span class="text-[7.5px] font-bold opacity-80 flex items-center gap-1"><i class="fas fa-drumstick-bite text-orange-800"></i> ${formatNum(cF1)} + ${coinImg} ${formatNum(cG1)}</span>
                    </button>
                    <button onclick="App.train(${qty2})" class="btn-royal h-[45px] flex flex-col items-center justify-center">
                        <span class="text-[10px] font-black"><i class="fas fa-dragon mr-1"></i> CHIÊU MỘ ${qty2} LÍNH</span>
                        <span class="text-[7.5px] font-bold opacity-80 flex items-center gap-1"><i class="fas fa-drumstick-bite text-orange-800"></i> ${formatNum(cF2)} + ${coinImg} ${formatNum(cG2)}</span>
                    </button>
                </div>
                <div class="mt-2 royal-card p-2">
                    <div class="flex gap-2 items-center">
                        <input id="train-custom-qty" type="number" min="1" class="set-input !py-2 text-[10px]" placeholder="Nhập số lính muốn mộ">
                        <button onclick="App.fillTrainMax()" class="btn-royal px-2 h-[34px] text-[9px]">TẤT CẢ</button>
                    </div>
                    <div id="train-custom-cost" class="text-[9px] text-gray-300 mt-1">Tổng phí: --</div>
                    <button onclick="App.trainCustom()" class="btn-royal w-full h-[34px] mt-2 text-[10px]">CHIÊU MỘ THEO SỐ LƯỢNG</button>
                </div>
            </div>
        </div>`;
        setTimeout(()=>app.updateTrainCostPreview(),30);
    },

    async renderInvite(v, app) {
        const friendData = await app.api('/api/friends', { telegram_id: app.user.telegram_id });
        const friends = friendData.success ? friendData.friends : [];
        app.totalFriends = friends.length;
        const link = `https://t.me/VuongTrieuTruyenKyBot?start=${app.user.telegram_id}`;

        let friendsHtml = friends.length === 0 ? '<div class="text-center text-gray-500 py-3 text-[10px]">Chưa có Hảo hữu nào gia nhập.</div>' : friends.map(f => `
            <div class="bg-black/50 p-2 rounded border border-gray-700/60 shadow-inner text-left mb-1.5">
                <div class="font-bold text-[11px] text-[var(--text-main)]"><i class="fas fa-user-circle text-gray-400 mr-1"></i>${f.first_name}</div>
                <div class="text-[9px] text-green-400 mt-1 flex flex-wrap gap-x-2 gap-y-1 border-t border-gray-700/50 pt-1">
                    <span class="text-gray-400 w-full mb-0.5">Thuế Cống Nạp đã nhận:</span>
                    ${f.tax_wood > 0 ? `<span title="Gỗ"><i class="fas fa-tree text-c-dark"></i> ${formatNum(f.tax_wood)}</span>` : ''}
                    ${f.tax_stone > 0 ? `<span title="Đá"><i class="fas fa-cube text-gray-300"></i> ${formatNum(f.tax_stone)}</span>` : ''}
                    ${f.tax_iron > 0 ? `<span title="Sắt"><i class="fas fa-cubes text-gray-400"></i> ${formatNum(f.tax_iron)}</span>` : ''}
                    ${f.tax_dark_iron > 0 ? `<span title="Huyền Thiết"><i class="fas fa-meteor text-purple-400"></i> ${formatNum(f.tax_dark_iron)}</span>` : ''}
                    ${f.tax_jade > 0 ? `<span title="Linh Ngọc"><i class="fas fa-gem text-teal-400"></i> ${formatNum(f.tax_jade)}</span>` : ''}
                    ${f.tax_food > 0 ? `<span title="Lương Thực"><i class="fas fa-drumstick-bite text-orange-400"></i> ${formatNum(f.tax_food)}</span>` : ''}
                </div>
            </div>
        `).join('');

        v.innerHTML = `
        <div class="fade-enter min-h-[85vh] pb-32 w-full">
            <div class="royal-card p-4 text-center mt-4 border-[var(--gold)]/30 shadow-[0_0_15px_rgba(255,215,0,0.1)] w-full">
                <i class="fas fa-envelope-open-text text-4xl text-[var(--gold)] mb-3 drop-shadow-[0_0_10px_rgba(255,215,0,0.5)] mt-1"></i>
                <h3 class="font-empire text-[16px] text-[var(--text-main)] mb-1">Triệu Gọi Chư Hầu</h3>
                <p class="text-[10px] text-gray-400 mb-3 px-1 leading-relaxed">Nhận Vàng ngẫu nhiên và lợi tức nguyên liệu 1 giờ từ hảo hữu mới! Nhận <span class="text-[var(--gold)] font-bold text-[12px]">${app.config.ref_commission ? parseFloat((app.config.ref_commission * 100).toFixed(2)) : 0.3}%</span> Hoa hồng thuế từ Hảo hữu mãi mãi.</p>
                <div class="flex items-center justify-between bg-black/60 border border-[var(--gold)]/30 rounded-lg p-1.5 mb-4 shadow-inner">
                    <span class="text-[10px] text-gray-300 truncate px-2 font-mono flex-1 text-left select-all">${link}</span>
                    <button onclick="App.copyInviteLink()" class="btn-royal h-[30px] px-4 text-[10px] shrink-0"><i class="fas fa-copy mr-1.5"></i> SAO CHÉP</button>
                </div>
                <div class="mt-4 text-left">
                    <h4 class="text-c-gold font-empire mb-2 border-b border-[var(--gold)]/20 pb-1.5 flex justify-between items-center">
                        <span><i class="fas fa-users mr-1"></i> Danh Sách Chư Hầu</span>
                        <span class="text-[var(--text-main)] font-black text-[10px] bg-black/50 px-2 py-0.5 rounded shadow border border-[var(--dark-gold)]/40">${app.totalFriends}</span>
                    </h4>
                    <div class="max-h-[30vh] overflow-y-auto pr-1">${friendsHtml}</div>
                </div>
            </div>
        </div>`;
    },

    async renderSubTab(tab, v, app) {
        let titles = { 'checkin':'Phúc Lợi', 'leaderboard':'Hoàng Cung', 'minigame':'Tiêu Dao Các', 'support':'Truyền Tin', 'bank':'Ngân Khố', 'market':'CHỢ' };
        let content = '';

        if (tab === 'checkin') {
            let td = new Date(new Date().getTime() + 7*3600*1000).toISOString().split('T')[0];
            let streak = app.user.checkin_streak || 0;
            let isClaimed = app.user.last_checkin === td;
            let rw = [5000, 10000, 15000, 20000, 25000, 30000, 50000];
            
            let grid = `<div class="grid grid-cols-4 gap-x-2 gap-y-7 mb-4 mt-2">`;
            for(let i=0; i<7; i++) {
                let d = i+1; let st = '';
                if(d < streak || (d === streak && isClaimed)) st = 'claimed';
                else if(d === streak && !isClaimed) st = 'current';
                else if(d === streak + 1 && isClaimed) st = 'current';
                
                let bg = st==='claimed' ? 'bg-gray-800 opacity-60' : (st==='current' ? 'bg-yellow-900/40 border border-yellow-500 shadow-[0_0_10px_rgba(255,215,0,0.3)]' : 'bg-black/50 border border-gray-800');
                let ic = st==='claimed' ? '<i class="fas fa-check-circle text-green-500 text-xl"></i>' : `<i class="fas fa-gift text-gray-500 text-lg"></i>`;
                if(st==='current') ic = '<i class="fas fa-gift text-yellow-500 text-xl animate-pulse"></i>';
                if(i===6) bg += ' col-span-2 bg-gradient-to-r from-red-900/40 to-yellow-900/40';

                grid += `<div class="rounded-lg p-2 flex flex-col items-center justify-center h-16 relative ${bg}">
                    <span class="absolute top-1 left-1 text-[8px] text-gray-400 font-bold">N.${d}</span>
                    <div class="mt-2">${ic}</div>
                    <span class="absolute -bottom-5 text-[8px] font-bold text-yellow-500 flex items-center justify-center w-full gap-0.5">${formatNum(rw[i])} ${coinImg}</span>
                </div>`;
            }
            grid += `</div>`;

            content = `
            <div class="royal-card p-4 text-center mt-4 w-full mb-4">
                <h3 class="font-empire text-[16px] text-c-gold mb-4 border-b border-gray-700 pb-2">Điểm Danh 7 Ngày</h3>
                ${grid}
                <div class="mt-8"><button onclick="App.checkIn()" class="btn-royal w-full h-[45px] text-[13px] shadow-lg" ${isClaimed?'disabled':''}><i class="fas fa-check-circle mr-2"></i> ${isClaimed?'ĐÃ NHẬN HÔM NAY':'NHẬN BỔNG LỘC'}</button></div>
            </div>
            <div class="royal-card p-4 text-center w-full">
                <i class="fas fa-ticket-alt text-4xl text-purple-500 mb-2 mt-1"></i>
                <h3 class="font-empire text-[16px] text-c-gold mb-3">Cống Phẩm Hoàng Gia</h3>
                <input type="text" id="inp-giftcode" class="set-input text-center text-[13px] font-bold py-2.5 mb-3 uppercase" placeholder="NHẬP MÃ CỐNG PHẨM...">
                <button onclick="App.submitGiftcode()" class="btn-royal w-full h-[45px] text-[13px] shadow-lg"><i class="fas fa-check-circle mr-2"></i> XÁC NHẬN MÃ</button>
            </div>
            <div class="w-full h-24 flex-shrink-0 pointer-events-none"></div>
            `;
        }
        else if (tab === 'support') {
            content = `<div class="royal-card p-2 w-full mt-2 h-[70vh] flex flex-col relative">
                <h3 class="font-empire text-c-gold border-b border-gray-700 pb-2 mb-2 text-center text-sm"><i class="fas fa-headset mr-1"></i> Tấu Chương</h3>
                <div id="chat-box" class="flex-1 overflow-y-auto p-2 space-y-3 bg-black/40 rounded border border-gray-800 shadow-inner">
                    <div class="text-center text-gray-500 text-[10px] mt-4"><i class="fas fa-spinner fa-spin text-xl"></i> Đang kết nối...</div>
                </div>
                <div class="flex gap-2 mt-2 pt-2 border-t border-[var(--gold)]/20 relative z-10 bg-[var(--card-bg)]">
                    <input type="text" id="chat-input" class="set-input flex-1 !py-2.5" placeholder="Gửi thỉnh cầu tới Quan Phủ...">
                    <button onclick="App.sendChat()" class="btn-royal px-4 h-[35px] shrink-0"><i class="fas fa-paper-plane text-lg"></i></button>
                </div>
            </div>`;
            setTimeout(() => app.loadChat(), 100);
        }
        else if (tab === 'minigame') {
            content = `<div class="grid grid-cols-2 gap-3 mt-4 w-full"><div class="royal-card p-3 text-center cursor-pointer" onclick="App.openModal('spin')"><i class="fas fa-dharmachakra text-3xl text-yellow-500 mb-2"></i><h3 class="font-empire text-c-gold text-[12px]">Vòng Quay</h3></div><div class="royal-card p-3 text-center cursor-pointer" onclick="App.openModal('dice')"><i class="fas fa-dice text-3xl text-red-500 mb-2"></i><h3 class="font-empire text-c-gold text-[12px]">Lớn nhỏ</h3></div><div class="royal-card p-3 text-center cursor-pointer" onclick="App.openModal('flip')"><i class="fas fa-clone text-3xl text-blue-500 mb-2"></i><h3 class="font-empire text-c-gold text-[12px]">Lật Bài</h3></div><div class="royal-card p-3 text-center cursor-pointer" onclick="App.openModal('race')"><i class="fas fa-horse-head text-3xl text-green-500 mb-2"></i><h3 class="font-empire text-c-gold text-[12px]">Đua Ngựa</h3></div></div>`;
        }
        else if (tab === 'bank') {
            let savedBank = localStorage.getItem('user_bank') || 'Chưa thiết lập';
            if (savedBank !== 'Chưa thiết lập') savedBank = savedBank.replace(/ \| /g, '<br>');
            
            content = `
            <div class="royal-card p-4 text-center mt-4 w-full">
                <i class="fas fa-money-bill-wave text-4xl text-green-500 mb-2"></i>
                <h3 class="font-empire text-[var(--text-main)] mb-1 text-[14px]">Xuất Khố Ngân Hàng</h3>
                <div class="text-[11px] text-[var(--dark-gold)] font-black mb-3 bg-black/30 py-1 rounded border border-[var(--gold)]/50 flex items-center justify-center gap-1 w-fit mx-auto px-3">${coinImg} 1,000,000 = 10,000 VNĐ</div>
                <div class="bg-black/50 p-2.5 rounded border border-[var(--gold)]/20 mb-4 text-left shadow-inner">
                    <div class="flex justify-between items-center mb-1">
                        <span class="text-[9px] text-gray-400">Thông tin nhận tiền:</span>
                        <button onclick="App.switchTab('settings')" class="text-[9px] text-blue-400 underline font-bold">Thay đổi</button>
                    </div>
                    <div class="text-[11px] font-bold text-c-gold leading-relaxed">${savedBank}</div>
                </div>
                <input type="number" id="wd-a" class="set-input text-center text-[13px] font-bold py-2.5 mb-3" placeholder="Nhập số Vàng (Tối thiểu 1M)...">
                <button onclick="App.withdraw()" class="btn-royal w-full h-[45px] text-[12px]"><i class="fas fa-paper-plane mr-1.5"></i> GỬI LỆNH RÚT</button>
                
                <div class="mt-5 text-left border-t border-[var(--gold)]/20 pt-3" id="wd-history-box"><div class="text-center text-gray-500 text-[10px]"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div></div>
                
                <div class="w-full h-24 bg-transparent pointer-events-none"></div>

            </div>`;
            setTimeout(() => app.loadWithdrawHistory(), 100);
        } else if (tab === 'leaderboard') {

            content = '<div class="text-center py-10 w-full"><i class="fas fa-spinner fa-spin text-c-gold text-3xl"></i></div>';
        } else if (tab === 'market') {
            content = `<div id="market-container" class="w-full"></div>`;
        }
        
        v.innerHTML = `<div class="fade-enter flex flex-col items-center justify-start relative w-full mt-2 px-1 min-h-[85vh] pb-32"><div class="w-full flex items-center mb-4 border-b border-[var(--gold)]/20 pb-3"><button onclick="App.switchTab('home')" class="text-c-gold text-2xl px-3"><i class="fas fa-arrow-left"></i></button><h3 class="font-empire text-c-gold text-[16px] flex-1 pr-10 text-center uppercase">${titles[tab]}</h3></div><div class="w-full max-w-[360px] flex-1">${content}</div></div>`;
        
        if (tab === 'leaderboard') { 
            const type = app.lbType || 'palace';
            const d = await(await fetch(`/api/leaderboard?type=${type}`)).json(); 
            let lbHtml = `<div class="royal-card p-2 text-[10px]">
                <div class="flex gap-1 mb-2">
                    <button onclick="App.setLeaderboardType('palace')" class="hist-tab ${type==='palace'?'active':''}">Hoàng Cung</button>
                    <button onclick="App.setLeaderboardType('stage')" class="hist-tab ${type==='stage'?'active':''}">Ải</button>
                </div>
                <div class="flex justify-between font-bold text-c-dark border-b border-[var(--gold)]/30 pb-1.5 mb-1 px-1">
                    <span class="w-7 text-center">Hạng</span>
                    <span class="flex-1 text-left">Hoàng Đế</span>
                    <span class="w-16 text-center whitespace-nowrap">${type==='stage'?'Ải':'Hoàng Cung'}</span>
                    <span class="w-[70px] text-right">${type==='stage'?'Vàng':'Lãi/h'}</span>
                </div>`;
            d.leaderboard.forEach((u, i) => {
                let avaName = u.hide_avatar ? "Ẩn+Danh" : encodeURIComponent(u.first_name);
                let displayName = u.hide_avatar ? "Hoàng Đế Ẩn Danh" : u.first_name;
                let avaUrl = `https://ui-avatars.com/api/?name=${avaName}&background=1a1100&color=FFD700&bold=true`; 
                
                lbHtml += `<div onclick="App.showPlayerOptions('${u.telegram_id}', '${displayName}', ${u.hide_avatar})" class="flex justify-between items-center py-2 border-b border-[var(--gold)]/10 active:bg-white/10 transition cursor-pointer px-1">
                    <span class="w-7 text-center text-c-gold font-bold">#${i+1}</span>
                    <span class="flex-1 text-left text-[var(--text-main)] truncate pr-2 flex items-center gap-1.5">
                        <img src="${avaUrl}" class="w-4 h-4 rounded-full border border-[var(--dark-gold)]">
                        ${displayName}
                    </span>
                    <span class="w-16 text-center text-c-gold font-bold">${type==='stage'?'Ải '+(u.current_stage||1):'Lv.'+(u.palace_level||1)}</span>
                    <span class="w-[70px] text-right text-c-gold font-bold flex items-center justify-end gap-0.5">${coinImg} ${formatFullNum(type==='stage'?(u.gold||0):(u.gold_rate||0))}</span>
                </div>`;
            });
            lbHtml += `</div>
            <p class="text-center text-gray-500 text-[9px] italic mt-2">Chạm vào tên người chơi để xem chi tiết</p>
            <div class="w-full h-24 bg-transparent pointer-events-none"></div>`;
            v.querySelector('.max-w-\\[360px\\]').innerHTML = lbHtml; 
        } else if (tab === 'market') {
            setTimeout(() => MarketSystem.init(), 80);
        }
    }
};

const App = {
    tg: window.Telegram.WebApp, user: {}, catalog: [], inventory: [], config: {}, tapQueue: { wood: 0, stone: 0, iron: 0, dark_iron: 0, jade: 0, glaze: 0, purple_gold: 0, total: 0 },
    friendsList: [], totalFriends: 0, currentMerchantModal: '', lastScoutedUser: null, chatSource: null,
    historyFilter: 'all', announcementsQueue: [],

    adsgramController: null,

    THEMES: {
        default: { gold: '#FFD700', dark: '#D4AF37', bg: '#0a0804', silk: '#261b07', card: 'rgba(10, 7, 0, 0.85)', btnTxt: '#2b1d00', textMain: '#fdf6e3', textMuted: '#9ca3af' },
        light: { gold: '#D4AF37', dark: '#B8860B', bg: '#FDFBF7', silk: '#FFFFFF', card: 'rgba(255, 255, 255, 0.95)', btnTxt: '#ffffff', textMain: '#2C1E00', textMuted: '#6B5E40' },
        black: { gold: '#d4d4d4', dark: '#555555', bg: '#000000', silk: '#111111', card: 'rgba(15, 15, 15, 0.9)', btnTxt: '#000000', textMain: '#ffffff', textMuted: '#888888' },
        blood: { gold: '#ff6b6b', dark: '#910000', bg: '#1a0505', silk: '#3a0a0a', card: 'rgba(30, 5, 5, 0.85)', btnTxt: '#fff', textMain: '#ffeaea', textMuted: '#cc8888' },
        shadow: { gold: '#b19cd9', dark: '#4b0082', bg: '#050510', silk: '#10102a', card: 'rgba(10, 10, 25, 0.85)', btnTxt: '#fff', textMain: '#eaeaff', textMuted: '#8888cc' },
        ocean: { gold: '#4da6ff', dark: '#004d99', bg: '#050a14', silk: '#0a1428', card: 'rgba(5, 15, 30, 0.85)', btnTxt: '#fff', textMain: '#eaf4ff', textMuted: '#88bbcc' },
        emerald: { gold: '#5cd65c', dark: '#1f7a1f', bg: '#051405', silk: '#0a290a', card: 'rgba(5, 25, 5, 0.85)', btnTxt: '#fff', textMain: '#eaffea', textMuted: '#88cc88' }
    },

    applyTheme(t) {
        const root = document.documentElement; const colors = this.THEMES[t] || this.THEMES.default;
        root.style.setProperty('--gold', colors.gold); root.style.setProperty('--dark-gold', colors.dark); root.style.setProperty('--royal-bg', colors.bg); root.style.setProperty('--silk-bg', colors.silk); root.style.setProperty('--card-bg', colors.card); root.style.setProperty('--btn-text', colors.btnTxt);
        if (colors.textMain) root.style.setProperty('--text-main', colors.textMain);
        if (colors.textMuted) root.style.setProperty('--text-muted', colors.textMuted);
        
        let styleTag = document.getElementById('dynamic-theme'); if(!styleTag) { styleTag = document.createElement('style'); styleTag.id = 'dynamic-theme'; document.head.appendChild(styleTag); }
        
        let css = '';
        if(t !== 'default') { 
            css += `.btn-royal { background: linear-gradient(180deg, #fff 0%, ${colors.gold} 20%, ${colors.dark} 70%, ${colors.dark} 100%) !important; border-color: rgba(255,255,255,0.2) !important; color: ${colors.btnTxt} !important; }\n`; 
        }

        css += `
            .text-gray-300, .text-gray-400, .text-gray-500, .text-gray-600 { color: var(--text-muted) !important; }
            #ann-text { color: var(--text-main) !important; font-weight: 600; }
            .hist-tab { background: var(--royal-bg) !important; color: var(--text-muted) !important; border: 1px solid var(--text-muted) !important; opacity: 0.7; }
            .hist-tab.active { background: var(--gold) !important; color: var(--btn-text) !important; border: 1px solid var(--gold) !important; opacity: 1; font-weight: 900; }
        `;

        if(t === 'light') {
            css += `
            .bg-black\\/30, .bg-black\\/40, .bg-black\\/50, .bg-black\\/60, .bg-black\\/80, .bg-gray-800, #ann-image-box { background-color: rgba(0,0,0,0.04) !important; box-shadow: none !important; }
            .border-gray-600, .border-gray-700\\/50, .border-gray-700\\/60, .border-gray-800 { border-color: rgba(212,175,55,0.2) !important; }
            `;
        }

        styleTag.innerHTML = css;
    },
    toggleMenuMode() {
        this.altMenuMode = !this.altMenuMode;
        const mainNav = document.getElementById('hub-main');
        const altNav = document.getElementById('hub-alt');
        const textSpan = document.getElementById('menu-swap-text');

        if (this.altMenuMode) {
            mainNav.classList.add('hidden'); 
            altNav.classList.remove('hidden');
            if(textSpan) textSpan.innerText = "Menu Phụ";
        } else {
            mainNav.classList.remove('hidden'); 
            altNav.classList.add('hidden');
            if(textSpan) textSpan.innerText = "Menu Chính";
        }
    },
    setLeaderboardType(type) {
        this.lbType = type;
        if(this.currentTab === 'leaderboard') this.switchTab('leaderboard');
    },
    
    changeTheme(t) { localStorage.setItem('user_theme', t); this.applyTheme(t); this.toast('Thay y phục thành công!', 'success'); this.renderSettings('main'); },

    async init(isFirstLoad = false) {
        if (window.Adsgram) {
            this.adsgramController = window.Adsgram.init({ blockId: "int-28961" });
        }

        this.tg.expand(); if(this.tg.disableVerticalSwipes) this.tg.disableVerticalSwipes();
        const savedTheme = localStorage.getItem('user_theme') || 'default'; this.applyTheme(savedTheme);
        this.user.telegram_id = this.tg.initDataUnsafe?.user?.id?.toString() || "12345";
        
        const savedAlias = localStorage.getItem('user_alias');
        this.user.first_name = savedAlias || (this.tg.initDataUnsafe?.user?.first_name || "Hoàng Đế");
        
        let startParam = this.tg.initDataUnsafe?.start_param || "";
        if (!startParam) {
            const urlParams = new URLSearchParams(window.location.search);
            startParam = urlParams.get('start_param') || "";
        }
        
        document.getElementById('ui-name').innerText = this.user.first_name; 
        document.getElementById('ui-id').innerText = this.user.telegram_id; 
        
        let d;
        if (isFirstLoad) {
            const loader = document.getElementById('app-loading');
            const pBar = document.getElementById('loading-progress');
            const pText = document.getElementById('loading-percent');
            
            if (loader && pBar && pText) {
                loader.style.opacity = '1'; loader.style.display = 'flex';
                let pt = 0;
                await new Promise(resolve => {
                    const tId = setInterval(() => {
                        pt += Math.floor(Math.random() * 15) + 5;
                        if(pt >= 100) {
                            pt = 100; clearInterval(tId);
                            pBar.style.width = '100%'; pText.innerText = '100%';
                            setTimeout(resolve, 800); 
                        } else {
                            pBar.style.width = pt + '%'; pText.innerText = pt + '%';
                        }
                    }, 150);
                });
            }

            d = await this.api('/api/user', { start_param: startParam, device_code: window.DEVICE_CODE });
            if (loader) { loader.style.opacity = '0'; setTimeout(() => loader.style.display = 'none', 500); }
            
            try {
                const annRes = await fetch('/api/announcements').then(r => r.json());
                if (annRes && annRes.success && annRes.announcements.length > 0) {
                    const hideDate = localStorage.getItem('hide_ann_today');
                    if (hideDate !== new Date().toLocaleDateString()) {
                        this.announcementsQueue = annRes.announcements; setTimeout(() => this.showNextAnnouncement(), 800);
                    }
                }
            } catch(e) { console.log("Lỗi thông báo", e); }
        } else {
            d = await this.api('/api/user', { start_param: startParam, device_code: window.DEVICE_CODE });
        }

        if(d.is_banned) {
            const banScreen = document.getElementById('ban-screen');
            if(banScreen) {
                banScreen.classList.replace('hidden', 'flex');
                banScreen.innerHTML = `<div class="bg-black/90 p-6 rounded-xl border border-red-500 shadow-[0_0_20px_red] text-center max-w-sm mx-4"><i class="fas fa-user-slash text-5xl text-red-500 mb-4 animate-pulse"></i><h2 class="text-xl font-black text-red-400 mb-2 font-empire">TƯỚC LỆNH BÀI</h2><p class="text-gray-300 text-sm font-bold leading-relaxed">${d.msg || 'Tài khoản của ngài đã bị phong ấn!'}</p></div>`;
            }
            return;
        }

        if(d.success) { 
            this.user = { ...this.user, ...d.user }; 
            this.config = d.config || { 
                cost_tap: 50000, cost_energy: 50000, cost_regen: 100000,
                train_qty_1: 5, train_qty_2: 25, train_cost_food: 10, train_cost_gold: 100,
                battle_base_troops: 5, battle_troops_step: 1, battle_base_food: 20, battle_food_step: 5
            };
            if(savedAlias) this.user.first_name = savedAlias;
            
            const avaUrl = this.user.hide_avatar ? `https://ui-avatars.com/api/?name=${encodeURIComponent(this.user.first_name)}&background=1a1100&color=FFD700&bold=true` : (this.tg.initDataUnsafe?.user?.photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(this.user.first_name)}&background=1a1100&color=FFD700&bold=true`);
            document.getElementById('ui-avatar').src = avaUrl;
            
            this.catalog = d.catalog || []; this.inventory = d.user.inventory || []; 
            
            // CẬP NHẬT: Fix lỗi trắng màn hình
            this.currentTab = this.currentTab || 'home'; 
            
            if(!['checkin', 'leaderboard', 'minigame', 'support', 'bank'].includes(this.currentTab)) {
                this.switchTab(this.currentTab); 
            } else {
                this.switchTab('home');
            }
            this.updateUI();
        }
        
        if(!this._intervalsStarted) {
            this._intervalsStarted = true;
            Fab.init();

            setInterval(() => { 
                if(this.user.rate > 0) this.user.gold += (this.user.rate / 3600); 
                if(this.user.food_rate > 0) this.user.food += (this.user.food_rate / 3600); 
                
                this.catalog.forEach(b => {
                    const key = b.effect_type;
                    if(!['troops', 'winrate', 'save_troops', 'energy_regen', 'discount_train', 'gold', 'food'].includes(key)) {
                        const rateKey = `${key}_rate`;
                        if(this.user[rateKey] > 0) this.user[key] = (this.user[key] || 0) + (this.user[rateKey] / 3600);
                    }
                });

                let maxE = Number(this.user.max_energy || 1000); 
                let currentE = Number(this.user.energy || 0);
                let regen = Number(this.user.total_regen || 1); 

                if (currentE < maxE) {
                    currentE += regen;
                    if (currentE > maxE) currentE = maxE;
                    this.user.energy = currentE;
                }
                
                this.updateUI();
            }, 1000);

            setInterval(() => {
                if (this.user.ad_autotap_end && Date.now() < this.user.ad_autotap_end) {
                    if (Number(this.user.energy) >= Number(this.user.tap_level || 1)) {
                        if (typeof this.tap === 'function') {
                            this.tap(null);
                        }
                    }
                }
            }, 500);

            setInterval(() => { if(this.tapQueue.total > 0) this.syncTaps(); }, 1500);
            setInterval(() => this.renderDynamicTimers(), 1000);
        }
    },
    
    showNextAnnouncement() {
        if (!this.announcementsQueue || this.announcementsQueue.length === 0) {
            document.getElementById('announcement-modal').classList.replace('flex', 'hidden');
            return;
        }
        const ann = this.announcementsQueue[0];
        const modal = document.getElementById('announcement-modal');
        const imgBox = document.getElementById('ann-image-box');
        const title = document.getElementById('ann-title');
        const text = document.getElementById('ann-text');
        const btnBox = document.getElementById('ann-btn-box');
        
        if (ann.image && ann.image !== '') {
            imgBox.innerHTML = `<img src="${ann.image}" class="w-full h-auto object-cover max-h-[160px] border-b border-[var(--gold)]/20">`;
            imgBox.style.display = 'block';
        } else {
            imgBox.style.display = 'none';
        }
        
        title.innerText = "SẮC LỆNH TỪ HOÀNG CUNG";
        text.innerText = ann.text;
        
        if (ann.btn_text && ann.btn_link) {
            btnBox.innerHTML = `<button onclick="window.open('${ann.btn_link}', '_blank')" class="btn-royal w-full h-[42px] text-[12px] shadow-md"><i class="fas fa-link mr-2"></i>${ann.btn_text}</button>`;
            btnBox.classList.remove('hidden');
        } else {
            btnBox.classList.add('hidden');
        }
        
        document.getElementById('ann-hide-today').checked = false;
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    },
    
    closeAnnouncement() {
        const hideCb = document.getElementById('ann-hide-today');
        if (hideCb && hideCb.checked) {
            localStorage.setItem('hide_ann_today', new Date().toLocaleDateString());
            this.announcementsQueue = []; 
        } else {
            this.announcementsQueue.shift(); 
        }
        const modal = document.getElementById('announcement-modal');
        modal.classList.replace('flex', 'hidden');
        
        if (this.announcementsQueue && this.announcementsQueue.length > 0) {
            setTimeout(() => this.showNextAnnouncement(), 300);
        }
    },

    updateUI() {
        const s = (id, v) => { const e = document.getElementById(id); if(e) e.innerText = v; };
        
        s('ui-gold', formatFullNum(this.user.gold || 0)); 
        s('ui-rate', formatFullNum(this.user.rate || 0)); 

        s('ui-wood-full', formatFullNum(this.user.wood || 0));
        s('ui-stone-full', formatFullNum(this.user.stone || 0));
        s('ui-iron-full', formatFullNum(this.user.iron || 0));
        s('ui-darkiron-full', formatFullNum(this.user.dark_iron || 0));
        s('ui-jade-full', formatFullNum(this.user.jade || 0));
        s('ui-glaze-full', formatFullNum(this.user.glaze || 0));
        s('ui-purplegold-full', formatFullNum(this.user.purple_gold || 0));
        s('ui-food-full', formatFullNum(this.user.food || 0));
        s('ui-troops-full', formatFullNum(this.user.troops || 0)); 
        s('ui-max-troops-full', formatFullNum(this.user.max_troops || 50));

        const eText = document.getElementById('ui-energy'), eBar = document.getElementById('ui-energy-bar');
        if(eText) eText.innerText = `${formatFullNum(Math.floor(this.user.energy))} / ${formatFullNum(this.user.max_energy)} (+${this.user.total_regen || 1}/s)`;
        if(eBar) eBar.style.width = `${(this.user.energy / this.user.max_energy) * 100}%`;
    },

    toggleResourceMenu() {
        const content = document.getElementById('resource-dropdown-content');
        const arrow = document.getElementById('resource-arrow');

        if (content.style.maxHeight && content.style.maxHeight !== '0px') {
            content.style.maxHeight = '0px';
            arrow.style.transform = 'rotate(0deg)';
        } else {
            content.style.maxHeight = content.scrollHeight + 'px';
            arrow.style.transform = 'rotate(180deg)';
        }
    },

    toast(msg, type = 'info') {
        const b = document.getElementById('toast-box'); b.innerHTML = '';
        const t = document.createElement('div');
        let icon = 'fa-exclamation-circle text-yellow-500';
        let bg = 'bg-[var(--card-bg)] border-yellow-500/50';
        if(type === 'success') { icon = 'fa-check-circle text-green-500'; bg = 'bg-[var(--card-bg)] border-green-500/50'; }
        else if(type === 'error') { icon = 'fa-times-circle text-red-500'; bg = 'bg-[var(--card-bg)] border-red-500/50'; }

        t.className = `toast royal-box ${bg} text-[var(--text-main)] p-3.5 rounded-lg mb-1 text-center text-[13px] font-bold shadow-2xl flex items-center justify-center gap-2.5 border w-full max-w-sm mx-auto z-[9999]`;
        t.innerHTML = `<i class="fas ${icon} text-lg"></i> <span class="leading-tight">${msg}</span>`;
        b.appendChild(t); setTimeout(() => t.remove(), 3000);
    },
    
    async api(p, b) { 
        try { 
            const initData = window.Telegram.WebApp.initData || ""; 
            
            const r = await fetch(p, { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify({ 
                    telegram_id: this.user.telegram_id, 
                    first_name: this.user.first_name, 
                    hide_avatar: this.user.hide_avatar ? 1 : 0, 
                    initData: initData, 
                    ...b 
                }) 
            }); 
            return await r.json(); 
        } catch(e) { 
            this.toast("Mất kết nối máy chủ, xin thử lại!", 'error'); return {success: false, msg: "Tín hiệu truyền tin bị gián đoạn!"}; 
        } 
    },
    
    async syncTaps() { 
        if (this.tapQueue.total === 0) return; 
        const q = { ...this.tapQueue }; this.tapQueue = { wood: 0, stone: 0, iron: 0, dark_iron: 0, jade: 0, glaze: 0, purple_gold: 0, total: 0 }; 
        await this.api('/api/tap', { taps: q.total, wood_taps: q.wood || 0, stone_taps: q.stone || 0, iron_taps: q.iron || 0, dark_iron_taps: q.dark_iron || 0, jade_taps: q.jade || 0, glaze_taps: q.glaze || 0, purple_gold_taps: q.purple_gold || 0 }); 
    },

    // CẬP NHẬT: Giao diện Sao Kê Lịch Sử Ngân Hàng
    async loadHistory() {
        const d = await this.api('/api/history', {});
        const box = document.getElementById('home-history-list');
        if(!box) return;

        // CHỈ ẨN đúng hàng nút lọc cũ (Gỗ, Đá, Sắt...), không ẩn cả giao diện
        const oldFilterBox = box.previousElementSibling;
        if (oldFilterBox && !oldFilterBox.id) { 
            oldFilterBox.style.display = 'none';
        }

        // Chèn thanh Sao Kê mới nếu chưa có
        if(!document.getElementById('new-history-tabs')) {
            const newTabsHtml = `
                <div id="new-history-tabs" class="flex gap-1 border-b border-[var(--gold)]/30 mb-3 px-1 mt-1">
                    <button id="h-tab-all" onclick="App.setHistoryFilter('all')" class="flex-1 pb-1.5 text-[11px] font-bold text-c-gold border-b-2 border-[var(--gold)]">Tất Cả</button>
                    <button id="h-tab-income" onclick="App.setHistoryFilter('income')" class="flex-1 pb-1.5 text-[11px] font-bold text-[var(--text-muted)]">Thu (+)</button>
                    <button id="h-tab-expense" onclick="App.setHistoryFilter('expense')" class="flex-1 pb-1.5 text-[11px] font-bold text-[var(--text-muted)]">Chi (-)</button>
                    <button id="h-tab-referral" onclick="App.setHistoryFilter('referral')" class="flex-1 pb-1.5 text-[11px] font-bold text-[var(--text-muted)]">Chư Hầu</button>
                </div>`;
            box.insertAdjacentHTML('beforebegin', newTabsHtml);
        }

        this.historyDataCache = d.history || [];
        this.setHistoryFilter(this.currentHistoryFilter || 'all'); 
    },

    setHistoryFilter(filter) {
        this.currentHistoryFilter = filter;
        ['all', 'income', 'expense', 'referral'].forEach(t => {
            const btn = document.getElementById(`h-tab-${t}`);
            if(btn) {
                btn.className = (t === filter) 
                    ? "flex-1 pb-1.5 text-[11px] font-bold text-c-gold border-b-2 border-[var(--gold)] transition-all"
                    : "flex-1 pb-1.5 text-[11px] font-bold text-[var(--text-muted)] border-b-2 border-transparent transition-all";
            }
        });

        const box = document.getElementById('home-history-list'); if(!box) return;

        const resMap = { 
            gold: { name: 'Vàng', color: 'text-yellow-400' }, wood: { name: 'Gỗ', color: 'text-[#D4AF37]' },
            stone: { name: 'Đá', color: 'text-gray-300' }, iron: { name: 'Sắt', color: 'text-gray-400' },
            dark_iron: { name: 'H.Thiết', color: 'text-purple-400' }, jade: { name: 'L.Ngọc', color: 'text-teal-400' },
            glaze: { name: 'Lưu Ly', color: 'text-blue-300' }, purple_gold: { name: 'Tử Kim', color: 'text-purple-600' },
            troops: { name: 'Lính', color: 'text-red-400' }, food: { name: 'L.Thực', color: 'text-orange-400' }, none: { name: '', color: 'text-gray-400' }
        };

        let list = this.historyDataCache || [];
        if (filter === 'income') list = list.filter(h => h.type === 'income');
        else if (filter === 'expense') list = list.filter(h => h.type === 'expense');
        else if (filter === 'referral') list = list.filter(h => h.action === 'referral' || h.action === 'tax');

        if(list.length === 0) { box.innerHTML = '<div class="text-center py-6 text-gray-400 text-[11px]">Trống.</div>'; return; }

        box.innerHTML = list.map(h => {
            const res = resMap[h.resource_type] || resMap.none;
            const amtStr = h.amount > 0 ? formatFullNum(h.amount) : '';
            const balStr = h.balance > 0 ? formatFullNum(h.balance) : '';
            let iconUI = h.type === 'income' ? '<i class="fas fa-arrow-down text-green-400"></i>' : (h.type === 'expense' ? '<i class="fas fa-arrow-up text-red-400"></i>' : '<i class="fas fa-info text-gray-400"></i>');
            let amtUI = h.type === 'income' ? `<div class="text-green-400 font-bold">+${amtStr}</div>` : (h.type === 'expense' ? `<div class="text-red-400 font-bold">-${amtStr}</div>` : '');

            return `<div class="border-b border-[var(--gold)]/20 py-2.5 flex items-center gap-3">
                <div class="w-7 h-7 rounded-full bg-black/40 border border-gray-700 flex items-center justify-center shrink-0">${iconUI}</div>
                <div class="flex-1 text-left">
                    <div class="text-[11px] text-[var(--text-main)] font-bold">${(h.details||'').replace(/([0-9][0-9,\.]*)/g, '<b class="text-white">$1</b>')}</div>
                    <div class="text-[8px] text-gray-500">${new Date(h.created_at).toLocaleString('vi-VN')}</div>
                </div>
                <div class="text-right">
                    <div class="text-[12px]">${amtUI}</div>
                    <div class="text-[8px] text-gray-500">Dư: <span class="${res.color}">${balStr}</span></div>
                </div>
            </div>`;
        }).join('');
    },

    async loadWithdrawHistory() {
        const d = await this.api('/api/withdraw/history', {});
        const box = document.getElementById('wd-history-box');
        if(!box) return;
        if(d.success && d.list.length > 0) {
            box.innerHTML = `<h4 class="text-c-gold font-empire mb-3 text-[14px]"><i class="fas fa-history"></i> Lịch Sử Lệnh Rút</h4><div class="space-y-3 max-h-[40vh] overflow-y-auto pr-1">` + 
            d.list.map(w => {
                let st = w.status === 'PENDING' ? '<span class="text-yellow-500 bg-yellow-900/40 border border-yellow-500/50 px-2 py-1 rounded">Chờ duyệt</span>' : (w.status === 'COMPLETED' ? '<span class="text-green-500 bg-green-900/40 border border-green-500/50 px-2 py-1 rounded">Thành công</span>' : '<span class="text-red-500 bg-red-900/40 border border-red-500/50 px-2 py-1 rounded">Từ chối</span>');
                let reason = w.status === 'REJECTED' && w.reject_reason ? `<div class="text-[12px] text-[var(--text-main)] mt-2 bg-red-950/80 p-2 rounded-md border border-red-500 font-bold">Lý do: ${w.reject_reason} ${w.is_refunded ? '(Đã hoàn tiền)' : ''}</div>` : '';
                
                return `<div class="bg-[var(--card-bg)] p-3.5 rounded-lg border border-[var(--gold)]/40 shadow-lg">
                            <div class="flex justify-between font-black text-[13px] items-center mb-2">
                                <span class="text-c-gold text-[14px]">${w.amount.toLocaleString()} Vàng</span>${st}
                            </div>
                            <div class="text-[12px] text-[var(--text-main)] font-bold opacity-90">${new Date(w.created_at).toLocaleString()}</div>
                            ${reason}
                        </div>`;
            }).join('') + `</div>`;
        } else {
            box.innerHTML = `<h4 class="text-c-gold font-empire mb-2 text-[14px]"><i class="fas fa-history"></i> Lịch Sử Lệnh Rút</h4><div class="text-center text-[var(--text-main)] text-[12px] py-4 font-bold">Chưa có giao dịch nào.</div>`;
        }
    },

    async loadChat() {
        const box = document.getElementById('chat-box');
        if(!box) return;
        
        box.innerHTML = '<div class="text-center text-[var(--text-muted)] text-[10px] mt-4"><i class="fas fa-spinner fa-spin text-xl mb-2"></i><br>Đang tải thư tín...</div>';

        if (this.chatSource) { this.chatSource.close(); this.chatSource = null; }
        if (this.chatInterval) { clearInterval(this.chatInterval); }

        await this.refreshChat();

        this.chatInterval = setInterval(() => {
            if (this.currentTab === 'support') {
                this.refreshChat(true); 
            } else {
                clearInterval(this.chatInterval);
                this.chatInterval = null;
            }
        }, 2000);
    },

    async refreshChat(silent = false) {
        try {
            const d = await this.api('/api/chat/messages', {});
            if(d && d.success) {
                this.renderChatMessages(d.messages, silent);
            }
        } catch(e) {
            console.log("Lỗi tải chat", e);
        }
    },

    renderChatMessages(messages, silent = false) {
        const box = document.getElementById('chat-box');
        if(!box) return;
        
        if(messages && messages.length > 0) {
            const isAtBottom = box.scrollHeight - box.scrollTop <= box.clientHeight + 50;
            
            box.innerHTML = messages.map(m => {
                const isUser = m.sender === 'user';
                return `<div class="flex w-full ${isUser?'justify-end':'justify-start'}"><div class="max-w-[85%] p-2.5 rounded-lg text-[11px] leading-relaxed shadow-md ${isUser?'bg-blue-900/60 text-blue-100 border border-blue-700/50 rounded-br-none':'bg-[var(--card-bg)] text-[var(--text-main)] font-medium border border-[var(--gold)]/50 rounded-bl-none'}">${m.message}<div class="text-[7px] ${isUser?'text-gray-400':'text-[var(--text-muted)]'} mt-1 text-right font-bold">${new Date(m.created_at).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</div></div></div>`;
            }).join('');
            
            if(!silent || isAtBottom) {
                setTimeout(() => box.scrollTop = box.scrollHeight, 50);
            }
        } else {
            box.innerHTML = '<div class="text-center text-gray-500 text-[10px] mt-4">Chưa có đoạn chat nào. Hãy gửi lời chào tới Quan Phủ!</div>';
        }
    },

    async sendChat() {
        const inp = document.getElementById('chat-input');
        const msg = inp.value.trim(); if(!msg) return;
        
        inp.value = ''; 
        await this.api('/api/chat/send', { message: msg });
        await this.refreshChat(); 
    },
    
    async saveProfile() { 
        const alias = document.getElementById('set-alias').value.trim(); 
        if(alias !== '') { 
            localStorage.setItem('user_alias', alias); 
            this.user.first_name = alias; 
        } else {
            localStorage.removeItem('user_alias');
            this.user.first_name = this.tg.initDataUnsafe?.user?.first_name || "Hoàng Đế";
        }
        document.getElementById('ui-name').innerText = this.user.first_name; 

        localStorage.setItem('user_phone', document.getElementById('set-phone').value); 
        localStorage.setItem('user_mail', document.getElementById('set-mail').value); 
        localStorage.setItem('user_tele', document.getElementById('set-tele').value); 
        
        const bio = document.getElementById('set-bio')?.value?.trim() || '';
        const contact_tg = document.getElementById('set-tele')?.value?.trim() || '';
        
        if (contact_tg && !contact_tg.startsWith('@')) {
            return this.toast('Telegram Username bắt buộc phải bắt đầu bằng chữ @', 'error');
        }

        const d = await this.api('/api/update_profile', { first_name: this.user.first_name, hide_avatar: this.user.hide_avatar ? 1 : 0, bio, contact_tg });
        if (!d.success) return this.toast(d.msg || 'Cập nhật thất bại', 'error');
        
        this.user.contact_tg = contact_tg;
        const avaUrl = this.user.hide_avatar ? `https://ui-avatars.com/api/?name=${encodeURIComponent(this.user.first_name)}&background=1a1100&color=FFD700&bold=true` : (this.tg.initDataUnsafe?.user?.photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(this.user.first_name)}&background=1a1100&color=FFD700&bold=true`);
        document.getElementById('ui-avatar').src = avaUrl;
            
        this.toast('Cập nhật Thân Phận thành công!', 'success'); 
        this.renderSettings('main'); 
    },
    
    toggleHideAvatar() {
        this.user.hide_avatar = !this.user.hide_avatar;
        this.renderSettings('profile');
    },

    saveBankInfo() { 
        const b1 = document.getElementById('set-b-name').value.trim(); 
        const b2 = document.getElementById('set-b-owner').value.trim(); 
        const b3 = document.getElementById('set-b-num').value.trim(); 
        if(!b1 || !b2 || !b3) return this.toast('Vui lòng điền đủ 3 dòng thông tin Ngân khố!', 'error'); 
        
        localStorage.setItem('user_bank_name', b1);
        localStorage.setItem('user_bank_owner', b2);
        localStorage.setItem('user_bank_number', b3);
        localStorage.setItem('user_bank', `${b1} | ${b2} | ${b3}`); 

        this.toast('Cập nhật Ngân khố thành công!', 'success'); 
        this.switchTab('bank');
    },

    toggleHaptic() { this.hapticEnabled = !this.hapticEnabled; localStorage.setItem('haptic', this.hapticEnabled); this.toast(`Chế Độ Rung: ${this.hapticEnabled ? 'ĐÃ BẬT' : 'ĐÃ TẮT'}`, 'success'); this.renderSettings('main'); },

    renderDynamicTimers() {
        const now = Date.now();

        if(this.currentTab === 'build') {
            this.catalog.forEach(b => {
                const invB = this.inventory.find(i => i.id === b.id);
                if(invB && invB.is_upgrading === 1) {
                    const timeLeft = Math.max(0, Math.ceil((invB.upgrade_end_time - now) / 1000));
                    const btn = document.getElementById(`btn-b-${b.id}`);
                    if(btn) {
                        if(timeLeft > 0) {
                            const cost = Math.max(1, Math.ceil(timeLeft * 5));
                            btn.innerHTML = `<span class="font-black text-[9px]">ĐẨY NHANH</span><span class="text-[7.5px] mt-0.5 font-bold text-[var(--btn-text)] opacity-90">(${coinImg} ${formatNum(cost)}) ${timeLeft}s</span>`;
                        } else {
                            if(!btn.dataset.reloading) { btn.dataset.reloading = 'true'; btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i>`; this.syncAfterAction(); }
                        }
                    }
                }
            });
        }

        if (this.currentMerchantModal === 'trade') {
            const formatTime = (ms) => {
                if (ms <= 0) return 'Sẵn sàng';
                const s = Math.ceil(ms / 1000);
                const h = Math.floor(s / 3600);
                const m = Math.floor((s % 3600) / 60);
                const sec = s % 60;
                return `${h>0?h+'h ':''}${m>0?m+'m ':''}${sec}s`;
            };

            const btnAuto = document.getElementById('btn-merch-autotap');
            const btnEnergy = document.getElementById('btn-merch-energy');
            const btnRandom = document.getElementById('btn-merch-random');

            const globalPassed = now - (this.user.ad_global_last || 0);
            const globalLock = globalPassed < 900000; 

            if (btnAuto) {
                const autoLeft = this.user.ad_autotap_end > now ? this.user.ad_autotap_end - now : 0;
                if (autoLeft > 0) {
                    btnAuto.disabled = true;
                    btnAuto.innerHTML = `<i class="fas fa-clock mr-1"></i> ${formatTime(autoLeft)}`;
                } else if (globalLock) {
                    btnAuto.disabled = true;
                    btnAuto.innerHTML = `<i class="fas fa-clock mr-1"></i> ${formatTime(900000 - globalPassed)}`;
                } else {
                    btnAuto.disabled = false;
                    btnAuto.innerHTML = `<i class="fas fa-hand-pointer mr-1"></i> CHỌN`;
                }
            }
            if (btnEnergy) {
                const energyPassed = now - (this.user.ad_energy_last || 0);
                if (energyPassed < 3600000) {
                    btnEnergy.disabled = true;
                    btnEnergy.innerHTML = `<i class="fas fa-clock mr-1"></i> ${formatTime(3600000 - energyPassed)}`;
                } else if (globalLock) {
                    btnEnergy.disabled = true;
                    btnEnergy.innerHTML = `<i class="fas fa-clock mr-1"></i> ${formatTime(900000 - globalPassed)}`;
                } else {
                    btnEnergy.disabled = false;
                    btnEnergy.innerHTML = `<i class="fas fa-hand-pointer mr-1"></i> CHỌN`;
                }
            }
            if (btnRandom) {
                const randomPassed = now - (this.user.ad_random_last || 0);
                if (randomPassed < 300000) {
                    btnRandom.disabled = true;
                    btnRandom.innerHTML = `<i class="fas fa-clock mr-1"></i> ${formatTime(300000 - randomPassed)}`;
                } else if (globalLock) {
                    btnRandom.disabled = true;
                    btnRandom.innerHTML = `<i class="fas fa-clock mr-1"></i> ${formatTime(900000 - globalPassed)}`;
                } else {
                    btnRandom.disabled = false;
                    btnRandom.innerHTML = `<i class="fas fa-hand-pointer mr-1"></i> CHỌN`;
                }
            }
        }
    },
    
    async chooseMerchant(type) {
        if(this.isProcessing) return; 
        this.isProcessing = true; 
        
        this.toast('Đang tìm kiếm Thương nhân để xem quảng cáo...', 'info'); 

        const grantReward = async () => {
            this.toast('Đang nhận bổng lộc, xin chờ...', 'info');
            const d = await this.api('/api/ads/reward', { type }); 
            if(d.success) { 
                this.toast(d.msg, 'success'); 
                this.syncAfterAction(); 
                this.closeModal(); 
            } else { 
                this.toast(d.msg || "Lỗi", 'error'); 
            } 
            this.isProcessing = false; 
        };

        const fallbackToMonetag = () => {
            if (typeof show_10938895 === 'function') {
                show_10938895().then(() => {
                    grantReward();
                }).catch((err) => {
                    this.toast('Không có quảng cáo hoặc ngài đã bỏ qua!', 'error');
                    this.isProcessing = false;
                });
            } else {
                this.toast('Hệ thống quảng cáo dự phòng bị lỗi!', 'error');
                this.isProcessing = false;
            }
        };

        if (this.adsgramController) {
            this.adsgramController.show().then((result) => {
                grantReward();
            }).catch((result) => {
                if (result && (result.error || result.done === false)) {
                    console.log("Adsgram không khả dụng, chuyển sang Monetag");
                    fallbackToMonetag();
                } else {
                    this.toast('Ngài phải xem hết quảng cáo mới nhận được phần thưởng!', 'error');
                    this.isProcessing = false;
                }
            });
        } else {
            fallbackToMonetag();
        }
    },

    renderSettings(view) {
        const mb = document.getElementById('modal-body');
        if(view === 'main') {
            mb.innerHTML = `<h3 class="font-empire text-center text-c-gold border-b border-[var(--gold)]/20 pb-2 mb-3 text-base mt-1"><i class="fas fa-cog mr-1"></i> Cơ Mật Viện</h3>
            <div class="space-y-2 mt-2">
                <button type="button" onclick="App.renderSettings('profile')" class="w-full royal-card p-3 flex justify-between items-center active:scale-95 transition"><div class="flex items-center gap-2"><i class="fas fa-user-circle text-blue-400 text-sm w-5"></i><span class="text-[var(--text-main)] text-[11px] font-bold">Thông Tin Hoàng Đế</span></div><i class="fas fa-chevron-right text-[var(--text-muted)] text-[10px]"></i></button>
                <button type="button" onclick="App.renderSettings('bank')" class="w-full royal-card p-3 flex justify-between items-center active:scale-95 transition"><div class="flex items-center gap-2"><i class="fas fa-university text-green-400 text-sm w-5"></i><span class="text-[var(--text-main)] text-[11px] font-bold">Cập Nhật Ngân Khố</span></div><i class="fas fa-chevron-right text-[var(--text-muted)] text-[10px]"></i></button>
                <div class="royal-card p-3 flex justify-between items-center"><div class="flex items-center gap-2"><i class="fas fa-mobile-alt text-orange-400 text-sm w-5"></i><span class="text-[var(--text-main)] text-[11px] font-bold">Chế Độ Rung</span></div><button type="button" onclick="App.toggleHaptic()" class="btn-royal px-3 py-1.5 text-[9px] min-w-[70px] whitespace-nowrap">${this.hapticEnabled?'ĐÃ BẬT':'ĐÃ TẮT'}</button></div>
                <button type="button" onclick="App.renderSettings('theme')" class="w-full royal-card p-3 flex justify-between items-center active:scale-95 transition"><div class="flex items-center gap-2"><i class="fas fa-palette text-purple-400 text-sm w-5"></i><span class="text-[var(--text-main)] text-[11px] font-bold">Thay Đổi Giao Diện</span></div><i class="fas fa-chevron-right text-[var(--text-muted)] text-[10px]"></i></button>
                <button type="button" onclick="App.renderSettings('guide')" class="w-full royal-card p-3 flex justify-between items-center active:scale-95 transition"><div class="flex items-center gap-2"><i class="fas fa-book text-yellow-500 text-sm w-5"></i><span class="text-[var(--text-main)] text-[11px] font-bold">Thông tin & Hướng dẫn</span></div><i class="fas fa-chevron-right text-[var(--text-muted)] text-[10px]"></i></button>
            </div>`;
        } else if(view === 'profile') {
            mb.innerHTML = `<div class="flex items-center mb-3 border-b border-[var(--gold)]/20 pb-2 mt-1"><button type="button" onclick="App.renderSettings('main')" class="text-c-gold text-lg px-2 active:scale-90"><i class="fas fa-chevron-left"></i></button><h3 class="font-empire text-center text-c-gold text-base flex-1 pr-6">Thân Phận Hoàng Đế</h3></div>
            <div class="space-y-2 px-1">
                <div><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1">Danh xưng (Xóa trống để quay về tên Telegram)</p><input type="text" id="set-alias" class="set-input" placeholder="Tên hiển thị..." value="${localStorage.getItem('user_alias')||this.user.first_name}"></div>
                <div><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1">Số Điện Thoại</p><input type="number" id="set-phone" class="set-input" placeholder="VD: 0987654321" value="${localStorage.getItem('user_phone')||''}"></div>
                <div><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1">Thư Tín (Email)</p><input type="email" id="set-mail" class="set-input" placeholder="VD: hoangde@gmail.com" value="${localStorage.getItem('user_mail')||''}"></div>
                <div><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1">Telegram Username (bắt buộc @ ở đầu)</p><input type="text" id="set-tele" class="set-input" placeholder="VD: @username" value="${this.user.contact_tg||localStorage.getItem('user_tele')||''}"></div>
                <div><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1">Bài giới thiệu / Bảng giá</p><textarea id="set-bio" class="set-input !h-[82px]" placeholder="Giới thiệu ngắn của ngài...">${this.user.bio||''}</textarea></div>
                <div class="flex justify-between items-center bg-black/40 p-2.5 rounded border border-[var(--gold)]/20 mt-3 shadow-inner">
                    <span class="text-[var(--text-main)] opacity-90 text-[10px] font-bold">Ẩn Ảnh đại diện Telegram</span>
                    <button type="button" onclick="App.toggleHideAvatar()" class="btn-royal px-3 py-1.5 text-[9px] min-w-[70px] whitespace-nowrap">${this.user.hide_avatar ? 'ĐÃ BẬT' : 'ĐÃ TẮT'}</button>
                </div>
                <div class="flex gap-2 mt-3">
                    <button type="button" onclick="App.renderSettings('main')" class="flex-[0.8] bg-gray-800 text-gray-300 border border-gray-600 py-2.5 rounded-lg shadow-md font-bold text-[11px] active:scale-95 transition">HỦY BỎ</button>
                    <button type="button" onclick="App.saveProfile()" class="flex-[1.2] btn-royal py-2.5 text-[11px] shadow-md"><i class="fas fa-save mr-1.5"></i> LƯU THÂN PHẬN</button>
                </div>
            </div>`;
        } else if(view === 'bank') {
            const b1 = localStorage.getItem('user_bank_name') || '';
            const b2 = localStorage.getItem('user_bank_owner') || '';
            const b3 = localStorage.getItem('user_bank_number') || '';

            mb.innerHTML = `<div class="flex items-center mb-3 border-b border-[var(--gold)]/20 pb-2 mt-1"><button type="button" onclick="App.switchTab('bank')" class="text-c-gold text-lg px-2 active:scale-90"><i class="fas fa-chevron-left"></i></button><h3 class="font-empire text-center text-c-gold text-base flex-1 pr-6">Cập Nhật Ngân Khố</h3></div>
            <div class="px-1 text-left mt-3">
                <div class="text-center mb-3"><i class="fas fa-university text-3xl text-green-500 mb-2 opacity-80"></i></div>
                <div class="mb-2"><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1 text-red-400">Ngân hàng (Không hỗ trợ rút về ví điện tử)</p><input type="text" id="set-b-name" class="set-input font-bold text-[11px]" placeholder="VD: MBBANK" value="${b1}"></div>
                <div class="mb-2"><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1">Chủ tài khoản</p><input type="text" id="set-b-owner" class="set-input font-bold text-[11px] uppercase" placeholder="VD: NGUYEN VAN A" value="${b2}"></div>
                <div class="mb-4"><p class="text-[var(--text-muted)] text-[9px] mb-1 ml-1">Số tài khoản</p><input type="number" id="set-b-num" class="set-input font-bold text-[11px]" placeholder="Chỉ nhập số tài khoản..." value="${b3}"></div>
                <button type="button" onclick="App.saveBankInfo()" class="btn-royal w-full py-2.5 text-[11px] shadow-md bg-gradient-to-r from-green-600 to-green-500 border-green-800 !text-white"><i class="fas fa-check-circle mr-1.5"></i> XÁC NHẬN THÔNG TIN</button>
            </div>`;
        } else if(view === 'theme') {
            const cT = localStorage.getItem('user_theme') || 'default';
            mb.innerHTML = `<div class="flex items-center mb-3 border-b border-[var(--gold)]/20 pb-2 mt-1"><button type="button" onclick="App.renderSettings('main')" class="text-c-gold text-lg px-2 active:scale-90"><i class="fas fa-chevron-left"></i></button><h3 class="font-empire text-center text-c-gold text-base flex-1 pr-6">Y Phục Hoàng Gia</h3></div>
            <div class="space-y-3 px-1 mt-3 max-h-[60vh] overflow-y-auto pb-4">
                <div class="royal-card p-3 flex justify-between items-center border-l-4 border-yellow-500"><div><h4 class="text-[var(--text-main)] text-[12px] font-bold">Hoàng Kim</h4><p class="text-[var(--text-muted)] text-[9px]">Vàng đen quyền lực.</p></div><button type="button" onclick="App.changeTheme('default')" class="btn-royal px-4 py-1.5 text-[9px]" ${cT==='default'?'disabled':''}>${cT==='default'?'ĐANG DÙNG':'CHỌN'}</button></div>
                <div class="royal-card p-3 flex justify-between items-center border-l-4 border-gray-300"><div><h4 class="text-[var(--text-main)] text-[12px] font-bold">Bạch Kim (Mới)</h4><p class="text-[var(--text-muted)] text-[9px]">Trắng vàng thanh tao.</p></div><button type="button" onclick="App.changeTheme('light')" class="btn-royal px-4 py-1.5 text-[9px]" ${cT==='light'?'disabled':''}>${cT==='light'?'ĐANG DÙNG':'CHỌN'}</button></div>
                <div class="royal-card p-3 flex justify-between items-center border-l-4 border-gray-800"><div><h4 class="text-[var(--text-main)] text-[12px] font-bold">Hắc Ám (Mới)</h4><p class="text-[var(--text-muted)] text-[9px]">Đen tuyền bí ẩn.</p></div><button type="button" onclick="App.changeTheme('black')" class="btn-royal px-4 py-1.5 text-[9px]" ${cT==='black'?'disabled':''}>${cT==='black'?'ĐANG DÙNG':'CHỌN'}</button></div>
                <div class="royal-card p-3 flex justify-between items-center border-l-4 border-red-600"><div><h4 class="text-[var(--text-main)] text-[12px] font-bold">Huyết Nguyệt</h4><p class="text-[var(--text-muted)] text-[9px]">Chiến tranh & rực lửa.</p></div><button type="button" onclick="App.changeTheme('blood')" class="btn-royal px-4 py-1.5 text-[9px]" ${cT==='blood'?'disabled':''}>${cT==='blood'?'ĐANG DÙNG':'CHỌN'}</button></div>
                <div class="royal-card p-3 flex justify-between items-center border-l-4 border-purple-500"><div><h4 class="text-[var(--text-main)] text-[12px] font-bold">Ảo Ảnh</h4><p class="text-[var(--text-muted)] text-[9px]">Tĩnh lặng & huyễn hoặc.</p></div><button type="button" onclick="App.changeTheme('shadow')" class="btn-royal px-4 py-1.5 text-[9px]" ${cT==='shadow'?'disabled':''}>${cT==='shadow'?'ĐANG DÙNG':'CHỌN'}</button></div>
                <div class="royal-card p-3 flex justify-between items-center border-l-4 border-blue-500"><div><h4 class="text-[var(--text-main)] text-[12px] font-bold">Thiên Thanh</h4><p class="text-[var(--text-muted)] text-[9px]">Trời xanh & Đại dương.</p></div><button type="button" onclick="App.changeTheme('ocean')" class="btn-royal px-4 py-1.5 text-[9px]" ${cT==='ocean'?'disabled':''}>${cT==='ocean'?'ĐANG DÙNG':'CHỌN'}</button></div>
                <div class="royal-card p-3 flex justify-between items-center border-l-4 border-green-500"><div><h4 class="text-[var(--text-main)] text-[12px] font-bold">Lục Bảo</h4><p class="text-[var(--text-muted)] text-[9px]">Ngọc ngà & Phú quý.</p></div><button type="button" onclick="App.changeTheme('emerald')" class="btn-royal px-4 py-1.5 text-[9px]" ${cT==='emerald'?'disabled':''}>${cT==='emerald'?'ĐANG DÙNG':'CHỌN'}</button></div>
            </div>`;
        } else if(view === 'guide') {
            mb.innerHTML = `<div class="flex items-center mb-3 border-b border-[var(--gold)]/20 pb-2 mt-1"><button type="button" onclick="App.renderSettings('main')" class="text-c-gold text-lg px-2 active:scale-90"><i class="fas fa-chevron-left"></i></button><h3 class="font-empire text-center text-c-gold text-base flex-1 pr-6">Cẩm Nang Hoàng Đế</h3></div>
            <div class="px-2 mt-3 max-h-[60vh] overflow-y-auto pb-4 text-left space-y-4">
                
                <div class="bg-black/40 p-3 rounded-lg border border-[var(--gold)]/20 shadow-inner">
                    <h4 class="text-c-gold font-bold text-[13px] mb-2 font-empire"><i class="fas fa-gem mr-1"></i> 1. HOÀNG CUNG (Khai thác)</h4>
                    <ul class="text-[var(--text-main)] opacity-90 text-[11.5px] leading-relaxed list-disc pl-4 space-y-1.5">
                        <li><b>Chạm:</b> Bấm vào vòng tròn giữa màn hình để nhận tài nguyên.</li>
                        <li><b>Nâng cấp Búa:</b> Giúp mỗi lần chạm nhận được nhiều nguyên liệu hơn.</li>
                        <li><b>Bể Thể Lực & Hồi Phục:</b> Tăng sức chứa Thể lực và tốc độ tự hồi phục mỗi giây để khai thác được lâu hơn.</li>
                        <li><b>Thương Nhân Bí Ẩn:</b> Xem quảng cáo nhận tự động tap, Linh dược (hồi thể lực) hoặc làm Chiếu chỉ (Nhiệm vụ) để lấy bổng lộc miễn phí.</li>
                    </ul>
                </div>

                <div class="bg-black/40 p-3 rounded-lg border border-[var(--gold)]/20 shadow-inner">
                    <h4 class="text-c-gold font-bold text-[13px] mb-2 font-empire"><i class="fas fa-chess-rook mr-1"></i> 2. CÔNG BỘ (Kiến Thiết)</h4>
                    <ul class="text-[var(--text-main)] opacity-90 text-[11.5px] leading-relaxed list-disc pl-4 space-y-1.5">
                        <li>Xây dựng và nâng cấp các công trình để nhận <b>Vàng và Nguyên liệu sinh ra tự động</b> mỗi giờ.</li>
                        <li><b>Lưu ý:</b> Phải nâng cấp <b>[Hoàng Cung]</b> lên cấp độ tương ứng thì mới có thể nâng cấp các công trình khác.</li>
                        <li><b>Đẩy nhanh:</b> Nếu không muốn chờ đợi thời gian xây dựng, ngài có thể dùng Vàng để hoàn thành ngay lập tức.</li>
                    </ul>
                </div>

                <div class="bg-black/40 p-3 rounded-lg border border-[var(--gold)]/20 shadow-inner">
                    <h4 class="text-c-gold font-bold text-[13px] mb-2 font-empire"><i class="fas fa-dragon mr-1"></i> 3. THẢO PHẠT (Chiến Trận)</h4>
                    <ul class="text-[var(--text-main)] opacity-90 text-[11.5px] leading-relaxed list-disc pl-4 space-y-1.5">
                        <li><b>Chiêu Mộ:</b> Dùng Lương Thực và Vàng để mua Binh sĩ. Cần nâng cấp <i>Binh Bộ</i> để tăng tối đa sức chứa lính.</li>
                        <li><b>Xuất Quân:</b> Mang Binh sĩ và Lương thực đi đánh ải. Nếu Thắng sẽ thu về rất nhiều Vàng.</li>
                        <li><b>Tỷ lệ thắng:</b> Phụ thuộc vào cấp độ của công trình <i>Binh Khí Phường</i>. Thương vong lính có thể giảm nhờ <i>Khâm Thiên Giám</i>.</li>
                    </ul>
                </div>

                <div class="bg-black/40 p-3 rounded-lg border border-[var(--gold)]/20 shadow-inner">
                    <h4 class="text-c-gold font-bold text-[13px] mb-2 font-empire"><i class="fas fa-user-friends mr-1"></i> 4. CHƯ HẦU (Mời Bạn)</h4>
                    <ul class="text-[var(--text-main)] opacity-90 text-[11.5px] leading-relaxed list-disc pl-4 space-y-1.5">
                        <li>Gửi thiếp mời (Link) cho Hảo hữu. Khi họ tham gia, ngài nhận ngay phần thưởng Vàng và x1 Giờ sản lượng nguyên liệu.</li>
                        <li><b>Đặc quyền vĩnh viễn:</b> Ngài được hệ thống trả hoa hồng 0.3% cho MỌI tài nguyên mà Chư hầu của ngài khai thác được. Mời càng nhiều, bổng lộc thụ động càng lớn!</li>
                    </ul>
                </div>

                <div class="bg-black/40 p-3 rounded-lg border border-[var(--gold)]/20 shadow-inner">
                    <h4 class="text-c-gold font-bold text-[13px] mb-2 font-empire"><i class="fas fa-vault mr-1"></i> 5. NGÂN KHỐ (Rút Tiền)</h4>
                    <ul class="text-[var(--text-main)] opacity-90 text-[11.5px] leading-relaxed list-disc pl-4 space-y-1.5">
                        <li>Nơi quy đổi Vàng thành VNĐ (Tỷ giá tham khảo: 1.000.000 Vàng = 10.000 VNĐ).</li>
                        <li><b>Lưu ý quan trọng:</b> Ngài cần vào <b>Cơ Mật Viện (Cài đặt) -> Cập nhật Ngân Khố</b> để điền đúng số tài khoản ngân hàng trước khi gửi lệnh rút. Mức rút tối thiểu là 1 triệu Vàng.</li>
                    </ul>
                </div>

                <div class="bg-black/40 p-3 rounded-lg border border-[var(--gold)]/20 shadow-inner">
                    <h4 class="text-c-gold font-bold text-[13px] mb-2 font-empire"><i class="fas fa-gift mr-1"></i> 6. CỐNG PHẨM & GIẢI TRÍ</h4>
                    <ul class="text-[var(--text-main)] opacity-90 text-[11.5px] leading-relaxed list-disc pl-4 space-y-1.5">
                        <li><b>Bổng Lộc:</b> Điểm danh hàng ngày để nhận Vàng.</li>
                        <li><b>Cống Phẩm:</b> Nhập Giftcode do Quan Phủ ban bố để nhận thưởng.</li>
                        <li><b>Trò Chơi:</b> Lớn nhỏ, Lật bài, Đua ngựa giúp nhân tài sản nhanh chóng. Vòng quay vận mệnh sẽ thưởng LỚN HƠN dựa theo cấp Hoàng Cung của ngài.</li>
                        <li><b>Truyền Tin:</b> Nhắn tin trực tiếp với Admin nếu cần hỗ trợ.</li>
                    </ul>
                </div>

                <div class="border-t border-[var(--gold)]/20 pt-4 text-center mt-6">
                    <p class="text-[var(--text-muted)] text-[10px] font-bold uppercase tracking-widest">Vương Triều Truyền Kỳ<br>© copyright NVT</p>
                </div>
            </div>`;
        }
    },

    showPlayerOptions(id, name, isHidden) {
        if(id === this.user.telegram_id) return this.openModal('empire'); 
        this.openModal('player_options');
        document.getElementById('modal-body').innerHTML = `
            <div class="text-center p-3">
                <i class="fas fa-search text-4xl text-c-gold mb-3 opacity-80"></i>
                <h3 class="font-empire text-[var(--text-main)] text-[16px] mb-1">${name}</h3>
                <p class="text-[9px] text-[var(--text-muted)] mb-5 font-mono">ID: ${isHidden ? '********' : id}</p>
                <button type="button" onclick="App.viewOtherProfile('${id}')" class="btn-royal w-full py-3.5 text-[12px]"><i class="fas fa-eye mr-2"></i> DO THÁM HỒ SƠ ĐẾ CHẾ</button>
            </div>
        `;
    },

    async viewOtherProfile(id) {
        this.closeModal();
        this.toast('Đang điều mật thám thu thập thông tin...', 'info');
        const d = await this.api('/api/player_profile', { target_id: id });
        
        if(d.success) {
            this.openModal('other_empire');
            const target = d.user;
            this.lastScoutedUser = target;
            
            let avaName = target.hide_avatar ? "Ẩn+Danh" : encodeURIComponent(target.first_name);
            let displayName = target.hide_avatar ? "Hoàng Đế Ẩn Danh" : target.first_name;
            const avaUrl = `https://ui-avatars.com/api/?name=${avaName}&background=1a1100&color=FFD700&bold=true`;

            const content = `
                <h3 class="font-empire text-center text-red-500 border-b border-red-900/50 pb-2 mb-3 text-sm"><i class="fas fa-mask mr-1"></i> Thông Tin Dò Thám</h3>
                <div class="flex items-center gap-3 mb-3 royal-box p-2 shadow-inner border-red-900/50">
                    <img src="${avaUrl}" class="w-12 h-12 rounded-full object-cover border-2 border-red-800 shadow-[0_0_10px_rgba(255,0,0,0.4)]">
                    <div class="flex-1">
                        <h2 class="text-red-400 font-empire font-black text-[15px] drop-shadow-md leading-none mb-1">${displayName}</h2>
                        <p class="text-[var(--text-muted)] text-[9px] uppercase mb-1">ID: <span class="text-[var(--text-main)] opacity-80 font-mono">${target.hide_avatar ? '********' : target.telegram_id}</span></p>
                    </div>
                    <div class="text-right">
                        <p class="text-yellow-500 text-[12px] font-bold flex items-center justify-end gap-1">${coinImg} ${formatFullNum(target.gold || 0)}</p>
                    </div>
                </div>
                
                <div class="flex justify-between border-b border-red-900/50 pb-0 mb-3">
                    <button type="button" id="btn-oemp-stats" onclick="App.renderOtherEmpireTab('stats')" class="flex-1 text-[10px] font-bold pb-1.5 text-red-400 border-b-2 border-red-500 transition-all">Chỉ Số</button>
                    <button type="button" id="btn-oemp-resources" onclick="App.renderOtherEmpireTab('resources')" class="flex-1 text-[10px] font-bold pb-1.5 text-[var(--text-muted)] border-b-2 border-transparent transition-all">Kho Tàng</button>
                    <button type="button" id="btn-oemp-yield" onclick="App.renderOtherEmpireTab('yield')" class="flex-1 text-[10px] font-bold pb-1.5 text-[var(--text-muted)] border-b-2 border-transparent transition-all">Sản Lượng</button>
                    <button type="button" id="btn-oemp-buildings" onclick="App.renderOtherEmpireTab('buildings')" class="flex-1 text-[10px] font-bold pb-1.5 text-[var(--text-muted)] border-b-2 border-transparent transition-all">Kiến Trúc</button>
                </div>
                <div id="other-empire-content" class="h-[40vh] overflow-y-auto pr-1"></div>
            `;
            document.getElementById('modal-body').innerHTML = content;
            setTimeout(() => this.renderOtherEmpireTab('stats'), 50);
        } else {
            this.toast(d.msg || 'Không thể lấy thông tin người chơi này!', 'error');
        }
    },

    renderOtherEmpireTab(tabName) {
        const container = document.getElementById('other-empire-content');
        if(!container) return;
        const target = this.lastScoutedUser;
        if(!target) return;
        
        ['stats', 'resources', 'yield', 'buildings'].forEach(t => {
            const btn = document.getElementById(`btn-oemp-${t}`);
            if(btn) {
                if(t === tabName) {
                    btn.className = "flex-1 text-[10px] font-bold pb-1.5 text-red-400 border-b-2 border-red-500 transition-all";
                } else {
                    btn.className = "flex-1 text-[10px] font-bold pb-1.5 text-[var(--text-muted)] border-b-2 border-transparent transition-all";
                }
            }
        });

        let html = '';
        if (tabName === 'stats') {
            html = `
                <div class="fade-enter flex flex-col gap-1 mb-3 pt-2">
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><i class="fas fa-hammer text-yellow-500 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Sức mạnh Búa</span></div><span class="text-[11px] text-c-gold font-bold">Lv.${target.tap_level || 1}</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><i class="fas fa-bolt text-blue-500 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Hồi Phục / Giây</span></div><span class="text-[11px] text-c-gold font-bold">+${target.total_regen || 1}/s</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><i class="fas fa-shield-alt text-red-400 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Tỷ lệ Chiến Thắng</span></div><span class="text-[11px] text-red-400 font-bold">${((target.win_rate||0)*100).toFixed(0)}%</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><i class="fas fa-clinic-medical text-pink-400 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Cứu Binh Tử Trận</span></div><span class="text-[11px] text-pink-400 font-bold">${((target.save_troops||0)*100).toFixed(0)}%</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><i class="fas fa-percent text-blue-400 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Giảm Phí Chiêu Mộ</span></div><span class="text-[11px] text-blue-400 font-bold">-${((target.discount_train||0)*100).toFixed(0)}%</span></div>
                </div>
            `;
        } else if (tabName === 'resources') {
            let resHtml = '';
            const resNames = { wood: ['fas fa-tree text-[#D4AF37]', 'Gỗ'], stone: ['fas fa-cube text-gray-300', 'Đá'], iron: ['fas fa-cubes text-gray-400', 'Sắt'], dark_iron: ['fas fa-meteor text-purple-400', 'Huyền Thiết'], jade: ['fas fa-gem text-teal-400', 'Linh Ngọc'], glaze: ['fas fa-ring text-blue-300', 'Lưu Ly'], purple_gold: ['fas fa-crown text-purple-600', 'Tử Kim'], food: ['fas fa-drumstick-bite text-orange-500', 'Lương Thực'] };
            
            this.catalog.forEach(b => {
                if (!['troops', 'winrate', 'save_troops', 'energy_regen', 'discount_train', 'gold'].includes(b.effect_type) && !resNames[b.effect_type]) {
                    resNames[b.effect_type] = ['fas fa-box text-blue-400', b.effect_name || b.effect_type];
                }
            });

            Object.keys(resNames).forEach(k => {
                if(target[k] !== undefined && target[k] > 0) {
                    resHtml += `<div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><i class="${resNames[k][0]} w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80 font-bold">${resNames[k][1]}</span></div><span class="text-[11px] text-c-gold font-bold">${formatFullNum(target[k])}</span></div>`;
                }
            });

            html = `<div class="fade-enter flex flex-col gap-1 mb-3 pt-2">${resHtml}</div>`;
        } else if (tabName === 'yield') {
            let yieldHtml = `<div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><div class="w-4 text-center flex justify-center">${coinImg}</div><span class="text-[10px] text-[var(--text-main)] opacity-80 font-bold">Vàng</span></div><span class="text-[11px] text-c-gold font-bold">+${formatFullNum(target.rate||0)}/h</span></div>`;
            const resNames = { food: ['fas fa-drumstick-bite text-orange-500', 'Lương Thực'], wood: ['fas fa-tree text-[#D4AF37]', 'Gỗ'], stone: ['fas fa-cube text-gray-300', 'Đá'], iron: ['fas fa-cubes text-gray-400', 'Sắt'], dark_iron: ['fas fa-meteor text-purple-400', 'Huyền Thiết'], jade: ['fas fa-gem text-teal-400', 'Linh Ngọc'], glaze: ['fas fa-ring text-blue-300', 'Lưu Ly'], purple_gold: ['fas fa-crown text-purple-600', 'Tử Kim'] };
            
            this.catalog.forEach(b => {
                if (!['troops', 'winrate', 'save_troops', 'energy_regen', 'discount_train', 'gold'].includes(b.effect_type) && !resNames[b.effect_type]) {
                    resNames[b.effect_type] = ['fas fa-box text-blue-400', b.effect_name || b.effect_type];
                }
            });

            Object.keys(resNames).forEach(k => {
                const rKey = `${k}_rate`;
                if(target[rKey] !== undefined && target[rKey] > 0) {
                    yieldHtml += `<div class="royal-box p-2 flex justify-between items-center bg-black/40 border-red-900/50"><div class="flex items-center gap-2"><i class="${resNames[k][0]} w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80 font-bold">${resNames[k][1]}</span></div><span class="text-[11px] text-[#D4AF37] font-bold">+${formatFullNum(target[rKey])/h}</span></div>`;
                }
            });

            html = `<div class="fade-enter flex flex-col gap-1 mb-3 pt-2">${yieldHtml}</div>`;
        } else if (tabName === 'buildings') {
            const ownedBuildings = target.inventory.filter(b => b.level > 0);
            html = ownedBuildings.length === 0 ? '<p class="text-[var(--text-muted)] text-[9px] italic text-center py-4">Chưa có kiến trúc.</p>' : ownedBuildings.map(b => `<div class="flex justify-between items-center border-b border-[var(--gold)]/15 py-2.5 px-2"><div class="flex flex-col"><span class="text-[var(--text-main)] text-[11px] font-bold mb-1"><i class="fas fa-hammer text-[var(--text-muted)] mr-1"></i>${b.name}</span><span class="text-[var(--text-muted)] text-[9px]">${b.description}</span></div><span class="text-c-gold text-[10px] font-bold bg-black/50 px-2 py-1 rounded border border-[var(--gold)]/20 shrink-0">Lv.${b.level}</span></div>`).join('');
            html = `<div class="fade-enter royal-box p-1 mt-2 shadow-inner border-red-900/50">${html}</div>`;
        }
        container.innerHTML = html;
    },

    renderEmpireTab(tabName) {
        const container = document.getElementById('empire-content');
        if(!container) return;
        
        ['stats', 'resources', 'yield', 'buildings'].forEach(t => {
            const btn = document.getElementById(`btn-emp-${t}`);
            if(btn) {
                if(t === tabName) {
                    btn.className = "flex-1 text-[10px] font-bold pb-1 text-c-gold border-b-2 border-[var(--gold)] transition-all";
                } else {
                    btn.className = "flex-1 text-[10px] font-bold pb-1 text-[var(--text-muted)] border-b-2 border-transparent transition-all";
                }
            }
        });

        let html = '';
        if (tabName === 'stats') {
            html = `
                <div class="fade-enter flex flex-col gap-1 mb-3 pt-2">
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="fas fa-hammer text-yellow-500 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Sức mạnh Búa</span></div><span class="text-[11px] text-c-gold font-bold">Lv.${this.user.tap_level}</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="fas fa-battery-full text-green-500 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Bể Thể Lực</span></div><span class="text-[11px] text-c-gold font-bold">${formatFullNum(this.user.max_energy)}</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="fas fa-bolt text-blue-500 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Hồi Phục / Giây</span></div><span class="text-[11px] text-c-gold font-bold">+${this.user.total_regen || 1}/s</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="fas fa-shield-alt text-red-400 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Tỷ lệ Chiến Thắng</span></div><span class="text-[11px] text-red-400 font-bold">${(this.user.win_rate*100).toFixed(0)}%</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="fas fa-clinic-medical text-pink-400 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Cứu Binh Tử Trận</span></div><span class="text-[11px] text-pink-400 font-bold">${(this.user.save_troops*100).toFixed(0)}%</span></div>
                    <div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="fas fa-percent text-blue-400 w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80">Giảm Phí Chiêu Mộ</span></div><span class="text-[11px] text-blue-400 font-bold">-${(this.user.discount_train*100).toFixed(0)}%</span></div>
                </div>
            `;
        } else if (tabName === 'resources') {
            let resHtml = '';
            const resNames = { wood: ['fas fa-tree text-[#D4AF37]', 'Gỗ'], stone: ['fas fa-cube text-gray-300', 'Đá'], iron: ['fas fa-cubes text-gray-400', 'Sắt'], dark_iron: ['fas fa-meteor text-purple-400', 'Huyền Thiết'], jade: ['fas fa-gem text-teal-400', 'Linh Ngọc'], glaze: ['fas fa-ring text-blue-300', 'Lưu Ly'], purple_gold: ['fas fa-crown text-purple-600', 'Tử Kim'], food: ['fas fa-drumstick-bite text-orange-500', 'Lương Thực'] };
            
            this.catalog.forEach(b => {
                if (!['troops', 'winrate', 'save_troops', 'energy_regen', 'discount_train', 'gold'].includes(b.effect_type) && !resNames[b.effect_type]) {
                    resNames[b.effect_type] = ['fas fa-box text-blue-400', b.effect_name || b.effect_type];
                }
            });

            Object.keys(resNames).forEach(k => {
                if(this.user[k] !== undefined && this.user[k] > 0) {
                    resHtml += `<div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="${resNames[k][0]} w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80 font-bold">${resNames[k][1]}</span></div><span class="text-[11px] text-c-gold font-bold">${formatFullNum(this.user[k])}</span></div>`;
                }
            });

            html = `<div class="fade-enter flex flex-col gap-1 mb-3 pt-2">${resHtml}</div>`;
        } else if (tabName === 'yield') {
            let yieldHtml = `<div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><div class="w-4 text-center flex justify-center">${coinImg}</div><span class="text-[10px] text-[var(--text-main)] opacity-80 font-bold">Vàng</span></div><span class="text-[11px] text-c-gold font-bold">+${formatFullNum(this.user.rate||0)}/h</span></div>`;
            const resNames = { food: ['fas fa-drumstick-bite text-orange-500', 'Lương Thực'], wood: ['fas fa-tree text-[#D4AF37]', 'Gỗ'], stone: ['fas fa-cube text-gray-300', 'Đá'], iron: ['fas fa-cubes text-gray-400', 'Sắt'], dark_iron: ['fas fa-meteor text-purple-400', 'Huyền Thiết'], jade: ['fas fa-gem text-teal-400', 'Linh Ngọc'], glaze: ['fas fa-ring text-blue-300', 'Lưu Ly'], purple_gold: ['fas fa-crown text-purple-600', 'Tử Kim'] };
            
            this.catalog.forEach(b => {
                if (!['troops', 'winrate', 'save_troops', 'energy_regen', 'discount_train', 'gold'].includes(b.effect_type) && !resNames[b.effect_type]) {
                    resNames[b.effect_type] = ['fas fa-box text-blue-400', b.effect_name || b.effect_type];
                }
            });

            Object.keys(resNames).forEach(k => {
                const rKey = `${k}_rate`;
                if(this.user[rKey] !== undefined && this.user[rKey] > 0) {
                    yieldHtml += `<div class="royal-box p-2 flex justify-between items-center bg-black/40"><div class="flex items-center gap-2"><i class="${resNames[k][0]} w-4 text-center"></i><span class="text-[10px] text-[var(--text-main)] opacity-80 font-bold">${resNames[k][1]}</span></div><span class="text-[11px] text-[#D4AF37] font-bold">+${formatFullNum(this.user[rKey])}/h</span></div>`;
                }
            });

            html = `<div class="fade-enter flex flex-col gap-1 mb-3 pt-2">${yieldHtml}</div>`;
        } else if (tabName === 'buildings') {
            const ownedBuildings = this.inventory.filter(b => b.level > 0);
            html = ownedBuildings.length === 0 ? '<p class="text-[var(--text-muted)] text-[9px] italic text-center py-4">Chưa có kiến trúc.</p>' : ownedBuildings.map(b => `<div class="flex justify-between items-center border-b border-[var(--gold)]/15 py-2.5 px-2"><div class="flex flex-col"><span class="text-[var(--text-main)] text-[11px] font-bold mb-1"><i class="fas fa-hammer text-[var(--text-muted)] mr-1"></i>${b.name}</span><span class="text-[var(--text-muted)] text-[9px]">${b.description}</span></div><span class="text-c-gold text-[10px] font-bold bg-black/50 px-2 py-1 rounded border border-[var(--gold)]/20 shrink-0">Lv.${b.level}</span></div>`).join('');
            html = `<div class="fade-enter royal-box p-1 mt-2 shadow-inner">${html}</div>`;
        }
        container.innerHTML = html;
    },

    async openModal(tab, data) {
        const m = document.getElementById('modal-overlay'); const mb = document.getElementById('modal-body'); 
        const closeBtn = document.getElementById('modal-close-btn');
        m.classList.remove('hidden'); m.classList.add('modal-active');
        if(closeBtn) closeBtn.style.display = 'block'; 

        if(tab === 'merchant') {
            const mTab = data || 'trade'; 
            this.currentMerchantModal = mTab;
            
            const renderMerchantBase = (content) => {
                mb.innerHTML = `
                <div class="text-center fade-enter min-h-[300px]">
                    <h3 class="font-empire text-[16px] text-c-gold pb-2 mt-2">
                        <i class="fas fa-user-secret mr-2 text-[var(--text-main)]"></i> THƯƠNG NHÂN BÍ ẨN
                    </h3>
                    <div class="flex border-b border-[var(--gold)]/30 mb-4">
                        <button type="button" onclick="App.openModal('merchant', 'trade')" class="flex-1 pb-1.5 text-[11px] font-bold ${mTab==='trade'?'text-c-gold border-b-2 border-[var(--gold)]':'text-[var(--text-muted)]'} transition">Trao Đổi</button>
                        <button type="button" onclick="App.openModal('merchant', 'help')" class="flex-1 pb-1.5 text-[11px] font-bold ${mTab==='help'?'text-c-gold border-b-2 border-[var(--gold)]':'text-[var(--text-muted)]'} transition">Giúp Đỡ</button>
                    </div>
                    <div id="merch-content">${content}</div>
                </div>`;
            };

            if (mTab === 'trade') {
                renderMerchantBase(`
                <p class="text-[var(--text-muted)] text-[10px] mb-4">Ngài chỉ có thể chọn MỘT món đồ trong lần gặp này. Hãy cân nhắc kỹ!</p>
                <div class="space-y-2">
                    <div class="royal-card p-2.5 flex justify-between items-center"><div class="flex items-center gap-2"><div class="w-8 h-8 rounded bg-blue-900/30 border border-blue-500/50 flex items-center justify-center"><i class="fas fa-robot text-blue-400 text-[14px]"></i></div><div class="text-left"><h4 class="text-[var(--text-main)] text-[11px] font-bold">Tự Động Tap</h4><p class="text-[9px] text-c-gold font-black">Tự khai thác 3 giờ</p></div></div><button type="button" id="btn-merch-autotap" onclick="App.chooseMerchant('autotap')" class="btn-royal px-3 h-[30px] w-[80px] text-[9px]"><i class="fas fa-spinner fa-spin"></i></button></div>
                    <div class="royal-card p-2.5 flex justify-between items-center"><div class="flex items-center gap-2"><div class="w-8 h-8 rounded bg-green-900/30 border border-green-500/50 flex items-center justify-center"><i class="fas fa-bolt text-green-400 text-[14px]"></i></div><div class="text-left"><h4 class="text-[var(--text-main)] text-[11px] font-bold">Linh Dược</h4><p class="text-[9px] text-c-gold font-black">Hồi 50% Thể Lực</p></div></div><button type="button" id="btn-merch-energy" onclick="App.chooseMerchant('energy')" class="btn-royal px-3 h-[30px] w-[80px] text-[9px]"><i class="fas fa-spinner fa-spin"></i></button></div>
                    <div class="royal-card p-2.5 flex justify-between items-center"><div class="flex items-center gap-2"><div class="w-8 h-8 rounded bg-purple-900/30 border border-purple-500/50 flex items-center justify-center"><i class="fas fa-box-open text-purple-400 text-[14px]"></i></div><div class="text-left"><h4 class="text-[var(--text-main)] text-[11px] font-bold">Hộp Báu Vật</h4><p class="text-[9px] text-c-gold font-black">Nguyên liệu ngẫu nhiên</p></div></div><button type="button" id="btn-merch-random" onclick="App.chooseMerchant('random_mat')" class="btn-royal px-3 h-[30px] w-[80px] text-[9px]"><i class="fas fa-spinner fa-spin"></i></button></div>
                </div>`);
                this.renderDynamicTimers();
            } else if (mTab === 'help') {
                renderMerchantBase(`<div class="py-10 text-center"><i class="fas fa-spinner fa-spin text-3xl text-c-gold"></i></div>`);
                const d = await this.api('/api/tasks', {});
                let taskHtml = '';
                if(d.success && d.tasks.length > 0) {
                    taskHtml = d.tasks.map(t => {
                        const isDone = d.completed.includes(t.id);
                        const rData = JSON.parse(t.reward_data);
                        const rTypeStr = t.reward_type === 'fixed' ? formatNum(rData.amount) : `${formatNum(rData.min)}-${formatNum(rData.max)}`;
                        
                        const resMap = { wood:'Gỗ', stone:'Đá', iron:'Sắt', food:'Lương', gold:'Vàng', dark_iron:'Huyền Thiết', jade:'Linh Ngọc', glaze:'Lưu Ly', purple_gold:'Tử Kim' };
                        const resStr = (rData.resources || []).map(r => resMap[r] || r).join(', ');

                        return `
                        <div class="royal-card p-3 mb-2 flex justify-between items-center text-left">
                            <div class="flex-1 pr-2">
                                <h4 class="text-[12px] font-bold text-[var(--text-main)] mb-1">${t.title}</h4>
                                <div class="text-[9px] text-yellow-500 bg-black/30 px-1.5 py-0.5 rounded inline-block border border-[var(--gold)]/30">
                                    <i class="fas fa-gift mr-1"></i> ${rTypeStr} (${resStr})
                                </div>
                            </div>
                            ${isDone 
                                ? `<button type="button" class="btn-royal !bg-none bg-gray-500 border-gray-400 !text-gray-200 h-[45px] w-[85px] text-[10px] shrink-0" disabled><i class="fas fa-check mb-1"></i>ĐÃ LÀM</button>`
                                : `<div class="flex flex-col gap-1 shrink-0 w-[85px]">
                                    <button type="button" onclick="App.doTask('${t.link}')" class="btn-royal h-[24px] text-[9px] !bg-none bg-blue-600 border-blue-500 !text-white">LÀM</button>
                                    <button type="button" onclick="App.verifyTask(${t.id})" class="btn-royal h-[24px] text-[9px] !bg-none bg-green-600 border-green-500 !text-white">KIỂM TRA</button>
                                   </div>`
                            }
                        </div>`;
                    }).join('');
                } else {
                    taskHtml = `<p class="text-[var(--text-muted)] text-[11px] italic mt-4">Tạm thời triều đình chưa có ban chiếu chỉ nhiệm vụ nào.</p>`;
                }

                document.getElementById('merch-content').innerHTML = `
                <div class="py-2">
                    <i class="fas fa-hands-helping text-4xl text-blue-500 mb-3 drop-shadow-[0_0_5px_rgba(59,130,246,0.5)]"></i>
                    <p class="text-[11px] text-[var(--text-main)] opacity-80 mb-4 px-2 leading-relaxed">Hoàn thành các chiếu chỉ dưới đây để nhận phần thưởng!</p>
                    <div class="max-h-[40vh] overflow-y-auto pr-1">
                        ${taskHtml}
                    </div>
                </div>`;
            }
            
        } else if(tab === 'spin') {
            this.currentMerchantModal = '';
            mb.innerHTML = `
            <div class="text-center pb-2">
                <h3 class="font-empire text-[16px] text-c-gold border-b border-[var(--gold)]/30 pb-2 mb-4 mt-2">
                    <i class="fas fa-dharmachakra mr-2 text-[var(--text-main)]"></i> VÒNG QUAY VẬN MỆNH
                </h3>
                <div class="bg-black/50 border border-[var(--dark-gold)] p-4 rounded-full w-28 h-28 mx-auto flex items-center justify-center mb-4 shadow-[0_0_15px_rgba(255,215,0,0.3)] overflow-hidden">
                    <i class="fas fa-dharmachakra text-5xl text-c-gold transition-transform duration-1000 ease-in-out" id="spin-icon"></i>
                </div>
                <p class="text-[var(--text-muted)] text-[10px] mb-4 px-2">Mỗi lượt quay tiêu tốn <span class="text-yellow-500 font-bold">10,000 Vàng</span>. Phần thưởng sẽ được <strong class="text-green-500">NHÂN LÊN</strong> theo Cấp Hoàng Cung của ngài!</p>
                <div id="spin-result" class="mb-4 text-[12px] font-bold h-4 text-[var(--text-main)] drop-shadow-md"></div>
                <div id="spin-controls">
                    <button type="button" id="btn-spin" onclick="App.playSpin()" class="btn-royal w-full h-[45px] text-[13px] shadow-lg">
                        <i class="fas fa-play mr-2"></i> QUAY NGAY <span class="text-[10px] ml-1 flex items-center justify-center gap-1">(10K ${coinImg})</span>
                    </button>
                </div>
            </div>`;
        } else if(tab === 'dice') {
            this.currentMerchantModal = '';
            mb.innerHTML = `
            <div class="text-center pb-2">
                <h3 class="font-empire text-[16px] text-c-gold border-b border-[var(--gold)]/30 pb-2 mb-4 mt-2"><i class="fas fa-dice mr-2 text-[var(--text-main)]"></i> DỰ ĐOÁN HOÀNG GIA</h3>
                <p class="text-[var(--text-muted)] text-[10px] mb-3">Nhỏ (3-10) - Lớn (11-18). Phí hệ thống: 2%.</p>
                <div class="flex justify-center gap-4 mb-5" id="dice-container">
                    <div class="w-12 h-12 bg-black/40 border border-[var(--gold)]/50 rounded-lg flex items-center justify-center shadow-inner"><i class="fas fa-dice-one text-3xl text-gray-500" id="dice-1"></i></div>
                    <div class="w-12 h-12 bg-black/40 border border-[var(--gold)]/50 rounded-lg flex items-center justify-center shadow-inner"><i class="fas fa-dice-two text-3xl text-gray-500" id="dice-2"></i></div>
                    <div class="w-12 h-12 bg-black/40 border border-[var(--gold)]/50 rounded-lg flex items-center justify-center shadow-inner"><i class="fas fa-dice-three text-3xl text-gray-500" id="dice-3"></i></div>
                </div>
                <div class="mb-4 relative"><div class="absolute left-3 top-1/2 -translate-y-1/2 flex items-center justify-center w-4 h-4">${coinImg}</div><input type="number" id="dice-bet" class="set-input pl-8 text-center text-[13px] font-bold py-2.5" placeholder="Mức cược tối thiểu 1,000..." value="1000"></div>
                <div id="dice-result" class="mb-4 text-[11px] font-bold h-4"></div>
                <div class="flex gap-3" id="dice-controls">
                    <button type="button" onclick="App.playDice('xiu')" class="flex-1 bg-gradient-to-b from-gray-700 to-gray-900 border border-gray-500 hover:border-gray-400 text-white font-black py-3 rounded-lg shadow-[0_0_10px_rgba(255,255,255,0.1)] active:scale-95 transition text-[14px]">NHỎ (3-10)</button>
                    <button type="button" onclick="App.playDice('tai')" class="flex-1 bg-gradient-to-b from-red-700 to-red-900 border border-red-500 hover:border-red-400 text-white font-black py-3 rounded-lg shadow-[0_0_10px_rgba(255,0,0,0.2)] active:scale-95 transition text-[14px]">LỚN (11-18)</button>
                </div>
            </div>`;
        } else if(tab === 'flip') {
            this.currentMerchantModal = '';
            mb.innerHTML = `
            <div class="text-center pb-2">
                <h3 class="font-empire text-[16px] text-c-gold border-b border-[var(--gold)]/30 pb-2 mb-4 mt-2"><i class="fas fa-clone mr-2 text-[var(--text-main)]"></i> LẬT BÀI HOÀNG GIA</h3>
                <p class="text-[var(--text-muted)] text-[10px] mb-3">Tìm đúng Kim Bài để x1.95 số Vàng.</p>
                <div class="mb-4 relative"><div class="absolute left-3 top-1/2 -translate-y-1/2 flex items-center justify-center w-4 h-4">${coinImg}</div><input type="number" id="flip-bet" class="set-input pl-8 text-center text-[13px] font-bold py-2.5" placeholder="Mức cược tối thiểu 1,000..." value="1000"></div>
                <div id="flip-result" class="mb-4 text-[11px] font-bold h-4"></div>
                <div class="flex justify-center gap-6 mb-2" id="flip-controls">
                    <div id="card-0" onclick="App.playFlip(0)" class="w-24 h-36 bg-black/60 rounded-xl cursor-pointer shadow-[0_0_15px_rgba(0,0,0,0.5)] border-2 border-c-gold transition-transform active:scale-95 relative flex items-center justify-center"><i class="fas fa-question text-4xl text-c-gold transition-all duration-500" id="card-inner-0"></i></div>
                    <div id="card-1" onclick="App.playFlip(1)" class="w-24 h-36 bg-black/60 rounded-xl cursor-pointer shadow-[0_0_15px_rgba(0,0,0,0.5)] border-2 border-c-gold transition-transform active:scale-95 relative flex items-center justify-center"><i class="fas fa-question text-4xl text-c-gold transition-all duration-500" id="card-inner-1"></i></div>
                </div>
                <p class="text-[var(--text-muted)] text-[9px] italic mt-2">Chạm vào lá bài để mở</p>
            </div>`;
        } else if(tab === 'race') {
            this.currentMerchantModal = '';
            mb.innerHTML = `
            <div class="text-center pb-2">
                <h3 class="font-empire text-[16px] text-c-gold border-b border-[var(--gold)]/30 pb-2 mb-3 mt-2"><i class="fas fa-horse-head mr-2 text-[var(--text-main)]"></i> KỴ BINH XUNG TRẬN</h3>
                <p class="text-[var(--text-muted)] text-[10px] mb-3">Chọn chiến mã xuất sắc nhất. Tỷ lệ x2.85.</p>
                <div class="mb-3 relative"><div class="absolute left-3 top-1/2 -translate-y-1/2 flex items-center justify-center w-4 h-4">${coinImg}</div><input type="number" id="race-bet" class="set-input pl-8 text-center text-[13px] font-bold py-2" placeholder="Mức cược tối thiểu 1,000..." value="1000"></div>
                <div id="race-result" class="mb-3 text-[11px] font-bold h-4"></div>
                <div class="bg-black/50 p-2 rounded-lg border border-[var(--gold)]/30 relative overflow-hidden mb-4 shadow-inner">
                    <div class="absolute right-4 top-0 bottom-0 w-1 bg-red-600 z-0 opacity-50"></div>
                    <div class="flex items-center mb-2 border-b border-[var(--gold)]/20 pb-1 relative z-10"><span class="w-6 text-center font-bold text-[var(--text-muted)]">#1</span><div class="flex-1 relative h-6"><i class="fas fa-horse text-xl text-red-500 absolute left-0 transition-all duration-[3000ms] ease-in-out" id="horse-1"></i></div></div>
                    <div class="flex items-center mb-2 border-b border-[var(--gold)]/20 pb-1 relative z-10"><span class="w-6 text-center font-bold text-[var(--text-muted)]">#2</span><div class="flex-1 relative h-6"><i class="fas fa-horse text-xl text-blue-500 absolute left-0 transition-all duration-[3000ms] ease-in-out" id="horse-2"></i></div></div>
                    <div class="flex items-center relative z-10"><span class="w-6 text-center font-bold text-[var(--text-muted)]">#3</span><div class="flex-1 relative h-6"><i class="fas fa-horse text-xl text-green-500 absolute left-0 transition-all duration-[3000ms] ease-in-out" id="horse-3"></i></div></div>
                </div>
                <div class="flex gap-2" id="race-controls">
                    <button type="button" onclick="App.playRace(1)" class="flex-1 bg-red-900/80 border border-red-500 hover:bg-red-800 text-white font-black py-2 rounded shadow-lg active:scale-95 transition text-[11px]">CHỌN SỐ 1</button>
                    <button type="button" onclick="App.playRace(2)" class="flex-1 bg-blue-900/80 border border-blue-500 hover:bg-blue-800 text-white font-black py-2 rounded shadow-lg active:scale-95 transition text-[11px]">CHỌN SỐ 2</button>
                    <button type="button" onclick="App.playRace(3)" class="flex-1 bg-green-900/80 border border-green-500 hover:bg-green-800 text-white font-black py-2 rounded shadow-lg active:scale-95 transition text-[11px]">CHỌN SỐ 3</button>
                </div>
            </div>`;
        } else if(tab === 'empire') {
            this.currentMerchantModal = '';
            mb.innerHTML = `<h3 class="font-empire text-center text-c-gold border-b border-[var(--gold)]/20 pb-2 mb-3 text-sm"><i class="fas fa-chess-knight mr-1"></i> Hồ Sơ Hoàng Đế</h3>
            <div class="flex items-center gap-3 mb-3 royal-box p-2 shadow-inner">
                <img src="${document.getElementById('ui-avatar').src}" class="w-12 h-12 rounded-full object-cover border-2 border-[var(--dark-gold)] shadow-[0_0_10px_rgba(255,215,0,0.4)]">
                <div class="flex-1">
                    <h2 class="text-c-gold font-empire font-black text-[15px] drop-shadow-md leading-none mb-1">${this.user.first_name}</h2>
                    <p class="text-[var(--text-muted)] text-[9px] uppercase mb-1">ID: <span class="text-[var(--text-main)] opacity-80 font-mono">${this.user.telegram_id}</span></p>
                </div>
                <div class="text-right">
                    <p class="text-yellow-500 text-[12px] font-bold mt-1 flex items-center justify-end gap-1">${coinImg} ${formatFullNum(this.user.gold)}</p>
                </div>
            </div>
            
            <div class="flex justify-between border-b border-[var(--gold)]/20 pb-0 mb-3">
                <button type="button" id="btn-emp-stats" onclick="App.renderEmpireTab('stats')" class="flex-1 text-[10px] font-bold pb-1 text-c-gold border-b-2 border-[var(--gold)] transition-all">Chỉ Số</button>
                <button type="button" id="btn-emp-resources" onclick="App.renderEmpireTab('resources')" class="flex-1 text-[10px] font-bold pb-1 text-[var(--text-muted)] border-b-2 border-transparent transition-all">Kho Tàng</button>
                <button type="button" id="btn-emp-yield" onclick="App.renderEmpireTab('yield')" class="flex-1 text-[10px] font-bold pb-1 text-[var(--text-muted)] border-b-2 border-transparent transition-all">Sản Lượng</button>
                <button type="button" id="btn-emp-buildings" onclick="App.renderEmpireTab('buildings')" class="flex-1 text-[10px] font-bold pb-1 text-[var(--text-muted)] border-b-2 border-transparent transition-all">Kiến Trúc</button>
            </div>
            <div id="empire-content" class="h-[40vh] overflow-y-auto pr-1"></div>`;
            setTimeout(() => this.renderEmpireTab('stats'), 50);
        } else if(tab === 'settings') { 
            this.currentMerchantModal = '';
            this.renderSettings('main'); 
        }
    },
    
    closeModal() { 
        this.currentMerchantModal = '';
        const m = document.getElementById('modal-overlay'); m.classList.add('hidden'); m.classList.remove('modal-active'); 
        const closeBtn = document.getElementById('modal-close-btn'); if(closeBtn) closeBtn.style.display = 'block'; 
    },
    
    copyInviteLink() {
        const link = `https://t.me/VuongTrieuTruyenKyBot?start=${this.user.telegram_id}`;
        const text = `👑Hoàng Đế! Hãy gia nhập Vương Triều Truyền Kỳ để cùng ta xưng bá thiên hạ!\n ${link}`;
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(() => this.toast('Đã chép thiếp mời Hảo Hữu!', 'success')).catch(() => this.toast('Lỗi copy!', 'error'));
        } else {
            let t = document.createElement("textarea"); t.value = text;
            t.style.position = "fixed"; t.style.left = "-999999px";
            document.body.appendChild(t); t.focus(); t.select();
            try { document.execCommand('copy'); this.toast('Đã chép thiếp mời Hảo Hữu!', 'success'); } catch (err) { this.toast('Lỗi copy!', 'error'); }
            t.remove();
        }
    },

    async switchTab(tab, el) {
        if(el) { document.querySelectorAll('.hub-item').forEach(i => i.classList.remove('active')); el.classList.add('active'); }
        else if (['home', 'build', 'dungeon', 'invite', 'market', 'bank'].includes(tab)) {
            document.querySelectorAll('.hub-item').forEach(i => i.classList.remove('active'));
            const items = document.querySelectorAll('#hub-main .hub-item');
            if(tab==='home') items[0].classList.add('active');
            if(tab==='build') items[1].classList.add('active');
            if(tab==='dungeon') items[2].classList.add('active');
            if(tab==='invite') items[3].classList.add('active');
            if(tab==='market') items[4].classList.add('active');
            if(tab==='bank') items[5].classList.add('active');
        }
        
        this.currentTab = tab;
        const v = document.getElementById('main-view'); 
        v.style.overflowY = 'auto';
        v.scrollTo({ top: 0, behavior: 'smooth' });

        if(tab === 'home') { Tabs.renderHome(v, this); } 
        else if(tab === 'build') { Tabs.renderBuild(v, this); } 
        else if(tab === 'dungeon') { Tabs.renderDungeon(v, this); } 
        else if(tab === 'invite') { Tabs.renderInvite(v, this); } 
        else if (['checkin', 'leaderboard', 'minigame', 'support', 'bank', 'settings', 'market'].includes(tab)) {
            if(tab === 'settings') {
                this.openModal('settings');
            } else {
                Tabs.renderSubTab(tab, v, this);
            }
        }
    },

    tap(e) {
        this.user.energy = Number(this.user.energy || 0);
        this.user.tap_level = Number(this.user.tap_level || 1);
        const cost = this.user.tap_level; 
        if (this.user.energy < cost) return;
        
        let x = window.innerWidth / 2; 
        let y = window.innerHeight / 2;
        if(e) {
            if (e.type === 'touchstart') e.preventDefault();
            if(e.touches && e.touches.length > 0) { x = e.touches[0].clientX; y = e.touches[0].clientY; }
            else if(e.clientX) { x = e.clientX; y = e.clientY; }
        }

        this.user.energy -= cost; 
        this.tapQueue.total++;

        const hasIron = this.inventory && this.inventory.some(b => b.id === 'ironmine' && b.level > 0);
        const hasDarkIron = this.inventory && this.inventory.some(b => b.id === 'darkiron_mine' && b.level > 0);
        const hasJade = this.inventory && this.inventory.some(b => b.id === 'jade_cave' && b.level > 0);
        const hasGlaze = this.inventory && this.inventory.some(b => b.id === 'glazekiln' && b.level > 0);
        const hasPurpleGold = this.inventory && this.inventory.some(b => b.id === 'purplegold_mine' && b.level > 0);

        let pool = [
            { id: 'wood', icon: 'fa-tree text-[#D4AF37]', color: '#F5DEB3', weight: 50 },
            { id: 'stone', icon: 'fa-cube text-gray-300', color: '#D1D5DB', weight: 50 }
        ];

        if(hasIron) pool.push({ id: 'iron', icon: 'fa-cubes text-gray-400', color: '#A9A9A9', weight: 35 });
        if(hasDarkIron) pool.push({ id: 'dark_iron', icon: 'fa-meteor text-purple-400', color: '#C084FC', weight: 25 });
        if(hasJade) pool.push({ id: 'jade', icon: 'fa-gem text-teal-400', color: '#2DD4BF', weight: 15 });
        if(hasGlaze) pool.push({ id: 'glaze', icon: 'fa-ring text-blue-300', color: '#93C5FD', weight: 7 });
        if(hasPurpleGold) pool.push({ id: 'purple_gold', icon: 'fa-crown text-purple-600', color: '#C084FC', weight: 3 });

        let totalWeight = pool.reduce((sum, item) => sum + item.weight, 0);
        let randomNum = Math.random() * totalWeight; let drop = pool[0];
        for (let item of pool) { if (randomNum < item.weight) { drop = item; break; } else { randomNum -= item.weight; } }

        this.user[drop.id] = (this.user[drop.id] || 0) + cost; 
        this.tapQueue[drop.id] = (this.tapQueue[drop.id] || 0) + 1; 

        this.updateUI();
        if(this.hapticEnabled && this.tg.HapticFeedback) this.tg.HapticFeedback.impactOccurred('light');

        const btn = document.querySelector('.tap-circle');
        if(btn) { btn.style.transform = 'scale(0.95)'; setTimeout(() => btn.style.transform = 'scale(1)', 100); }

        const f = document.createElement('div');
        f.className = 'res-pop flex items-center justify-center z-[9000]';
        f.style.left = `${x - 20}px`; 
        f.style.top = `${y - 20}px`;
        f.innerHTML = `<i class="fas ${drop.icon} mr-1.5"></i><span class="font-bold text-[20px]" style="color: ${drop.color};">+${cost}</span>`;
        document.body.appendChild(f); setTimeout(() => f.remove(), 800);
    },
    
    async playSpin() {
        if(this.isProcessing) return;
        if(this.user.gold < 10000) return this.toast('Ngân khố không đủ 10,000 Vàng!', 'error');

        this.isProcessing = true;
        const ctrls = document.getElementById('spin-controls');
        if(ctrls) ctrls.style.display = 'none';

        const icon = document.getElementById('spin-icon'); const resDiv = document.getElementById('spin-result');
        resDiv.innerHTML = '<span class="text-yellow-500 animate-pulse"><i class="fas fa-spinner fa-spin mr-1"></i> Đang quay vòng...</span>';
        icon.style.transform = `rotate(${360 * 5 + Math.random() * 360}deg)`;

        const d = await this.api('/api/minigame/spin', {});
        
        setTimeout(() => {
            icon.style.transform = 'none'; 
            if(d.success) { resDiv.innerHTML = `<span class="text-green-400 bg-green-900/40 border border-green-500/50 px-3 py-1 rounded"><i class="fas fa-gift mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); } 
            else { resDiv.innerHTML = `<span class="text-red-400 bg-red-900/40 border border-red-500/50 px-3 py-1 rounded"><i class="fas fa-times mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); }
            
            if(ctrls) ctrls.style.display = 'block';
            this.isProcessing = false;
        }, 1200);
    },

    async playDice(choice) {
        if(this.isProcessing) return;
        const betInput = document.getElementById('dice-bet').value; const bet = parseInt(betInput);
        if(isNaN(bet) || bet < 1000) return this.toast('Cược tối thiểu 1,000 Vàng!', 'error');
        if(this.user.gold < bet) return this.toast('Ngân khố không đủ Vàng!', 'error');

        this.isProcessing = true;
        const ctrls = document.getElementById('dice-controls');
        if(ctrls) ctrls.style.display = 'none';

        const resDiv = document.getElementById('dice-result'); resDiv.innerHTML = '<span class="text-yellow-500 animate-pulse"><i class="fas fa-spinner fa-spin mr-1"></i> Xúc xắc đang đổ...</span>';
        const dIcons = ['fa-dice-one', 'fa-dice-two', 'fa-dice-three', 'fa-dice-four', 'fa-dice-five', 'fa-dice-six'];
        
        let rollInterval = setInterval(() => {
            document.getElementById('dice-1').className = `fas ${dIcons[Math.floor(Math.random()*6)]} text-4xl text-yellow-400`;
            document.getElementById('dice-2').className = `fas ${dIcons[Math.floor(Math.random()*6)]} text-4xl text-yellow-400`;
            document.getElementById('dice-3').className = `fas ${dIcons[Math.floor(Math.random()*6)]} text-4xl text-yellow-400`;
        }, 80);

        const d = await this.api('/api/minigame/dice', { bet, choice });

        setTimeout(() => {
            clearInterval(rollInterval);
            if(d.dice) {
                document.getElementById('dice-1').className = `fas ${dIcons[d.dice[0]-1]} text-4xl ${d.success ? 'text-green-500' : 'text-red-500'}`;
                document.getElementById('dice-2').className = `fas ${dIcons[d.dice[1]-1]} text-4xl ${d.success ? 'text-green-500' : 'text-red-500'}`;
                document.getElementById('dice-3').className = `fas ${dIcons[d.dice[2]-1]} text-4xl ${d.success ? 'text-green-500' : 'text-red-500'}`;
            }

            if(d.success) { resDiv.innerHTML = `<span class="text-green-400 bg-green-900/40 border border-green-500/50 px-3 py-1 rounded"><i class="fas fa-check mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); } 
            else { resDiv.innerHTML = `<span class="text-red-400 bg-red-900/40 border border-red-500/50 px-3 py-1 rounded"><i class="fas fa-times mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); }
            
            setTimeout(() => {
                if(ctrls) ctrls.style.display = 'flex';
                this.isProcessing = false;
                if(document.getElementById('dice-1')) {
                    document.getElementById('dice-1').className = 'fas fa-dice-one text-4xl text-gray-500'; document.getElementById('dice-2').className = 'fas fa-dice-two text-4xl text-gray-500'; document.getElementById('dice-3').className = 'fas fa-dice-three text-4xl text-gray-500';
                }
            }, 2000);
        }, 1000);
    },

    async playFlip(choice) {
        if(this.isProcessing) return;
        const bet = parseInt(document.getElementById('flip-bet').value);
        if(isNaN(bet) || bet < 1000) return this.toast('Cược tối thiểu 1,000 Vàng!', 'error');

        this.isProcessing = true;
        const ctrls = document.getElementById('flip-controls');
        if(ctrls) ctrls.style.pointerEvents = 'none';

        const resDiv = document.getElementById('flip-result'); resDiv.innerHTML = '<span class="text-yellow-500 animate-pulse"><i class="fas fa-spinner fa-spin mr-1"></i> Đang lật bài...</span>';

        const d = await this.api('/api/minigame/flip', { bet, choice });
        const inner0 = document.getElementById('card-inner-0'); const inner1 = document.getElementById('card-inner-1');

        if(d.result === 0) { inner0.className = "fas fa-crown text-5xl text-yellow-500 transition-all duration-500 transform scale-0"; inner1.className = "fas fa-skull text-5xl text-red-500 transition-all duration-500 transform scale-0"; } 
        else { inner0.className = "fas fa-skull text-5xl text-red-500 transition-all duration-500 transform scale-0"; inner1.className = "fas fa-crown text-5xl text-yellow-500 transition-all duration-500 transform scale-0"; }

        setTimeout(() => {
            inner0.classList.remove('scale-0'); inner0.classList.add('scale-100'); inner1.classList.remove('scale-0'); inner1.classList.add('scale-100');
            if(d.success) { resDiv.innerHTML = `<span class="text-green-400 bg-green-900/40 border border-green-500/50 px-3 py-1 rounded"><i class="fas fa-check mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); } 
            else { resDiv.innerHTML = `<span class="text-red-400 bg-red-900/40 border border-red-500/50 px-3 py-1 rounded"><i class="fas fa-times mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); }
            
            setTimeout(() => { 
                if(ctrls) ctrls.style.pointerEvents = 'auto';
                this.isProcessing = false;
                if(document.getElementById('flip-result')) { 
                    inner0.className = 'fas fa-question text-4xl text-c-gold transition-all duration-500'; inner1.className = 'fas fa-question text-4xl text-c-gold transition-all duration-500'; 
                } 
            }, 2000);
        }, 300);
    },

    async playRace(choice) {
        if(this.isProcessing) return;
        const bet = parseInt(document.getElementById('race-bet').value);
        if(isNaN(bet) || bet < 1000) return this.toast('Cược tối thiểu 1,000 Vàng!', 'error');

        this.isProcessing = true;
        const ctrls = document.getElementById('race-controls');
        if(ctrls) ctrls.style.display = 'none';

        const resDiv = document.getElementById('race-result'); resDiv.innerHTML = '<span class="text-yellow-500 animate-pulse"><i class="fas fa-flag-checkered mr-1"></i> Cuộc đua bắt đầu...</span>';
        const h1 = document.getElementById('horse-1'); const h2 = document.getElementById('horse-2'); const h3 = document.getElementById('horse-3');
        h1.style.left = '0'; h2.style.left = '0'; h3.style.left = '0';

        const d = await this.api('/api/minigame/race', { bet, choice });

        setTimeout(() => {
            const winner = d.winner; let p = [0, 0, 0];
            for(let i=1; i<=3; i++) { if(i === winner) p[i-1] = '85%'; else p[i-1] = `${Math.floor(Math.random() * 40) + 30}%`; }
            h1.style.left = p[0]; h2.style.left = p[1]; h3.style.left = p[2];

            setTimeout(() => {
                if(d.success) { resDiv.innerHTML = `<span class="text-green-400 bg-green-900/40 border border-green-500/50 px-3 py-1 rounded"><i class="fas fa-trophy mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); } 
                else { resDiv.innerHTML = `<span class="text-red-400 bg-red-900/40 border border-red-500/50 px-3 py-1 rounded"><i class="fas fa-times mr-1"></i> ${d.msg}</span>`; this.syncAfterAction(); }
                
                setTimeout(() => { 
                    if(ctrls) ctrls.style.display = 'flex';
                    this.isProcessing = false;
                    if(document.getElementById('race-result')) { 
                        h1.style.left = '0'; h2.style.left = '0'; h3.style.left = '0'; 
                    } 
                }, 2000);
            }, 3000); 
        }, 100);
    },

    async withdraw() {
        const a = document.getElementById('wd-a').value; 
        const b = localStorage.getItem('user_bank');
        if(!a || a < 1000000) return this.toast('Số Vàng rút tối thiểu là 1,000,000!', 'error');
        if(!b || b === 'Chưa thiết lập' || !b.includes('|')) return this.toast('Xin ngài cập nhật thông Ngân hàng trước!', 'error');
        const authCheck = await this.api('/api/auth/check', {});
        if(authCheck && !authCheck.success) {
            const banScreen = document.getElementById('ban-screen');
            if(banScreen) {
                banScreen.classList.replace('hidden', 'flex');
                banScreen.innerHTML = `<div class="bg-black/90 p-6 rounded-xl border border-red-500 shadow-[0_0_20px_red] text-center max-w-sm mx-4"><i class="fas fa-user-slash text-5xl text-red-500 mb-4 animate-bounce"></i><h2 class="text-xl font-black text-red-400 mb-2 font-empire">TRỤC XUẤT</h2><p class="text-gray-300 text-sm font-bold leading-relaxed">Phát hiện Hoàng Đế đã rời khỏi Vương Triều hoặc chưa xác minh! Lệnh bài bị tước bỏ. Hãy thoát ra và kiểm tra lại Bot!</p></div>`;
            }
            return;
        }
        
        if(this.isProcessing) return;
        this.isProcessing = true;
        const d = await this.api('/api/withdraw', { amount: Number(a), bank_info: b });
        
        if(d.success) { 
            this.toast(d.msg, 'success'); 
            this.syncAfterAction(); 
            this.switchTab('bank'); 
        } else { 
            this.toast(d.msg || "Lỗi", 'error'); 
        }
        this.isProcessing = false;
    },
    
    async syncAfterAction() {
        const d = await this.api('/api/user', { start_param: "", device_code: window.DEVICE_CODE });
        if(d.success) {
            this.user = { ...this.user, ...d.user };
            this.catalog = d.catalog || [];
            this.inventory = d.user.inventory || [];
            this.updateUI();
            const v = document.getElementById('main-view');
            
            if(this.currentTab === 'home') Tabs.renderHome(v, this);
            else if(this.currentTab === 'build') Tabs.renderBuild(v, this);
            else if(this.currentTab === 'dungeon') Tabs.renderDungeon(v, this);
            else if(this.currentTab === 'invite') Tabs.renderInvite(v, this);
            else if(['checkin', 'leaderboard', 'minigame', 'support', 'bank', 'settings', 'market'].includes(this.currentTab)) {
                Tabs.renderSubTab(this.currentTab, v, this);
            }
        }
    },

    updateTrainCostPreview() {
        const q = Number(document.getElementById('train-custom-qty')?.value || 0);
        const box = document.getElementById('train-custom-cost'); if(!box) return;
        if(q <= 0) { box.innerText = 'Tổng phí: --'; return; }
        const c = this.config || {}; const dR = this.user.discount_train || 0;
        const costF = Math.floor(q * (c.train_cost_food||10) * (1-dR));
        const costG = Math.floor(q * (c.train_cost_gold||100) * (1-dR));
        box.innerHTML = `Tổng phí: <span class="text-orange-300">${formatNum(costF)} Lương thực</span> + <span class="text-c-gold">${formatNum(costG)} Vàng</span>`;
    },
    fillTrainMax() {
        const c = this.config || {}; const dR = this.user.discount_train || 0;
        const perF = Math.max(1, Math.floor((c.train_cost_food||10) * (1-dR)));
        const perG = Math.max(1, Math.floor((c.train_cost_gold||100) * (1-dR)));
        const maxByFood = Math.floor((this.user.food||0) / perF);
        const maxByGold = Math.floor((this.user.gold||0) / perG);
        const q = Math.max(0, Math.min(maxByFood, maxByGold));
        const inp = document.getElementById('train-custom-qty'); if(inp) inp.value = q || '';
        this.updateTrainCostPreview();
    },
    async trainCustom() {
        const q = Number(document.getElementById('train-custom-qty')?.value || 0);
        if(!q || q <= 0) return this.toast('Nhập số lính hợp lệ.', 'error');
        await this.train(q);
    },
    confirmAction(title, message, isAlert = false) {
        return new Promise(resolve => {
            const old = document.getElementById('confirm-overlay'); if(old) old.remove();
            const d = document.createElement('div');
            d.id = 'confirm-overlay';
            d.className = 'fixed inset-0 z-[3000] bg-black/80 flex items-center justify-center p-4';
            
            // Nếu là Alert (Thông báo) thì vẽ 1 nút ĐÓNG. Nếu không thì vẽ 2 nút Hủy - Xác nhận.
            let btnsHtml = isAlert 
                ? `<button type="button" id="cf-no" class="w-full h-[40px] rounded btn-royal font-black active:scale-95 transition">ĐÓNG</button>` 
                : `<button type="button" id="cf-no" class="flex-1 h-[40px] rounded bg-gray-800 border border-gray-600 text-gray-200 font-bold active:scale-95 transition">Huỷ</button>
                   <button type="button" id="cf-yes" class="flex-1 h-[40px] rounded btn-royal font-black">Xác nhận</button>`;

            d.innerHTML = `<div class="royal-card w-full max-w-sm p-4 border-2 border-[var(--gold)] shadow-[0_0_25px_rgba(255,215,0,0.35)]">
                <h3 class="font-empire text-c-gold text-lg mb-2 text-center">${title}</h3>
                <div class="text-[12px] text-[var(--text-main)] text-center leading-relaxed mb-4">${message}</div>
                <div class="flex gap-2">${btnsHtml}</div></div>`;
                
            document.body.appendChild(d);
            
            d.querySelector('#cf-no').onclick = () => { d.remove(); resolve(false); };
            const btnYes = d.querySelector('#cf-yes');
            if(btnYes) btnYes.onclick = () => { d.remove(); resolve(true); };
        });
    },
    
    async upgrade(t) { if(!(await this.confirmAction('Nâng cấp', 'Xác nhận dùng Vàng để nâng cấp Long Thể?'))) return; if(this.isProcessing) return; this.isProcessing = true; const d = await this.api('/api/upgrade', { type: t }); if(d.success) { this.toast(d.msg, 'success'); this.syncAfterAction(); } else { this.toast(d.msg || "Lỗi", 'error'); } this.isProcessing = false;},
    async build(id) { if(!(await this.confirmAction('Xây dựng', 'Xác nhận tiêu hao tài nguyên để kiến thiết công trình này?'))) return; if(this.isProcessing) return; this.isProcessing = true; const d = await this.api('/api/build', { building_id: id }); if(d.success) { this.toast(d.msg, 'success'); this.syncAfterAction(); } else { this.toast(d.msg || "Lỗi", 'error'); } this.isProcessing = false;},
    async speedUp(id) { if(!(await this.confirmAction('Đẩy nhanh', 'Xác nhận dùng Vàng để thúc đẩy tiến độ ngay lập tức?'))) return; if(this.isProcessing) return; this.isProcessing = true; const d = await this.api('/api/speedup', { building_id: id }); if(d.success) { this.toast(d.msg, 'success'); this.syncAfterAction(); } else { this.toast(d.msg || "Lỗi", 'error'); } this.isProcessing = false;},
    async train(q) { if(!(await this.confirmAction('Mộ binh', `Xác nhận dùng tài nguyên để chiêu mộ ${q} binh sĩ?`))) return; if(this.isProcessing) return; this.isProcessing = true; const d = await this.api('/api/military/train', { qty: q }); if(d.success) { this.toast(d.msg, 'success'); this.syncAfterAction(); } else { this.toast(d.msg || "Lỗi", 'error'); } this.isProcessing = false;},
    async checkIn() { if(this.isProcessing) return; this.isProcessing = true; const d = await this.api('/api/checkin', {}); if(d.success) { this.toast(d.msg, 'success'); this.syncAfterAction(); } else { this.toast(d.msg || "Lỗi", 'error'); } this.isProcessing = false;},
    
    async battle(isContinuous = false) { 
        if(this.isProcessing) return; 
        this.isProcessing = true; 
        
        const loader = document.getElementById('app-loading');
        const loaderText = document.getElementById('loading-text');
        const pBar = document.getElementById('loading-progress');
        const pText = document.getElementById('loading-percent');
        
        const d = await this.api('/api/military/battle', {}); 
        const isActualBattle = d.success || (d.msg && (d.msg.includes('Thất bại') || d.msg.includes('thất thủ')));

        if(!isContinuous && isActualBattle) {
            if(loader && loaderText) {
                loader.style.opacity = '1';
                loader.style.display = 'flex';
                loader.style.pointerEvents = 'auto';
                loaderText.innerText = "ĐANG HÀNH QUÂN TỚI CHIẾN TRƯỜNG...";
                if(pBar && pText) {
                    pBar.style.transition = 'none'; pBar.style.width = '0%'; pText.innerText = '0%';
                    setTimeout(() => {
                        pBar.style.transition = 'width 2s linear'; pBar.style.width = '100%';
                        let pt = 0; const tId = setInterval(() => { pt += 5; if(pt > 100) pt = 100; pText.innerText = pt + '%'; if(pt >= 100) clearInterval(tId); }, 100);
                    }, 50);
                }
            }
            await new Promise(r => setTimeout(r, 2000));
            if(loader) { loader.style.opacity = '0'; loader.style.pointerEvents = 'none'; setTimeout(() => loader.style.display = 'none', 500); }
        }

        if(isActualBattle) { 
            let match = d.msg ? d.msg.match(/Ải (\d+)/i) : null;
            let currentStage = match ? parseInt(match[1]) : (this.user.current_stage || 1); 
            if(window.BattleSystem) {
                window.BattleSystem.startBattle(d.success, currentStage, d.msg, isContinuous);
            } else {
                this.toast(d.msg, d.success ? 'success' : 'error');
            }
        } else { 
            if(isContinuous && window.BattleSystem) window.BattleSystem.showErrorAndForceRetreat(d.msg || "Không đủ quân lương!");
            else this.toast(d.msg || "Không đủ điều kiện xuất quân!", 'error'); 
        } 
        
        await this.syncAfterAction(); 
        this.isProcessing = false;
    },
    async submitGiftcode() {
        const code = document.getElementById('inp-giftcode').value.trim().toUpperCase();
        if(!code) return this.toast('Vui lòng nhập mã cống phẩm!', 'error');
        if(this.isProcessing) return;
        this.isProcessing = true;
        const d = await this.api('/api/giftcode', { code });
        if(d.success) {
            this.toast(d.msg, 'success');
            document.getElementById('inp-giftcode').value = '';
            this.syncAfterAction();
        } else {
            this.toast(d.msg, 'error');
        }
        this.isProcessing = false;
    },

    doTask(link) {
        if (this.tg.openLink) this.tg.openLink(link);
        else window.open(link, '_blank');
    },

    async verifyTask(taskId) {
        if(this.isProcessing) return;
        this.isProcessing = true;
        this.toast('Thương nhân đang xác minh...', 'info');
        
        setTimeout(async () => {
            const d = await this.api('/api/tasks/claim', { task_id: taskId });
            if(d.success) {
                this.toast(d.msg, 'success');
                this.syncAfterAction(); 
                this.openModal('merchant', 'help'); 
            } else {
                this.toast(d.msg, 'error');
            }
            this.isProcessing = false;
        }, 1500); 
    }
};

window.App = App;

window.onload = () => App.init(true);
