const BattleSystem = {
    isAnimating: false,

    init() {
        if (document.getElementById('battle-overlay-container')) return;

        const style = document.createElement('style');
        style.innerHTML = `
        #battle-overlay { width: 100%; max-width: 600px; height: 100vh; background-image: url('https://i.ibb.co/TBrjSQXp/IMG-20260430-201925.png'); background-size: cover; background-position: center; position: relative; overflow: hidden; border: 2px solid #D4AF37; margin: 0 auto; box-shadow: 0 0 50px rgba(0,0,0,1); }
        .dark-mask { position: absolute; inset: 0; background: rgba(0,0,0,0.4); z-index: 1; }
        
        /* === BỐ CỤC UI THANH MÁU === */
        .top-ui { position: absolute; top: 2rem; left: 1rem; right: 1rem; display: flex; justify-content: space-between; z-index: 50; }
        
        /* Căn giữa tên so với thanh HP */
        .info-box { width: 45%; display: flex; flex-direction: column; align-items: center; text-align: center; }
        
        .name-label { width: 100%; font-size: 13px; font-weight: 900; margin-bottom: 4px; font-family: serif; text-shadow: 0 2px 2px black; letter-spacing: -0.5px; text-align: center; }
        .name-p { color: #eab308; }
        .name-e { color: #ef4444; }

        .hp-box { width: 100%; background: rgba(0,0,0,0.8); border: 2px solid rgba(255,215,0,0.5); border-radius: 8px; height: 16px; position: relative; overflow: hidden; box-shadow: 0 0 10px black; }
        .hp-trail { position: absolute; top: 0; left: 0; height: 100%; background: #ffffff; transition: width 0.5s ease-out; z-index: 1; }
        .hp-main { position: absolute; top: 0; left: 0; height: 100%; transition: width 0.15s ease-out; z-index: 2; }
        .player-color { background: linear-gradient(90deg, #004d99, #3399ff); }
        .enemy-color { background: linear-gradient(90deg, #800000, #ff3333); }
        .hp-text { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: white; font-size: 10px; font-weight: 900; z-index: 3; text-shadow: 0 1px 1px black; font-family: 'Cinzel', serif; }
        
        /* === THIẾT KẾ VÕ TƯỚNG === */
        .fighter { position: absolute; bottom: 30%; display: flex; align-items: flex-end; justify-content: center; transform-origin: bottom center; z-index: 10; }
        #p-sprite { left: 2%; width: 150px; height: 150px; z-index: 20; }
        #e-sprite { right: -54%; width: 500px; height: 400px; overflow: hidden; z-index: 10; }

        .portrait { width: 100%; height: 100%; object-fit: contain; display: block; filter: drop-shadow(0 0 15px rgba(0,0,0,0.8)); }
        #e-sprite img { transform: scaleX(1) !important; }

        @keyframes idleBreath { 
            0%, 100% { transform: scaleY(1); } 
            50% { transform: scaleY(1.02) translateY(-2px); } 
        }
        .idle { animation: idleBreath 2.5s infinite ease-in-out; }

        /* Đòn đánh của Lính: Tầm lao tới 35% */
        @keyframes atkL { 
            0% { left: 2%; transform: scale(1) translateY(0); } 
            50% { left: 27%; transform: scale(1) translateY(-20px); } 
            100% { left: 2%; transform: scale(1) translateY(0); } 
        }
        
        @keyframes atkR { 
            0% { right: -54%; transform: scale(1) translateY(0); } 
            50% { right: -25%; transform: scale(1) translateY(40px); } 
            100% { right: -54%; transform: scale(1) translateY(0); } 
        }
        
        .anim-p { animation: atkL 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .anim-e { animation: atkR 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }

        @keyframes hitShake { 
            0%, 100% { transform: translateX(0); filter: brightness(1); } 
            25% { transform: translateX(-12px); filter: brightness(2) contrast(1.5) drop-shadow(0 0 20px red); } 
            75% { transform: translateX(12px); } 
        }
        .hit { animation: hitShake 0.4s ease-in-out; }

        @keyframes screenShake { 0% { transform: translate(0, 0); } 20% { transform: translate(-6px, 5px); } 40% { transform: translate(6px, -5px); } 60% { transform: translate(-6px, -5px); } 80% { transform: translate(6px, 5px); } 100% { transform: translate(0, 0); } }
        .shake-hard { animation: screenShake 0.4s ease-in-out; }

        @keyframes dmgFloat { 0% { opacity: 1; transform: translateY(0) scale(1); } 100% { opacity: 0; transform: translateY(-80px) scale(1.3); } }
        .dmg { position: absolute; font-weight: 900; font-size: 38px; color: #ff4444; text-shadow: 2px 2px 0 #000, -2px -2px 0 #000, 2px -2px 0 #000, -2px 2px 0 #000; animation: dmgFloat 0.9s forwards; pointer-events: none; z-index: 100; }
        .crit { color: #FFD700; font-size: 52px; text-shadow: 0 0 10px red, 2px 2px 0 #000; z-index: 101; }
        
        #res-box { position: absolute; inset: 0; background: rgba(0,0,0,0.9); z-index: 1000; display: flex; flex-direction: column; align-items: center; justify-content: center; transform: scale(0); opacity: 0; pointer-events: none; backdrop-filter: blur(5px); }
        .res-active { transform: scale(1) !important; opacity: 1 !important; pointer-events: auto !important; transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), opacity 0.3s; }
        .btn-battle { padding: 12px 24px; border-radius: 30px; font-weight: 900; text-transform: uppercase; font-size: 14px; border: 2px solid; transition: 0.2s; display: flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer; font-family: 'Quicksand', sans-serif; }
        .btn-battle:active { transform: scale(0.95); }
        @keyframes popStage { 0% { opacity: 0; transform: scale(0.5); } 20% { opacity: 1; transform: scale(1.2); } 80% { opacity: 1; transform: scale(1); } 100% { opacity: 0; transform: scale(1.5); } }
        .anim-stage { animation: popStage 1.2s ease-out forwards; }
        `;
        document.head.appendChild(style);

        const div = document.createElement('div');
        div.id = 'battle-overlay-container';
        div.className = 'fixed inset-0 z-[9999] hidden flex justify-center bg-black/90 backdrop-blur-sm';
        div.innerHTML = `
        <div id="battle-overlay">
            <div class="dark-mask"></div>
            
            <div class="top-ui">
                <div class="info-box">
                    <div class="name-label name-p">Vương Triều Tướng</div>
                    <div class="hp-box"><div id="p-hp-txt" class="hp-text">1000/1000</div><div id="p-hp-trail" class="hp-trail" style="width: 100%"></div><div id="p-hp-bar" class="hp-main player-color" style="width: 100%"></div></div>
                </div>
                <div class="info-box">
                    <div id="e-name" class="name-label name-e">Đang tiến vào...</div>
                    <div class="hp-box"><div id="e-hp-txt" class="hp-text">2000/2000</div><div id="e-hp-trail" class="hp-trail" style="width: 100%"></div><div id="e-hp-bar" class="hp-main enemy-color" style="width: 100%"></div></div>
                </div>
            </div>
            
            <div id="p-sprite" class="fighter idle">
                <img src="https://i.ibb.co/CKFF2gnP/Polish-20260430-182417630.png" alt="Vương Triều Tướng" class="portrait">
            </div>
            <div id="e-sprite" class="fighter idle">
                <img src="https://i.ibb.co/kgKhdDvs/Chat-GPT-Image-18-03-14-30-thg-4-2026.png" alt="Ma Long Quái" class="portrait">
            </div>
            
            <div id="res-box">
                <div id="res-title" class="font-black text-5xl mb-4 font-serif text-shadow-[0_0_20px_currentColor]"></div>
                <div id="res-desc" class="text-white text-center mb-8 px-4 font-bold leading-relaxed text-sm"></div>
                <div id="res-actions" class="flex gap-4 px-4 w-full justify-center"></div>
            </div>
        </div>`;
        document.body.appendChild(div);
    },

    showDmg(id, val, isCrit) {
        const rect = document.getElementById(id).getBoundingClientRect();
        const contRect = document.getElementById('battle-overlay').getBoundingClientRect();
        const d = document.createElement('div');
        d.className = `dmg ${isCrit ? 'crit' : ''}`;
        d.innerText = `-${val.toLocaleString()}`;
        
        const rx = Math.random() * 50 - 25;
        if(id === 'e-sprite') {
            d.style.left = `${contRect.width - 140 + rx}px`; 
        } else {
            d.style.left = `${rect.left - contRect.left + (rect.width/2) + rx}px`;
        }
        d.style.top = `${rect.top - contRect.top + 30}px`; 
        
        document.getElementById('battle-overlay').appendChild(d);
        setTimeout(() => d.remove(), 800);
    },

    upHP(side, cur, max) {
        cur = Math.max(0, cur);
        const pct = (cur/max*100) + '%';
        document.getElementById(`${side}-hp-bar`).style.width = pct;
        document.getElementById(`${side}-hp-txt`).innerText = `${Math.floor(cur).toLocaleString()} / ${max.toLocaleString()}`;
        
        setTimeout(() => {
            const trail = document.getElementById(`${side}-hp-trail`);
            if(trail) trail.style.width = pct;
        }, 300);
    },

    async doHit(atk, def, dmg, crit) {
        return new Promise(resolve => {
            const a = document.getElementById(`${atk}-sprite`);
            const d = document.getElementById(`${def}-sprite`);
            const cont = document.getElementById('battle-overlay');
            
            a.classList.remove('idle');
            a.classList.add(`anim-${atk}`);
            
            setTimeout(() => {
                d.classList.remove('idle');
                d.classList.add('hit');
                
                if(crit) {
                    cont.classList.add('shake-hard');
                    setTimeout(() => cont.classList.remove('shake-hard'), 400);
                }
                
                this.showDmg(`${def}-sprite`, dmg, crit);
                
                setTimeout(() => { 
                    a.classList.remove(`anim-${atk}`); 
                    d.classList.remove('hit'); 
                    a.classList.add('idle');
                    d.classList.add('idle');
                    resolve(); 
                }, 200);
            }, 200);
        });
    },

    prepareNext() {
        document.getElementById('e-name').innerText = `Đang dò xét...`;
        this.upHP('p', 0, 1000); 
        this.upHP('e', 0, 1000);
        if(document.getElementById('p-hp-trail')) document.getElementById('p-hp-trail').style.width = '0%';
        if(document.getElementById('e-hp-trail')) document.getElementById('e-hp-trail').style.width = '0%';
    },

    // Lấy số lính (playerTroops) từ miniapp truyền vào
    async startBattle(isWin, stage, message, isContinuous = false, playerTroops = null) {
        if(this.isAnimating) return; 
        this.isAnimating = true;

        this.init();
        document.getElementById('battle-overlay-container').classList.remove('hidden');
        document.getElementById('res-box').classList.remove('res-active');
        
        const eName = document.getElementById('e-name');
        eName.innerText = `Đang tải ải...`;

        if (isContinuous) {
            const overlay = document.getElementById('battle-overlay');
            const stageText = document.createElement('div');
            stageText.className = 'absolute inset-0 flex items-center justify-center pointer-events-none z-[60]';
            stageText.innerHTML = `<span class="font-empire text-6xl text-yellow-400 font-black drop-shadow-[0_0_20px_red] anim-stage">ẢI ${stage}</span>`;
            overlay.appendChild(stageText);
            await new Promise(r => setTimeout(r, 1200));
            stageText.remove();
        }

        eName.innerText = `Ma Long cấp ${stage}`;
        
        // --- TÍNH TOÁN HP: ĐỒNG BỘ THEO LÍNH ---
        // Mỗi ải tăng 2 lính. Nếu hệ thống truyền số lính thực tế vào thì dùng, không thì tự tính
        let pTroops = playerTroops || (10 + (Math.max(1, stage) - 1) * 2);
        
        // HP của Lãnh Chúa (1 Lính = 500 HP)
        let pm = pTroops * 500;
        
        // HP của Ma Long: Tăng đồng bộ và LUÔN LỚN HƠN HP Lãnh chúa (Gấp 1.2 lần + Thêm máu theo ải)
        let em = Math.floor(pm * 1.2) + (stage * 500);

        // Nếu người chơi Thua, Ma Long sẽ xuất hiện với thanh máu trâu bò hơn nữa để dập tắt hy vọng
        if (!isWin) {
            em = Math.floor(em * 1.5); 
        }
        
        let p = pm;
        let e = em;

        this.upHP('p', p, pm); 
        this.upHP('e', e, em);
        if(document.getElementById('p-hp-trail')) document.getElementById('p-hp-trail').style.width = '100%';
        if(document.getElementById('e-hp-trail')) document.getElementById('e-hp-trail').style.width = '100%';
        
        // Chờ 600ms cho thanh máu chạy mượt trước khi đánh
        await new Promise(r => setTimeout(r, 600));

        // --- KỊCH BẢN ĐẠO DIỄN CHUẨN 5 GIÂY ---
        // Lên kịch bản sát thương (chia làm 3 hit)
        let pHits = isWin ? [
            Math.floor(em * 0.3),  // Hit 1: Lấy 30% máu quái
            Math.floor(em * 0.35), // Hit 2: Lấy 35% máu quái
            em                     // Hit 3: Lấy mạng (100% máu còn lại)
        ] : [
            Math.floor(em * 0.15), // Nếu thua, Lãnh chúa đánh như gãi ngứa
            Math.floor(em * 0.15),
            Math.floor(em * 0.15)
        ];

        let eHits = isWin ? [
            Math.floor(pm * 0.3),  // Quái đánh trả lại
            Math.floor(pm * 0.3)
        ] : [
            Math.floor(pm * 0.3),  // Hit 1: Lấy 30% máu
            Math.floor(pm * 0.35), // Hit 2: Lấy 35% máu
            pm                     // Hit 3: Lấy mạng Lãnh chúa
        ];

        // Random nhẹ sát thương để nhìn thật hơn (nhưng vẫn giữ đúng kịch bản)
        const randomize = (val, isFatal) => isFatal ? val : Math.floor(val * (0.8 + Math.random() * 0.4));

        for (let round = 0; round < 3; round++) {
            // Tới lượt Lãnh Chúa
            let pd = randomize(pHits[round], isWin && round === 2);
            let pc = (isWin && round === 2) ? true : Math.random() < 0.2; // Hit cuối cùng nếu thắng là đòn Chí Mạng
            if (e - pd <= 0) pd = e; 
            
            await this.doHit('p', 'e', pd, pc); 
            e -= pd; 
            this.upHP('e', e, em);
            if (e <= 0) break; // Quái chết -> Dừng trận
            
            await new Promise(r => setTimeout(r, 400));

            // Tới lượt Ma Long
            if (round >= eHits.length) break; 
            let ed = randomize(eHits[round], !isWin && round === 2);
            let ec = (!isWin && round === 2) ? true : Math.random() < 0.2; // Hit cuối cùng nếu thua là đòn Chí Mạng của quái
            if (p - ed <= 0) ed = p; 

            await this.doHit('e', 'p', ed, ec); 
            p -= ed; 
            this.upHP('p', p, pm);
            if (p <= 0) break; // Mình chết -> Dừng trận

            await new Promise(r => setTimeout(r, 400)); 
        }

        // Chờ kết thúc trận đấu hiển thị thông báo. Tổng thời gian luôn đảm bảo vừa khớp 5 giây.
        await new Promise(r => setTimeout(r, isWin ? 400 : 200));

        // --- HIỂN THỊ KẾT QUẢ ---
        const box = document.getElementById('res-box');
        const title = document.getElementById('res-title');
        const desc = document.getElementById('res-desc');
        const acts = document.getElementById('res-actions');

        let formatMsg = message;
        if(isWin) {
            title.innerText = "ĐẠI THẮNG"; 
            title.className = "text-yellow-500 font-black text-5xl mb-4 font-serif drop-shadow-[0_0_20px_yellow]";
            formatMsg = message.replace('!', `!<br><span class="text-yellow-400 text-xl font-black">`).replace('Vàng.', 'Vàng</span>');
            acts.innerHTML = `<button onclick="BattleSystem.close()" class="btn-battle bg-gray-600 border-gray-400 text-white w-1/2 flex-1"><i class="fas fa-sign-out-alt"></i> Rút Binh</button><button onclick="BattleSystem.reBattle()" class="btn-battle bg-gradient-to-b from-yellow-400 to-yellow-600 border-yellow-200 text-black w-1/2 flex-1"><i class="fas fa-forward"></i> Đánh Tiếp</button>`;
        } else {
            title.innerText = "TỬ TRẬN"; 
            title.className = "text-red-500 font-black text-5xl mb-4 font-serif drop-shadow-[0_0_20px_red]";
            formatMsg = message.replace('!', `!<br><span class="text-red-400 text-[16px] font-black">`).replace('binh sĩ!', 'binh sĩ!</span>');
            acts.innerHTML = `<button onclick="BattleSystem.close()" class="btn-battle bg-gray-600 border-gray-400 text-white w-1/2 flex-1"><i class="fas fa-sign-out-alt"></i> Rút Binh</button><button onclick="BattleSystem.reBattle()" class="btn-battle bg-red-600 border-red-400 text-white w-1/2 flex-1"><i class="fas fa-redo"></i> Thử Lại</button>`;
        }
        
        desc.innerHTML = formatMsg;
        box.classList.add('res-active');
        this.isAnimating = false; 
    },

    showErrorAndForceRetreat(msg) {
        const box = document.getElementById('res-box');
        const title = document.getElementById('res-title');
        const desc = document.getElementById('res-desc');
        const acts = document.getElementById('res-actions');

        title.innerText = "CẠN KIỆT"; 
        title.className = "text-red-500 font-black text-5xl mb-4 font-serif drop-shadow-[0_0_20px_red]";
        desc.innerHTML = `<div class="text-white text-sm mb-3">${msg}</div><div class="text-yellow-400 font-bold text-xs uppercase animate-pulse">Hãy Rút Binh để bổ sung lực lượng!</div>`;
        acts.innerHTML = `<button onclick="BattleSystem.close()" class="btn-battle bg-red-600 border-red-400 text-white w-full"><i class="fas fa-sign-out-alt"></i> Rút Binh Về Thành</button>`;
        
        box.classList.add('res-active');
        this.isAnimating = false; 
    },

    async close() {
        const loader = document.getElementById('app-loading');
        const loaderText = document.getElementById('loading-text');
        const pBar = document.getElementById('loading-progress');
        const pText = document.getElementById('loading-percent');
        
        if(loader && loaderText) {
            loader.style.zIndex = '10000';
            loader.style.opacity = '1';
            loader.style.display = 'flex';
            loader.style.pointerEvents = 'auto';
            loaderText.innerText = "ĐANG TRỞ VỀ VƯƠNG TRIỀU...";
            
            if(pBar && pText) {
                pBar.style.transition = 'none';
                pBar.style.width = '0%';
                pText.innerText = '0%';
                setTimeout(() => {
                    pBar.style.transition = 'width 2s linear';
                    pBar.style.width = '100%';
                    let pt = 0;
                    const tId = setInterval(() => {
                        pt += 5;
                        if(pt > 100) pt = 100;
                        pText.innerText = pt + '%';
                        if(pt >= 100) clearInterval(tId);
                    }, 100);
                }, 50);
            }
        }

        await new Promise(r => setTimeout(r, 2000));

        document.getElementById('battle-overlay-container').classList.add('hidden');
        
        if(loader) {
            loader.style.opacity = '0';
            loader.style.pointerEvents = 'none';
            setTimeout(() => { 
                loader.style.display = 'none'; 
                if(loaderText) loaderText.innerText = "Khởi tạo hoàng cung..."; 
                loader.style.zIndex = '9999'; 
            }, 500);
        }
        this.isAnimating = false;
    },

    reBattle() {
        document.getElementById('res-box').classList.remove('res-active');
        this.prepareNext();
        if(typeof window.App !== 'undefined' && typeof window.App.battle === 'function') {
            window.App.battle(true); 
        }
    }
};
window.BattleSystem = BattleSystem;
