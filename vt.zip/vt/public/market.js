window.MarketSystem = {
    ordersCache: [],
    privateOrdersCache: [],
    historyCache: [],
    currentFilter: 'all',
    currentMaxGold: 0, 
    currentTab: 'public', // public | private | history
    currentPrivateSubTab: 'sell', // sell | buy
    historySubTab: 'public', // public | private

    vnMap: { wood:'Gỗ', stone:'Đá', iron:'Sắt', food:'Lương thực', dark_iron:'Huyền Thiết', jade:'Linh Ngọc', glaze:'Lưu Ly', purple_gold:'Tử Kim' },

    init() {
        const container = document.getElementById('market-container');
        if (!container) return;

        // Tự động nhúng CSS cho Dropdown
        if (!document.getElementById('royal-select-style')) {
            const style = document.createElement('style');
            style.id = 'royal-select-style';
            style.innerHTML = `
                .royal-select { appearance: none; -webkit-appearance: none; background-color: rgba(0, 0, 0, 0.5); border: 1px solid var(--gold); color: var(--gold); border-radius: 6px; padding: 6px 24px 6px 8px; outline: none; cursor: pointer; background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffe08a' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 6px center; background-size: 12px; box-shadow: inset 0 0 5px rgba(255, 193, 7, 0.15); transition: all 0.3s ease; }
                .royal-select:focus { border-color: #fff; box-shadow: 0 0 8px rgba(255, 193, 7, 0.5); }
                .royal-select option { background-color: #1a1a1a; color: #ffe08a; font-weight: bold; }
            `;
            document.head.appendChild(style);
        }

        // GIAO DIỆN CHÍNH (Tiêu đề + Nút Lịch Sử + Khối Tab Chính)
        container.innerHTML = `
            <div class="flex justify-between items-center mb-3 px-1 mt-1">
                <h2 class="font-empire text-[16px] text-c-gold drop-shadow-md"><i class="fas fa-store"></i> GIAO DỊCH</h2>
                <button type="button" onclick="MarketSystem.switchTab('history')" class="relative flex items-center gap-1 px-3 py-1.5 bg-[var(--card-bg)] border border-[var(--gold)]/50 rounded-lg text-[10px] font-bold text-yellow-500 shadow-sm active:scale-95 transition-all">
                    <i class="fas fa-history"></i> Lịch Sử
                </button>
            </div>

            <div class="flex bg-black/40 rounded-xl p-1 mb-3 border border-[var(--gold)]/20 shadow-inner">
                <button type="button" id="tab-btn-public" onclick="MarketSystem.switchTab('public')" class="flex-1 py-1.5 rounded-lg text-[12px] font-bold transition-all">CÔNG KHAI</button>
                <button type="button" id="tab-btn-private" onclick="MarketSystem.switchTab('private')" class="relative flex-1 py-1.5 rounded-lg text-[12px] font-bold transition-all">
                    CÁ NHÂN 
                    <span id="dot-private" class="hidden absolute top-1 right-2 w-2 h-2 bg-red-500 rounded-full shadow-[0_0_5px_red]"></span>
                </button>
            </div>

            <div id="market-body" class="w-full"></div>
        `;
        
        this.switchTab('public');
        this.checkNotifications(); // Khởi chạy kiểm tra chấm đỏ
    },

    // ==========================================
    // KIỂM TRA CHẤM ĐỎ (NOTIFICATIONS)
    // ==========================================
    async checkNotifications() {
        try {
            // Tự động cấy chấm đỏ vào thanh menu dưới đáy của index.html (Nếu chưa có)
            const marketNavBtn = document.querySelector('[onclick*="market"]');
            if(marketNavBtn && !document.getElementById('nav-dot-market')) {
                marketNavBtn.style.position = 'relative';
                marketNavBtn.insertAdjacentHTML('beforeend', '<span id="nav-dot-market" class="hidden absolute top-1 right-[25%] w-2 h-2 bg-red-500 rounded-full shadow-[0_0_5px_red] z-50"></span>');
            }

            const d = await App.api('/api/market/private/list', {});
            if(d && d.success) {
                const incoming = (d.orders || d.incoming || []).filter(o => String(o.seller_id) !== String(App.user.telegram_id));
                const seenIds = JSON.parse(localStorage.getItem('seen_market_orders') || '[]');
                
                // Kiểm tra xem có ID lệnh nào chưa có trong danh sách Đã Xem không
                const hasNew = incoming.some(o => !seenIds.includes(o.id));
                
                const menuDot = document.getElementById('nav-dot-market');
                const privDot = document.getElementById('dot-private');
                const buyDot = document.getElementById('dot-buy');
                
                if(hasNew) {
                    if(menuDot) menuDot.classList.remove('hidden');
                    if(privDot) privDot.classList.remove('hidden');
                    if(buyDot) buyDot.classList.remove('hidden');
                } else {
                    if(menuDot) menuDot.classList.add('hidden');
                    if(privDot) privDot.classList.add('hidden');
                    if(buyDot) buyDot.classList.add('hidden');
                }
            }
        } catch(e) { console.warn("Lỗi kiểm tra thông báo:", e); }
    },

    // Đánh dấu đã xem toàn bộ
    markOrdersAsSeen() {
        const incoming = (this.privateOrdersCache || []).filter(o => String(o.seller_id) !== String(App.user.telegram_id));
        const ids = incoming.map(o => o.id);
        localStorage.setItem('seen_market_orders', JSON.stringify(ids)); // Lưu vào máy
        
        // Tắt ngay chấm đỏ
        const menuDot = document.getElementById('nav-dot-market');
        const privDot = document.getElementById('dot-private');
        const buyDot = document.getElementById('dot-buy');
        if(menuDot) menuDot.classList.add('hidden');
        if(privDot) privDot.classList.add('hidden');
        if(buyDot) buyDot.classList.add('hidden');
    },

    switchTab(tab) {
        this.currentTab = tab;
        
        // Cập nhật UI cho 2 Tab chính (Công khai / Cá nhân)
        ['public', 'private'].forEach(t => {
            const btn = document.getElementById(`tab-btn-${t}`);
            if(btn) {
                const isPrivate = (t === 'private');
                if (t === tab) {
                    btn.className = `flex-1 py-1.5 rounded-lg text-[12px] font-black bg-gradient-to-r from-yellow-500 to-yellow-700 text-black shadow-[0_0_10px_rgba(255,215,0,0.3)] border border-yellow-300 transition-all ${isPrivate ? 'relative' : ''}`;
                } else {
                    btn.className = `flex-1 py-1.5 rounded-lg text-[12px] font-bold text-[var(--text-muted)] border border-transparent transition-all ${isPrivate ? 'relative' : ''}`;
                }
            }
        });

        const body = document.getElementById('market-body');
        if(tab === 'public') this.renderPublicUI(body);
        else if(tab === 'private') this.renderPrivateUI(body);
        else if(tab === 'history') this.renderHistoryUI(body);
    },

    // ==========================================
    // 1. CHỢ CÔNG KHAI
    // ==========================================
    renderPublicUI(container) {
        container.innerHTML = `
            <div class="royal-card p-3 mb-4 w-full text-center">
                <h3 class="font-empire text-c-gold text-[12px] mb-2"><i class="fas fa-bullhorn"></i> RAO BÁN CÔNG KHAI</h3>
                <div class="flex gap-2 mb-2">
                    <select id="mk-resource" class="royal-select flex-1 !py-1.5 text-[11px]">
                        ${Object.keys(this.vnMap).map(k => `<option value="${k}">${this.vnMap[k]}</option>`).join('')}
                    </select>
                    <input type="number" id="mk-amount" class="set-input flex-1 !py-1.5 text-[11px]" placeholder="SL (Tối thiểu 1000)...">
                </div>
                <div class="flex gap-2 mb-1">
                    <input type="number" id="mk-price" class="set-input flex-[2] !py-1.5 text-[11px]" placeholder="Giá Vàng...">
                    <button type="button" onclick="MarketSystem.marketSell('public')" class="btn-royal flex-1 h-[30px] text-[10px]"><i class="fas fa-check"></i> XÁC NHẬN</button>
                </div>
                <p class="text-[9px] text-[var(--text-muted)] italic text-left mt-1">*Hàng không ai mua sau 3 ngày sẽ tự hoàn trả.</p>
            </div>

            <div class="w-full">
                <div class="flex gap-2 mb-3 px-1 items-center bg-[var(--card-bg)] p-2 rounded-lg border border-[var(--gold)]/20 shadow-sm">
                    <select id="mk-search-res" class="royal-select flex-1 !py-1.5 text-[11px] !border-[var(--gold)]/50">
                        <option value="all" ${this.currentFilter === 'all' ? 'selected' : ''}>Tất cả nguyên liệu</option>
                        ${Object.keys(this.vnMap).map(k => `<option value="${k}" ${this.currentFilter === k ? 'selected' : ''}>${this.vnMap[k]}</option>`).join('')}
                    </select>
                    <div class="relative flex-1">
                        <div class="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3">${coinImg}</div>
                        <input type="number" id="mk-search-gold" value="${this.currentMaxGold > 0 ? this.currentMaxGold : ''}" class="set-input w-full pl-7 !py-1.5 text-[11px] !border-[var(--gold)]/50" placeholder="Vàng tối đa...">
                    </div>
                    <button type="button" onclick="MarketSystem.executeSearch()" class="btn-royal px-3 h-[30px] text-[10px] shrink-0"><i class="fas fa-search"></i> TÌM</button>
                </div>

                <div id="public-list" class="space-y-2 mb-6">
                    <div class="text-center text-gray-500 py-4"><i class="fas fa-spinner fa-spin"></i> Đang tải chợ...</div>
                </div>

                <div class="h-28 w-full shrink-0"></div>
            </div>
        `;
        this.loadPublicOrders();
    },

    executeSearch() {
        this.currentFilter = document.getElementById('mk-search-res').value || 'all';
        const goldVal = document.getElementById('mk-search-gold').value;
        this.currentMaxGold = goldVal ? Number(goldVal) : 0;
        this.renderPublicList();
    },

    async loadPublicOrders() {
        try {
            const d1 = await App.api('/api/market/list', {});
            if(d1 && d1.success) this.ordersCache = d1.orders || [];
        } catch(e) { console.warn("Lỗi tải market list"); }
        this.renderPublicList();
    },

    renderPublicList() {
        const box = document.getElementById('public-list');
        if (!box) return;

        let orders = this.ordersCache || [];
        if(this.currentFilter !== 'all') orders = orders.filter(o => o.resource_type === this.currentFilter);
        if(this.currentMaxGold > 0) orders = orders.filter(o => o.price_gold <= this.currentMaxGold);

        if(orders.length === 0) { 
            box.innerHTML = `<div class="text-center text-gray-400 py-6">Chưa có lệnh nào phù hợp.</div>`; 
        } else {
            box.innerHTML = orders.map(o => {
                let contactTg = o.contact_tg ? o.contact_tg.replace('@', '') : null;
                let contactHtml = contactTg ? `<button type="button" onclick="window.open('https://t.me/${contactTg}', '_blank')" class="underline text-green-400 font-bold"><i class="fab fa-telegram"></i> Thương lượng</button>` : `<span class="text-gray-500 line-through text-[9px]">Không thể LH</span>`;
                let badgeHtml = this.getBadgeHtml(o.seller_sold_count || 0);

                return `<div class="royal-card p-2 text-[11px] mb-2">
                <div class="flex items-start justify-between gap-2">
                    <div class="flex-1">
                        <div class="text-[var(--text-main)] font-bold text-[12px] opacity-90 flex items-center flex-wrap">
                            Người bán: <span class="text-c-gold ml-1">${o.seller_name || 'Ẩn danh'}</span> ${badgeHtml}
                        </div>
                        <div class="text-[10px] text-gray-400 mb-1">Đã bán: <span class="text-green-400">${formatFullNum(o.seller_sold_count || 0)}</span> đơn</div>
                        <div class="text-blue-300 text-[9px] mt-1 mb-2 flex flex-wrap gap-x-3 gap-y-1">
                            <button type="button" onclick="MarketSystem.viewSellerIntro('${o.seller_id}')" class="underline">Giới thiệu</button>
                            <button type="button" onclick="MarketSystem.viewSellerOrders('${o.seller_id}')" class="underline">Đơn khác</button>
                            ${contactHtml}
                        </div>
                        <div class="font-black text-[var(--text-main)] text-[12px]">Mặt hàng: <span class="text-c-gold">${formatFullNum(o.amount)} ${this.vnMap[o.resource_type] || o.resource_type}</span></div>
                        <div class="text-yellow-500 font-bold text-[11px] mt-0.5">Giá: ${formatFullNum(o.price_gold)} ${coinImg}</div>
                    </div>
                    <div class="flex flex-col gap-1 shrink-0 items-end">
                        <button type="button" onclick="MarketSystem.marketBuy(${o.id})" class="btn-royal h-[34px] w-[55px] text-[10px]"><i class="fas fa-shopping-cart"></i></button>
                        ${String(o.seller_id) === String(App.user.telegram_id) ? `<button type="button" onclick="MarketSystem.marketCancel(${o.id})" class="h-[26px] w-[55px] text-[9px] rounded bg-red-900/50 border border-red-500 text-red-300 active:scale-95 transition">Huỷ đơn</button>`:''}
                    </div>
                </div>
            </div>`}).join('');
        }
    },

    // ==========================================
    // 2. CHỢ CÁ NHÂN (GIAO DỊCH KÍN)
    // ==========================================
    renderPrivateUI(container) {
        // Khác biệt Sub-Tab: Chỉ là chữ gạch chân đơn giản
        container.innerHTML = `
            <div class="flex gap-1 border-b border-purple-500/30 mb-3 px-1">
                <button type="button" id="priv-sub-sell" onclick="MarketSystem.switchPrivateSubTab('sell')" class="flex-1 pb-1.5 text-[11px] font-bold text-purple-400 border-b-2 border-purple-500 transition-all">Lệnh Bán</button>
                <button type="button" id="priv-sub-buy" onclick="MarketSystem.switchPrivateSubTab('buy')" class="relative flex-1 pb-1.5 text-[11px] font-bold text-[var(--text-muted)] border-b-2 border-transparent transition-all">
                    Lệnh Mua <span id="dot-buy" class="hidden absolute top-0 right-[25%] w-2 h-2 bg-red-500 rounded-full shadow-[0_0_5px_red]"></span>
                </button>
            </div>

            <div id="private-dynamic-content" class="w-full">
                <div class="text-center text-gray-500 py-4"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div>
            </div>

            <div class="h-28 w-full shrink-0"></div>
        `;
        this.loadPrivateOrders();
        this.checkNotifications(); // Cập nhật trạng thái chấm đỏ
    },

    switchPrivateSubTab(tab) {
        this.currentPrivateSubTab = tab;
        ['sell', 'buy'].forEach(t => {
            const btn = document.getElementById(`priv-sub-${t}`);
            if(btn) {
                const baseClass = "relative flex-1 pb-1.5 text-[11px] font-bold transition-all ";
                btn.className = baseClass + ((t === tab) 
                    ? "text-purple-400 border-b-2 border-purple-500"
                    : "text-[var(--text-muted)] border-b-2 border-transparent");
            }
        });

        // Tắt chấm đỏ khi người dùng bấm vào tab Lệnh Mua
        if (tab === 'buy') {
            this.markOrdersAsSeen();
        }
        
        this.renderPrivateList();
    },

    async loadPrivateOrders() {
        try {
            const d1 = await App.api('/api/market/private/list', {});
            if(d1 && d1.success) {
                this.privateOrdersCache = d1.orders || d1.incoming || [];
                // Tự động tắt chấm đỏ nếu mở sẵn Lệnh Mua
                if (this.currentPrivateSubTab === 'buy' && this.currentTab === 'private') {
                    this.markOrdersAsSeen();
                }
            }
        } catch(e) { console.warn("Lỗi tải private_list."); }
        
        this.renderPrivateList();
    },

    renderPrivateList() {
        const box = document.getElementById('private-dynamic-content');
        if (!box) return;

        let contentHtml = '';
        const myId = String(App.user.telegram_id);

        if (this.currentPrivateSubTab === 'sell') {
            contentHtml += `
                <div class="royal-card p-3 mb-4 w-full text-center border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]">
                    <h3 class="font-empire text-purple-400 text-[12px] mb-2"><i class="fas fa-user-secret"></i> TẠO LỆNH KÍN</h3>
                    <input type="text" id="mk-priv-target" class="set-input w-full !py-1.5 text-[11px] mb-2 text-center text-purple-300" placeholder="Nhập ID Telegram người mua...">
                    <div class="flex gap-2 mb-2">
                        <select id="mk-priv-resource" class="royal-select flex-1 !py-1.5 text-[11px]">
                            ${Object.keys(this.vnMap).map(k => `<option value="${k}">${this.vnMap[k]}</option>`).join('')}
                        </select>
                        <input type="number" id="mk-priv-amount" class="set-input flex-1 !py-1.5 text-[11px]" placeholder="SL (Tối thiểu 1000)...">
                    </div>
                    <div class="flex gap-2 mb-1">
                        <input type="number" id="mk-priv-price" class="set-input flex-[2] !py-1.5 text-[11px]" placeholder="Giá Vàng...">
                        <button type="button" onclick="MarketSystem.marketSell('private')" class="btn-royal flex-1 h-[30px] text-[10px] !bg-none bg-purple-700 border-purple-500 !text-white"><i class="fas fa-paper-plane"></i> GỬI LỆNH</button>
                    </div>
                </div>
                <h4 class="font-empire text-[11px] text-gray-400 mb-2 px-1 border-l-2 border-gray-500 pl-1.5">Lệnh Ngài Đã Gửi Đi</h4>
            `;

            const list = this.privateOrdersCache.filter(o => String(o.seller_id) === myId);
            if(list.length === 0) {
                contentHtml += `<div class="text-center text-gray-400 py-4 text-[10px] mb-4">Ngài chưa gửi lệnh bán kín nào.</div>`;
            } else {
                contentHtml += list.map(o => `
                <div class="royal-card p-2 text-[11px] mb-2 border border-purple-500/30">
                    <div class="flex items-start justify-between gap-2">
                        <div class="flex-1">
                            <div class="text-[var(--text-main)] font-bold text-[12px] opacity-90 mb-1"><span class="text-purple-400">Gửi cho ID: ${o.buyer_id || o.target_id}</span></div>
                            <div class="font-black text-[var(--text-main)] text-[12px]">Mặt hàng: <span class="text-c-gold">${formatFullNum(o.amount)} ${this.vnMap[o.resource_type] || o.resource_type}</span></div>
                            <div class="text-yellow-500 font-bold text-[11px] mt-0.5">Giá: ${formatFullNum(o.price_gold)} ${coinImg}</div>
                        </div>
                        <div class="flex flex-col gap-1 shrink-0 items-end justify-center">
                            <button type="button" onclick="MarketSystem.marketCancel(${o.id})" class="h-[30px] w-[60px] text-[10px] rounded bg-red-900/50 border border-red-500 text-red-300 active:scale-95 transition">HUỶ ĐƠN</button>
                        </div>
                    </div>
                </div>`).join('');
            }

        } else if (this.currentPrivateSubTab === 'buy') {
            contentHtml += `<h4 class="font-empire text-[11px] text-gray-400 mb-2 px-1 border-l-2 border-gray-500 pl-1.5 mt-2">Lệnh Được Gửi Tới Ngài</h4>`;
            
            const list = this.privateOrdersCache.filter(o => String(o.seller_id) !== myId);
            if(list.length === 0) {
                contentHtml += `<div class="text-center text-gray-400 py-4 text-[10px] mb-4">Không có lệnh mua kín nào gửi đến ngài.</div>`;
            } else {
                contentHtml += list.map(o => `
                <div class="royal-card p-2 text-[11px] mb-2 border border-green-500/30">
                    <div class="flex items-start justify-between gap-2">
                        <div class="flex-1">
                            <div class="text-[var(--text-main)] font-bold text-[12px] opacity-90 mb-1"><span class="text-green-400">Nhận từ: ${o.seller_name || o.seller_id}</span></div>
                            <div class="font-black text-[var(--text-main)] text-[12px]">Mặt hàng: <span class="text-c-gold">${formatFullNum(o.amount)} ${this.vnMap[o.resource_type] || o.resource_type}</span></div>
                            <div class="text-yellow-500 font-bold text-[11px] mt-0.5">Giá: ${formatFullNum(o.price_gold)} ${coinImg}</div>
                        </div>
                        <div class="flex flex-col gap-1 shrink-0 items-end justify-center">
                            <button type="button" onclick="MarketSystem.marketBuyPrivate(${o.id})" class="btn-royal h-[26px] w-[60px] text-[10px] !bg-none bg-green-700 border-green-500 !text-white mb-1">ĐỒNG Ý</button>
                            <button type="button" onclick="MarketSystem.marketRejectPrivate(${o.id})" class="h-[24px] w-[60px] text-[9px] rounded bg-red-900/50 border border-red-500 text-red-300">TỪ CHỐI</button>
                        </div>
                    </div>
                </div>`).join('');
            }
        }
        
        box.innerHTML = contentHtml;
    },

    // ==========================================
    // 3. LỊCH SỬ GIAO DỊCH (TÁCH RIÊNG HOÀN TOÀN)
    // ==========================================
    renderHistoryUI(container) {
        container.innerHTML = `
            <div class="flex gap-1 border-b border-[var(--gold)]/30 mb-3 px-1 mt-2">
                <button type="button" id="hist-sub-public" onclick="MarketSystem.switchHistorySubTab('public')" class="flex-1 pb-1.5 text-[11px] font-bold text-c-gold border-b-2 border-[var(--gold)] transition-all">Lịch Sử Công Khai</button>
                <button type="button" id="hist-sub-private" onclick="MarketSystem.switchHistorySubTab('private')" class="flex-1 pb-1.5 text-[11px] font-bold text-[var(--text-muted)] border-b-2 border-transparent transition-all">Lịch Sử Cá Nhân</button>
            </div>
            <div id="history-dynamic-content" class="w-full space-y-2 mb-6">
                <div class="text-center text-gray-500 py-4"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div>
            </div>
            <div class="h-28 w-full shrink-0"></div>
        `;
        this.loadHistory();
    },

    switchHistorySubTab(tab) {
        this.historySubTab = tab;
        ['public', 'private'].forEach(t => {
            const btn = document.getElementById(`hist-sub-${t}`);
            if(btn) {
                btn.className = (t === tab) 
                    ? "flex-1 pb-1.5 text-[11px] font-bold text-c-gold border-b-2 border-[var(--gold)] transition-all"
                    : "flex-1 pb-1.5 text-[11px] font-bold text-[var(--text-muted)] border-b-2 border-transparent transition-all";
            }
        });
        this.renderHistoryList();
    },

    async loadHistory() {
        try {
            const d = await App.api('/api/market/history', {});
            if(d && d.success) this.historyCache = d.history || [];
        } catch(e) { console.warn("Lỗi tải lịch sử."); }
        this.renderHistoryList();
    },

    renderHistoryList() {
        const box = document.getElementById('history-dynamic-content');
        if (!box) return;

        let contentHtml = '';
        let list = [];
        
        if (this.historySubTab === 'public') {
            list = this.historyCache.filter(h => !h.is_private);
            if(list.length === 0) contentHtml = `<div class="text-center text-gray-400 py-4 text-[10px]">Ngài chưa có giao dịch công khai nào.</div>`;
        } else {
            list = this.historyCache.filter(h => h.is_private);
            if(list.length === 0) contentHtml = `<div class="text-center text-gray-400 py-4 text-[10px]">Ngài chưa có giao dịch cá nhân nào.</div>`;
        }

        if(list.length > 0) {
            contentHtml = list.map(h => this.renderHistoryItem(h)).join('');
        }
        box.innerHTML = contentHtml;
    },

    // ==========================================
    // CÁC HÀM XỬ LÝ LOGIC CHUNG
    // ==========================================
    renderHistoryItem(h) {
        let statusHtml = '';
        switch(h.status.toLowerCase()) {
            case 'pending': statusHtml = '<span class="text-yellow-500 bg-yellow-900/40 border border-yellow-500/50 px-2 py-0.5 rounded text-[9px]">Đang chờ</span>'; break;
            case 'completed': 
            case 'sold': statusHtml = '<span class="text-green-500 bg-green-900/40 border border-green-500/50 px-2 py-0.5 rounded text-[9px]">Thành công</span>'; break;
            case 'rejected': statusHtml = '<span class="text-red-500 bg-red-900/40 border border-red-500/50 px-2 py-0.5 rounded text-[9px]">Từ chối</span>'; break;
            case 'cancelled': statusHtml = '<span class="text-gray-400 bg-gray-800 border border-gray-500 px-2 py-0.5 rounded text-[9px]">Đã hủy</span>'; break;
            default: statusHtml = `<span class="text-gray-400">${h.status}</span>`;
        }

        const isSell = String(h.seller_id) === String(App.user.telegram_id);
        const borderColor = h.is_private ? 'border-purple-500/20' : 'border-[var(--gold)]/20';

        return `<div class="bg-[var(--card-bg)] p-2 rounded-lg border ${borderColor} shadow-sm mb-2">
            <div class="flex justify-between items-center mb-1 border-b border-[var(--gold)]/10 pb-1">
                <span class="text-[10px] text-[var(--text-main)] opacity-80">${new Date(h.created_at || h.bought_at).toLocaleString()}</span>
                ${statusHtml}
            </div>
            <div class="text-[11px] text-[var(--text-main)] font-bold">
                ${isSell ? 'Bán' : 'Mua'}: <span class="text-c-gold">${formatFullNum(h.amount)} ${this.vnMap[h.resource_type] || h.resource_type}</span>
            </div>
            <div class="text-[11px] text-[var(--text-muted)] mt-0.5">
                Giá: <span class="text-yellow-500 font-bold">${formatFullNum(h.price_gold)} ${coinImg}</span>
            </div>
        </div>`;
    },

    getBadgeHtml(soldCount) {
        if (soldCount >= 2000) return '<span class="bg-gradient-to-r from-red-600 to-red-800 text-white px-1.5 py-0.5 rounded text-[8px] font-black border border-red-400 shadow-[0_0_5px_rgba(220,38,38,0.8)] ml-1">THƯỢNG CẤP</span>';
        if (soldCount >= 500) return '<span class="bg-gradient-to-r from-yellow-400 to-yellow-600 text-[var(--btn-text)] px-1.5 py-0.5 rounded text-[8px] font-black border border-yellow-200 shadow-[0_0_5px_rgba(250,204,21,0.8)] ml-1">CAO CẤP</span>';
        if (soldCount >= 100) return '<span class="bg-gradient-to-r from-purple-500 to-purple-700 text-white px-1.5 py-0.5 rounded text-[8px] font-black border border-purple-300 shadow-[0_0_5px_rgba(168,85,247,0.8)] ml-1">TRUNG CẤP</span>';
        if (soldCount >= 20) return '<span class="bg-gradient-to-r from-gray-300 to-gray-500 text-[var(--btn-text)] px-1.5 py-0.5 rounded text-[8px] font-black border border-white shadow-[0_0_5px_rgba(209,213,219,0.8)] ml-1">SƠ CẤP</span>';
        return '';
    },

    async marketSell(type) {
        let payload = {};
        if(type === 'public') {
            payload.resource_type = document.getElementById('mk-resource')?.value;
            payload.amount = Number(document.getElementById('mk-amount')?.value || 0);
            payload.price_gold = Number(document.getElementById('mk-price')?.value || 0);
        } else {
            payload.target_id = document.getElementById('mk-priv-target')?.value?.trim();
            payload.resource_type = document.getElementById('mk-priv-resource')?.value;
            payload.amount = Number(document.getElementById('mk-priv-amount')?.value || 0);
            payload.price_gold = Number(document.getElementById('mk-priv-price')?.value || 0);
            if(!payload.target_id) return App.toast('Vui lòng nhập ID người nhận!', 'error');
        }

        if (payload.amount < 1000) return App.toast('Số lượng rao bán tối thiểu là 1,000!', 'error');

        const endpoint = type === 'public' ? '/api/market/sell' : '/api/market/private/sell';
        const d = await App.api(endpoint, payload);
        
        App.toast(d.msg || (d.success ? 'Gửi lệnh thành công' : 'Lỗi gửi lệnh'), d.success ? 'success' : 'error');
        if(d.success) { 
            await App.syncAfterAction(); 
            if(type === 'public') { document.getElementById('mk-amount').value=''; this.loadPublicOrders(); }
            else { 
                document.getElementById('mk-priv-target').value='';
                document.getElementById('mk-priv-amount').value='';
                document.getElementById('mk-priv-price').value='';
                this.loadPrivateOrders(); 
            }
        }
    },
    
    async marketBuy(order_id) {
        const order = (this.ordersCache || []).find(x => Number(x.id) === Number(order_id));
        const details = order
            ? `Người bán: ${order.seller_name || 'Ẩn danh'}<br>Mặt hàng: ${formatFullNum(order.amount)} ${this.vnMap[order.resource_type] || order.resource_type}<br>Giá: ${formatFullNum(order.price_gold)} vàng`
            : 'Xác nhận khớp lệnh này? Vàng sẽ bị trừ ngay.';
            
        const ok = await App.confirmAction('Xác nhận mua lệnh', details);
        if(!ok) return;
        
        const d = await App.api('/api/market/buy', { order_id });
        App.toast(d.msg || (d.success ? 'Giao dịch thành công' : 'Giao dịch thất bại'), d.success ? 'success' : 'error');
        if(d.success) { 
            await App.syncAfterAction(); 
            this.loadPublicOrders();
        }
    },

    async marketBuyPrivate(order_id) {
        const ok = await App.confirmAction('Đồng ý giao dịch kín', 'Xác nhận đồng ý mua lệnh này? Vàng sẽ bị trừ ngay.');
        if(!ok) return;
        
        const d = await App.api('/api/market/private/action', { order_id, action: 'accept' });
        App.toast(d.msg || (d.success ? 'Giao dịch thành công' : 'Giao dịch thất bại'), d.success ? 'success' : 'error');
        if(d.success) { 
            await App.syncAfterAction(); 
            this.loadPrivateOrders(); 
        }
    },

    async marketRejectPrivate(order_id) {
        const ok = await App.confirmAction('Từ chối giao dịch', 'Ngài chắc chắn muốn TỪ CHỐI lệnh kín này?');
        if(!ok) return;
        
        const d = await App.api('/api/market/private/action', { order_id, action: 'reject' });
        App.toast(d.msg || (d.success ? 'Đã từ chối thành công' : 'Thất bại'), d.success ? 'success' : 'error');
        if(d.success) { 
            await App.syncAfterAction(); 
            this.loadPrivateOrders();
        }
    },
    
    async marketCancel(order_id) {
        const ok = await App.confirmAction('Huỷ lệnh bán', 'Huỷ lệnh sẽ bị trừ 5% nguyên liệu làm phí hao hụt. Xác nhận huỷ?');
        if(!ok) return;
        
        const d = await App.api('/api/market/cancel', { order_id });
        App.toast(d.msg || (d.success ? 'Đã huỷ thành công' : 'Huỷ thất bại'), d.success ? 'success' : 'error');
        if(d.success) { 
            await App.syncAfterAction(); 
            if(this.currentTab === 'public') this.loadPublicOrders();
            else this.loadPrivateOrders();
        }
    },
    
    async viewSellerIntro(sellerId) {
        const d = await App.api('/api/player_profile', { target_id: sellerId });
        if(!d.success) return App.toast('Không tải được hồ sơ.', 'error');
        const u = d.user || {};
        
        let contactHtml = u.contact_tg 
            ? `<br><br><button type="button" onclick="window.open('https://t.me/${u.contact_tg.replace('@', '')}', '_blank')" class="btn-royal w-full h-[35px] text-[11px]"><i class="fab fa-telegram mr-2"></i> Thương Lượng (Telegram)</button>`
            : `<br><br><span class="text-red-400 text-[10px] italic">Hoàng Đế này chưa cài đặt phương thức liên hệ.</span>`;

        // Thêm tham số "true" ở cuối để bật chế độ 1 nút ĐÓNG
        await App.confirmAction('Giới thiệu người bán', `<span class="text-c-gold font-bold text-[14px]">${u.first_name||'Ẩn danh'}</span><br><br><span class="opacity-90 italic">"${u.bio || 'Chưa có lời giới thiệu nào.'}"</span>${contactHtml}`, true);
    },
    
    async viewSellerOrders(sellerId) {
        const d = await App.api('/api/market/seller_orders', { seller_id: sellerId });
        if(!d.success) return App.toast(d.msg || 'Không tải được đơn hàng.', 'error');
        
        let html = '';
        const orders = d.orders || [];
        
        if (orders.length === 0) {
            html = '<div class="text-center text-gray-400 py-4 text-[11px]">Người bán này không còn đơn hàng nào khác.</div>';
        } else {
            html = '<div class="max-h-[50vh] overflow-y-auto pr-1">' + orders.map(o => `
                <div class="flex items-center justify-between border-b border-[var(--gold)]/20 py-2 mb-1">
                    <div class="flex-1 text-left">
                        <div class="text-c-gold font-bold text-[12px]">${formatFullNum(o.amount)} ${this.vnMap[o.resource_type] || o.resource_type}</div>
                        <div class="text-yellow-500 text-[11px] mt-0.5">Giá: ${formatFullNum(o.price_gold)} ${coinImg}</div>
                    </div>
                    <button type="button" onclick="const cf = document.getElementById('confirm-overlay'); if(cf) cf.remove(); setTimeout(() => MarketSystem.marketBuy(${o.id}), 300)" class="btn-royal h-[28px] px-4 text-[10px] shrink-0 active:scale-95 transition-all"><i class="fas fa-shopping-cart"></i> MUA</button>
                </div>
            `).join('') + '</div>';
        }

        // Thêm tham số "true" ở cuối để bật chế độ 1 nút ĐÓNG sạch sẽ
        await App.confirmAction('Đơn Hàng Khác', html, true);
    }
};
// ==========================================
// THIẾT LẬP KIỂM TRA CHẤM ĐỎ NGẦM
// ==========================================
setTimeout(() => { if(window.App && window.App.user) MarketSystem.checkNotifications(); }, 2000);
setInterval(() => { if(window.App && window.App.user) MarketSystem.checkNotifications(); }, 15000);
